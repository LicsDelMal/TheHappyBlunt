-- Update site_settings table to match TypeScript types
ALTER TABLE site_settings
  ADD COLUMN IF NOT EXISTS age_verification boolean DEFAULT true,
  ADD COLUMN IF NOT EXISTS site_name text DEFAULT 'The Happy Blunt',
  ADD COLUMN IF NOT EXISTS description text,
  ADD COLUMN IF NOT EXISTS logo text,
  ADD COLUMN IF NOT EXISTS primary_color text DEFAULT '#047857',
  ADD COLUMN IF NOT EXISTS payment_methods text[] DEFAULT ARRAY[]::text[],
  ADD COLUMN IF NOT EXISTS stripe_public_key text,
  ADD COLUMN IF NOT EXISTS stripe_secret_key text,
  ADD COLUMN IF NOT EXISTS shipping_zones jsonb DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS free_shipping_threshold numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS email_notifications jsonb DEFAULT '{"orderConfirmation": true, "abandonedCart": true, "orderShipped": true}'::jsonb,
  ADD COLUMN IF NOT EXISTS email_sender text,
  ADD COLUMN IF NOT EXISTS email_template text,
  ADD COLUMN IF NOT EXISTS password_min_length integer DEFAULT 8,
  ADD COLUMN IF NOT EXISTS max_login_attempts integer DEFAULT 3,
  ADD COLUMN IF NOT EXISTS two_factor_auth boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS terms_and_conditions text,
  ADD COLUMN IF NOT EXISTS privacy_policy text;

-- Rename any existing columns to match camelCase naming in TypeScript
ALTER TABLE site_settings 
  RENAME COLUMN age_verification TO "ageVerification";

ALTER TABLE site_settings 
  RENAME COLUMN site_name TO "siteName";

ALTER TABLE site_settings 
  RENAME COLUMN primary_color TO "primaryColor";

ALTER TABLE site_settings 
  RENAME COLUMN payment_methods TO "paymentMethods";

ALTER TABLE site_settings 
  RENAME COLUMN stripe_public_key TO "stripePublicKey";

ALTER TABLE site_settings 
  RENAME COLUMN stripe_secret_key TO "stripeSecretKey";

ALTER TABLE site_settings 
  RENAME COLUMN shipping_zones TO "shippingZones";

ALTER TABLE site_settings 
  RENAME COLUMN free_shipping_threshold TO "freeShippingThreshold";

ALTER TABLE site_settings 
  RENAME COLUMN email_notifications TO "emailNotifications";

ALTER TABLE site_settings 
  RENAME COLUMN email_sender TO "emailSender";

ALTER TABLE site_settings 
  RENAME COLUMN email_template TO "emailTemplate";

ALTER TABLE site_settings 
  RENAME COLUMN password_min_length TO "passwordMinLength";

ALTER TABLE site_settings 
  RENAME COLUMN max_login_attempts TO "maxLoginAttempts";

ALTER TABLE site_settings 
  RENAME COLUMN two_factor_auth TO "twoFactorAuth";

ALTER TABLE site_settings 
  RENAME COLUMN terms_and_conditions TO "termsAndConditions";

ALTER TABLE site_settings 
  RENAME COLUMN privacy_policy TO "privacyPolicy";