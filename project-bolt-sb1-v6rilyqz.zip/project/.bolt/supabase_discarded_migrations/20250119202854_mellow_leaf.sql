-- Drop existing policies if they exist
DROP POLICY IF EXISTS "allow_read" ON categories;
DROP POLICY IF EXISTS "allow_admin_write" ON categories;

-- Drop existing triggers if they exist
DROP TRIGGER IF EXISTS update_categories_timestamp ON categories;

-- Drop existing functions if they exist
DROP FUNCTION IF EXISTS update_categories_timestamp();

-- Delete existing data
DELETE FROM categories;

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_categories_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for timestamp updates
CREATE TRIGGER update_categories_timestamp
  BEFORE UPDATE ON categories
  FOR EACH ROW
  EXECUTE FUNCTION update_categories_timestamp();

-- Create policies
CREATE POLICY "allow_read"
  ON categories FOR SELECT
  TO public
  USING (true);

CREATE POLICY "allow_admin_write"
  ON categories FOR ALL 
  TO authenticated
  USING ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com')
  WITH CHECK ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com');

-- Insert main categories (level 1)
WITH main_categories AS (
  INSERT INTO categories (name, level, display_order) VALUES
    ('FLOR', 1, 1),
    ('COMESTIBLES', 1, 2),
    ('EXTRACTOS', 1, 3),
    ('INSUMOS', 1, 4),
    ('PSICOTROPICOS', 1, 5)
  RETURNING id, name
),
-- Insert FLOR weights (level 2)
flor_weights AS (
  INSERT INTO categories (name, parent_id, level, display_order)
  SELECT w.weight_name, m.id, 2, w.ord
  FROM main_categories m
  CROSS JOIN (VALUES 
    ('1kg', 1),
    ('1/2kg', 2),
    ('1/4kg', 3),
    ('Oz', 4),
    ('Toques', 5)
  ) AS w(weight_name, ord)
  WHERE m.name = 'FLOR'
  RETURNING id, name
),
-- Insert qualities for each weight (level 3)
flor_qualities AS (
  INSERT INTO categories (name, parent_id, level, display_order)
  SELECT q.quality_name, w.id, 3, q.ord
  FROM flor_weights w
  CROSS JOIN (VALUES 
    ('Regular', 1),
    ('Quality', 2),
    ('Exotica', 3)
  ) AS q(quality_name, ord)
  WHERE w.name IN ('1kg', '1/2kg', '1/4kg')
),
-- Insert special qualities for Oz
oz_qualities AS (
  INSERT INTO categories (name, parent_id, level, display_order)
  SELECT q.quality_name, w.id, 3, q.ord
  FROM flor_weights w
  CROSS JOIN (VALUES 
    ('Regular', 1),
    ('Quality', 2),
    ('Exotica', 3),
    ('Hydro', 4),
    ('Indoor', 5),
    ('Greenhouse', 6)
  ) AS q(quality_name, ord)
  WHERE w.name = 'Oz'
),
-- Insert Toques products
toques_products AS (
  INSERT INTO categories (name, parent_id, level, display_order)
  SELECT p.product_name, w.id, 3, p.ord
  FROM flor_weights w
  CROSS JOIN (VALUES 
    ('12na Natural', 1),
    ('12na Empanizada', 2),
    ('12na de Hydro', 3),
    ('Blunt Empanizado', 4),
    ('Baby Jeetter', 5)
  ) AS p(product_name, ord)
  WHERE w.name = 'Toques'
),
-- Insert COMESTIBLES subcategories
comestibles_subcats AS (
  INSERT INTO categories (name, parent_id, level, display_order)
  SELECT s.subcat_name, m.id, 2, s.ord
  FROM main_categories m
  CROSS JOIN (VALUES 
    ('Americanos', 1),
    ('Caseros', 2)
  ) AS s(subcat_name, ord)
  WHERE m.name = 'COMESTIBLES'
),
-- Insert EXTRACTOS subcategories
extractos_subcats AS (
  INSERT INTO categories (name, parent_id, level, display_order)
  SELECT s.subcat_name, m.id, 2, s.ord
  FROM main_categories m
  CROSS JOIN (VALUES 
    ('Cartuchos', 1),
    ('Desechables', 2),
    ('Solidos', 3)
  ) AS s(subcat_name, ord)
  WHERE m.name = 'EXTRACTOS'
  RETURNING id, name
),
-- Insert Cartuchos variants
cartuchos_variants AS (
  INSERT INTO categories (name, parent_id, level, display_order)
  SELECT v.variant_name, e.id, 3, v.ord
  FROM extractos_subcats e
  CROSS JOIN (VALUES 
    ('Originales', 1),
    ('De Lab todos 2gr', 2)
  ) AS v(variant_name, ord)
  WHERE e.name = 'Cartuchos'
),
-- Insert Desechables variants
desechables_variants AS (
  INSERT INTO categories (name, parent_id, level, display_order)
  SELECT v.variant_name, e.id, 3, v.ord
  FROM extractos_subcats e
  CROSS JOIN (VALUES 
    ('Originales', 1),
    ('De Lab', 2)
  ) AS v(variant_name, ord)
  WHERE e.name = 'Desechables'
  RETURNING id, name
),
-- Insert sizes for Desechables variants
desechables_sizes AS (
  INSERT INTO categories (name, parent_id, level, display_order)
  SELECT s.size_name, v.id, 4, s.ord
  FROM desechables_variants v
  CROSS JOIN (VALUES 
    ('1g', 1),
    ('2g', 2),
    ('3g', 3)
  ) AS s(size_name, ord)
),
-- Insert Solidos products
solidos_products AS (
  INSERT INTO categories (name, parent_id, level, display_order)
  SELECT '(Solid Wax, Rossin) presentaciones 1gr', e.id, 3, 1
  FROM extractos_subcats e
  WHERE e.name = 'Solidos'
),
-- Insert INSUMOS subcategories
insumos_subcats AS (
  INSERT INTO categories (name, parent_id, level, display_order)
  SELECT s.subcat_name, m.id, 2, s.ord
  FROM main_categories m
  CROSS JOIN (VALUES 
    ('Para Wax', 1),
    ('Para Weed', 2)
  ) AS s(subcat_name, ord)
  WHERE m.name = 'INSUMOS'
),
-- Insert PSICOTROPICOS subcategories
psicotropicos_subcats AS (
  INSERT INTO categories (name, parent_id, level, display_order)
  SELECT s.subcat_name, m.id, 2, s.ord
  FROM main_categories m
  CROSS JOIN (VALUES 
    ('LSD', 1),
    ('Hongos', 2)
  ) AS s(subcat_name, ord)
  WHERE m.name = 'PSICOTROPICOS'
  RETURNING id, name
),
-- Insert LSD variants
lsd_variants AS (
  INSERT INTO categories (name, parent_id, level, display_order)
  SELECT v.variant_name, p.id, 3, v.ord
  FROM psicotropicos_subcats p
  CROSS JOIN (VALUES 
    ('Triangulo', 1),
    ('Cuadro', 2),
    ('Gel tap', 3)
  ) AS v(variant_name, ord)
  WHERE p.name = 'LSD'
),
-- Insert Hongos products
hongos_products AS (
  INSERT INTO categories (name, parent_id, level, display_order)
  SELECT p.product_name, ps.id, 3, p.ord
  FROM psicotropicos_subcats ps
  CROSS JOIN (VALUES 
    ('Bolsa 2gr', 1),
    ('pastilla microdosis', 2),
    ('Chocohongos', 3)
  ) AS p(product_name, ord)
  WHERE ps.name = 'Hongos'
)
SELECT 'Categories structure created successfully' as result;

-- Verify the structure was created correctly
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM categories WHERE name = 'FLOR'
    UNION ALL
    SELECT FROM categories WHERE name = 'COMESTIBLES'
    UNION ALL
    SELECT FROM categories WHERE name = 'EXTRACTOS'
  ) THEN
    RAISE EXCEPTION 'Categories structure was not properly created';
  END IF;
END $$;