-- Drop existing policies
DROP POLICY IF EXISTS "Enable read access for own profile" ON user_profiles;
DROP POLICY IF EXISTS "Enable read access for admins" ON user_profiles;
DROP POLICY IF EXISTS "Enable write access for admins" ON user_profiles;

-- Create simplified policies that avoid recursion
CREATE POLICY "Anyone can read active profiles"
  ON user_profiles FOR SELECT
  TO public
  USING (is_active = true);

CREATE POLICY "Users can read their own profile"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (id = auth.uid());

CREATE POLICY "Admin can manage profiles"
  ON user_profiles FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM auth.users
      WHERE id = auth.uid()
      AND raw_user_meta_data->>'username' = 'admin'
    )
  );

-- Create index for performance
CREATE INDEX IF NOT EXISTS idx_user_profiles_active ON user_profiles(is_active);
CREATE INDEX IF NOT EXISTS idx_auth_users_username ON auth.users((raw_user_meta_data->>'username'));