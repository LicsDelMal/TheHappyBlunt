-- Drop ALL existing policies first to avoid conflicts
DROP POLICY IF EXISTS "Anyone can read active profiles" ON user_profiles;
DROP POLICY IF EXISTS "Users can read their own profile" ON user_profiles;
DROP POLICY IF EXISTS "Admin can manage profiles" ON user_profiles;
DROP POLICY IF EXISTS "Enable read access for own profile" ON user_profiles;
DROP POLICY IF EXISTS "Enable read access for admins" ON user_profiles;
DROP POLICY IF EXISTS "Enable write access for admins" ON user_profiles;

-- Create new simplified policies
CREATE POLICY "Enable basic read access"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (
    id = auth.uid() OR
    auth.jwt() -> 'user_metadata' ->> 'username' = 'admin'
  );

CREATE POLICY "Enable admin write access"
  ON user_profiles FOR ALL
  TO authenticated
  USING (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin')
  WITH CHECK (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin');

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_user_profiles_active ON user_profiles(is_active);
CREATE INDEX IF NOT EXISTS idx_auth_users_username ON auth.users((raw_user_meta_data->>'username'));