-- Drop existing function
DROP FUNCTION IF EXISTS get_auth_users();

-- Create updated function with correct types
CREATE OR REPLACE FUNCTION get_auth_users()
RETURNS TABLE (
  id uuid,
  email varchar,
  username text,
  role text,
  is_active boolean,
  last_login timestamptz
) 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    au.id,
    au.email::varchar,
    up.username,
    up.role,
    up.is_active,
    up.last_login
  FROM auth.users au
  LEFT JOIN user_profiles up ON au.id = up.id
  ORDER BY au.created_at DESC;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION get_auth_users TO authenticated;