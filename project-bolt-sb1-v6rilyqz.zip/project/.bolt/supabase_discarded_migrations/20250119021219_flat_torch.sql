-- Add ON DELETE CASCADE to order_items foreign key
ALTER TABLE order_items
DROP CONSTRAINT order_items_product_id_fkey,
ADD CONSTRAINT order_items_product_id_fkey 
  FOREIGN KEY (product_id) 
  REFERENCES products(id) 
  ON DELETE CASCADE;