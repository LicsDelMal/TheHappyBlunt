-- Drop existing table if it exists
DROP TABLE IF EXISTS categories CASCADE;

-- Create categories table
CREATE TABLE categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  parent_id uuid REFERENCES categories(id) ON DELETE CASCADE,
  level integer NOT NULL DEFAULT 1,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "allow_read"
  ON categories FOR SELECT
  TO public
  USING (true);

CREATE POLICY "allow_admin_write"
  ON categories FOR ALL 
  TO authenticated
  USING ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com')
  WITH CHECK ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com');

-- Insert main categories (level 1)
WITH inserted_main AS (
  INSERT INTO categories (name, level) 
  VALUES 
    ('Flor', 1),
    ('Vaporizadores', 1)
  RETURNING id, name
),
-- Insert quality categories for Flor (level 2)
inserted_qualities AS (
  INSERT INTO categories (name, parent_id, level)
  SELECT 
    quality,
    (SELECT id FROM inserted_main WHERE name = 'Flor'),
    2
  FROM unnest(ARRAY['Exótica', 'Premium', 'Alta Calidad', 'Standar']) AS quality
  RETURNING id, name
)
-- Insert weight categories for each quality (level 3)
INSERT INTO categories (name, parent_id, level)
SELECT 
  weight,
  quality.id,
  3
FROM inserted_qualities quality
CROSS JOIN unnest(ARRAY['1Kg', '1/2Kg', '1/4Kg', 'Onza']) AS weight;

-- Insert Vaporizadores subcategories (level 2)
INSERT INTO categories (name, parent_id, level)
SELECT 
  size,
  (SELECT id FROM categories WHERE name = 'Vaporizadores'),
  2
FROM unnest(ARRAY['1 Gramo', '2 Gramos']) AS size;

-- Create indexes for better performance
CREATE INDEX idx_categories_parent_id ON categories(parent_id);
CREATE INDEX idx_categories_name ON categories(name);
CREATE INDEX idx_categories_level ON categories(level);

-- Grant necessary permissions
GRANT ALL ON categories TO authenticated;
GRANT SELECT ON categories TO anon;

-- Verify the hierarchy was created correctly
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM categories WHERE name = 'Flor'
    UNION ALL
    SELECT FROM categories WHERE name = 'Exótica'
    UNION ALL
    SELECT FROM categories WHERE name = '1Kg'
  ) THEN
    RAISE EXCEPTION 'Categories hierarchy was not properly created';
  END IF;
END $$;