-- Drop existing policies for order_items
DROP POLICY IF EXISTS "order_items_user_read" ON order_items;
DROP POLICY IF EXISTS "order_items_admin_all" ON order_items;

-- Create new policies for order_items
CREATE POLICY "enable_user_read_own_items"
  ON order_items FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_items.order_id
      AND orders.user_id = auth.uid()
    )
  );

CREATE POLICY "enable_user_insert_own_items"
  ON order_items FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_items.order_id
      AND orders.user_id = auth.uid()
    )
  );

CREATE POLICY "enable_admin_all_items"
  ON order_items FOR ALL
  TO authenticated
  USING (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin')
  WITH CHECK (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin');

-- Rename price_at_time to price if it exists
DO $$ 
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'order_items' AND column_name = 'price_at_time'
  ) THEN
    ALTER TABLE order_items RENAME COLUMN price_at_time TO price;
  END IF;
END $$;

-- Add price column if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'order_items' AND column_name = 'price'
  ) THEN
    ALTER TABLE order_items ADD COLUMN price numeric NOT NULL;
  END IF;
END $$;

-- Grant necessary permissions
GRANT ALL ON order_items TO authenticated;