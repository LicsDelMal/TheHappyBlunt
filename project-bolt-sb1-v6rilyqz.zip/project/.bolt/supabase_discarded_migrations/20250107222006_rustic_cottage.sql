-- Drop existing policies
DROP POLICY IF EXISTS "Public read access for coupons" ON coupons;
DROP POLICY IF EXISTS "Admin full access for coupons" ON coupons;

-- Create new simplified policies
CREATE POLICY "enable_read_for_all"
  ON coupons FOR SELECT
  TO public
  USING (true);

CREATE POLICY "enable_write_for_admin"
  ON coupons FOR INSERT
  TO authenticated
  WITH CHECK (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin');

CREATE POLICY "enable_update_for_admin"
  ON coupons FOR UPDATE
  TO authenticated
  USING (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin')
  WITH CHECK (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin');

CREATE POLICY "enable_delete_for_admin"
  ON coupons FOR DELETE
  TO authenticated
  USING (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin');

-- Ensure RLS is enabled
ALTER TABLE coupons ENABLE ROW LEVEL SECURITY;

-- Grant necessary permissions
GRANT ALL ON coupons TO authenticated;
GRANT SELECT ON coupons TO anon;