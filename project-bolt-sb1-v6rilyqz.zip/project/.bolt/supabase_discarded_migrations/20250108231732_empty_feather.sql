-- Create product_images table
CREATE TABLE IF NOT EXISTS product_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products ON DELETE CASCADE,
  image_url text NOT NULL,
  display_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE product_images ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "product_images_read"
  ON product_images FOR SELECT
  TO public
  USING (true);

CREATE POLICY "product_images_admin"
  ON product_images FOR ALL
  TO authenticated
  USING ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com')
  WITH CHECK ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com');

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_product_images_product ON product_images(product_id);
CREATE INDEX IF NOT EXISTS idx_product_images_order ON product_images(product_id, display_order);

-- Grant permissions
GRANT ALL ON product_images TO authenticated;
GRANT SELECT ON product_images TO anon;