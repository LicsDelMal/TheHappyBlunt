-- Create categories table
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  parent_id uuid REFERENCES categories(id),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "allow_read"
  ON categories FOR SELECT
  TO public
  USING (true);

CREATE POLICY "allow_admin_write"
  ON categories FOR ALL 
  TO authenticated
  USING ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com')
  WITH CHECK ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com');

-- Insert default categories
INSERT INTO categories (name) VALUES
  ('Flor'),
  ('Vapeadores')
ON CONFLICT (name) DO NOTHING;

-- Get the ID of the 'Flor' category
DO $$ 
DECLARE
  flor_id uuid;
BEGIN
  SELECT id INTO flor_id FROM categories WHERE name = 'Flor';
  
  -- Insert subcategories for 'Flor'
  INSERT INTO categories (name, parent_id) VALUES
    ('Kilos', flor_id),
    ('1/2 Kilos', flor_id),
    ('Onzas', flor_id)
  ON CONFLICT (name) DO NOTHING;
END $$;