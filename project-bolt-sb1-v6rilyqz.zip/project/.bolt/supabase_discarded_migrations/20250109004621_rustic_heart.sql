-- Drop existing trigger and function
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- Create improved function to handle new user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  -- Ensure we have a username
  IF NEW.raw_user_meta_data->>'username' IS NULL THEN
    RAISE EXCEPTION 'Username is required';
  END IF;

  -- Create user profile with is_active set to true by default
  INSERT INTO public.user_profiles (
    id,
    username,
    role,
    is_active,
    last_login
  ) VALUES (
    NEW.id,
    NEW.raw_user_meta_data->>'username',
    CASE 
      WHEN NEW.raw_user_meta_data->>'username' = 'admin' THEN 'admin'
      ELSE 'user'
    END,
    true, -- Set is_active to true by default
    CURRENT_TIMESTAMP
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recreate trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Update any existing inactive users to be active
UPDATE user_profiles 
SET is_active = true 
WHERE is_active = false;