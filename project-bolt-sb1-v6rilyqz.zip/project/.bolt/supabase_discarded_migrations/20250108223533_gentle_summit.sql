-- Drop existing policies for site-assets bucket
DROP POLICY IF EXISTS "storage_read_access" ON storage.objects;
DROP POLICY IF EXISTS "storage_write_access" ON storage.objects;
DROP POLICY IF EXISTS "storage_update_access" ON storage.objects;
DROP POLICY IF EXISTS "storage_delete_access" ON storage.objects;

-- Update bucket configuration
UPDATE storage.buckets 
SET public = true
WHERE id = 'site-assets';

-- Create simplified policies for site-assets
CREATE POLICY "allow_site_assets_read"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'site-assets');

CREATE POLICY "allow_site_assets_admin"
  ON storage.objects FOR ALL
  TO authenticated
  USING (
    bucket_id = 'site-assets' AND
    (auth.jwt() ->> 'email') = 'admin@thehappyblunt.com'
  );