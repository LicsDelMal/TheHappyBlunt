-- Add soft delete column to products table
ALTER TABLE products 
ADD COLUMN IF NOT EXISTS deleted_at timestamptz DEFAULT NULL;

-- Create index for better performance on soft delete queries
CREATE INDEX IF NOT EXISTS idx_products_deleted_at ON products(deleted_at);

-- Update existing RLS policies to consider soft delete
CREATE OR REPLACE POLICY "allow_read"
  ON products FOR SELECT
  TO public
  USING (deleted_at IS NULL);

CREATE OR REPLACE POLICY "allow_admin_write"
  ON products FOR ALL 
  TO authenticated
  USING ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com')
  WITH CHECK ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com');

-- Create function to soft delete products
CREATE OR REPLACE FUNCTION soft_delete_product(product_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE products
  SET deleted_at = CURRENT_TIMESTAMP,
      is_visible = false
  WHERE id = product_id;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION soft_delete_product TO authenticated;