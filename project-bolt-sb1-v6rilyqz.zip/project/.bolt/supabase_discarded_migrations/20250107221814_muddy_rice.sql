-- Create orders table
CREATE TABLE orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  status text NOT NULL CHECK (status IN ('pending', 'processing', 'shipped', 'delivered', 'cancelled')),
  total_amount numeric NOT NULL CHECK (total_amount >= 0),
  shipping_address jsonb NOT NULL,
  tracking_number text,
  notes text,
  coupon_id uuid REFERENCES coupons,
  discount_amount numeric DEFAULT 0,
  shipping_cost numeric DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create order items table
CREATE TABLE order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders NOT NULL,
  product_id uuid REFERENCES products NOT NULL,
  quantity integer NOT NULL CHECK (quantity > 0),
  price_at_time numeric NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create order status history table
CREATE TABLE order_status_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders NOT NULL,
  status text NOT NULL,
  notes text,
  created_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users NOT NULL
);

-- Enable RLS
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_status_history ENABLE ROW LEVEL SECURITY;

-- Create indexes
CREATE INDEX idx_orders_user ON orders(user_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_created ON orders(created_at);
CREATE INDEX idx_order_items_order ON order_items(order_id);
CREATE INDEX idx_order_history_order ON order_status_history(order_id);

-- Create policies for orders
CREATE POLICY "Users can view their own orders"
  ON orders FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admin can view all orders"
  ON orders FOR SELECT
  TO authenticated
  USING (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin');

CREATE POLICY "Admin can manage orders"
  ON orders FOR ALL
  TO authenticated
  USING (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin')
  WITH CHECK (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin');

-- Create policies for order items
CREATE POLICY "Users can view their own order items"
  ON order_items FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_items.order_id
      AND orders.user_id = auth.uid()
    )
  );

CREATE POLICY "Admin can view all order items"
  ON order_items FOR SELECT
  TO authenticated
  USING (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin');

CREATE POLICY "Admin can manage order items"
  ON order_items FOR ALL
  TO authenticated
  USING (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin')
  WITH CHECK (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin');

-- Create policies for order status history
CREATE POLICY "Users can view their own order history"
  ON order_status_history FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_status_history.order_id
      AND orders.user_id = auth.uid()
    )
  );

CREATE POLICY "Admin can view all order history"
  ON order_status_history FOR SELECT
  TO authenticated
  USING (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin');

CREATE POLICY "Admin can manage order history"
  ON order_status_history FOR ALL
  TO authenticated
  USING (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin')
  WITH CHECK (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin');

-- Create function to update order timestamps
CREATE OR REPLACE FUNCTION update_order_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for order timestamp updates
CREATE TRIGGER update_order_timestamp
  BEFORE UPDATE ON orders
  FOR EACH ROW
  EXECUTE FUNCTION update_order_timestamp();

-- Create function to log status changes
CREATE OR REPLACE FUNCTION log_order_status_change()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.status IS NULL OR NEW.status != OLD.status THEN
    INSERT INTO order_status_history (
      order_id,
      status,
      created_by
    ) VALUES (
      NEW.id,
      NEW.status,
      auth.uid()
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for status change logging
CREATE TRIGGER log_order_status_change
  AFTER INSERT OR UPDATE ON orders
  FOR EACH ROW
  EXECUTE FUNCTION log_order_status_change();