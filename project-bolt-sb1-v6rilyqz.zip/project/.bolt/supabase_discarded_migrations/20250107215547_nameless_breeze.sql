-- Drop existing policies
DROP POLICY IF EXISTS "basic_read_access" ON user_profiles;
DROP POLICY IF EXISTS "admin_write_access" ON user_profiles;

-- Create new simplified policies
CREATE POLICY "enable_read_access"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "enable_admin_access"
  ON user_profiles FOR ALL
  TO authenticated
  USING (
    auth.jwt() -> 'user_metadata' ->> 'username' = 'admin'
  );

-- Ensure RLS is enabled
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

-- Grant necessary permissions
GRANT ALL ON user_profiles TO authenticated;