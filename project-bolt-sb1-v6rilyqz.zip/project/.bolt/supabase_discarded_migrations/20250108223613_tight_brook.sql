-- Drop existing policies
DROP POLICY IF EXISTS "Admin can manage site settings" ON site_settings;
DROP POLICY IF EXISTS "Public can read site settings" ON site_settings;
DROP POLICY IF EXISTS "Enable full access for admin users" ON site_settings;
DROP POLICY IF EXISTS "Enable public read access to basic settings" ON site_settings;

-- Create simplified policies
CREATE POLICY "allow_settings_read"
  ON site_settings FOR SELECT
  TO public
  USING (true);

CREATE POLICY "allow_settings_admin"
  ON site_settings FOR ALL
  TO authenticated
  USING ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com')
  WITH CHECK ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com');

-- Ensure RLS is enabled
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;

-- Grant permissions
GRANT ALL ON site_settings TO authenticated;
GRANT SELECT ON site_settings TO anon;