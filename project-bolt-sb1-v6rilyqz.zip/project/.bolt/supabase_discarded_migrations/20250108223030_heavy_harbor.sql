-- First ensure we clean up any existing policies
DO $$ 
BEGIN
    -- Drop all existing policies on products
    DROP POLICY IF EXISTS "enable_read_for_all" ON products;
    DROP POLICY IF EXISTS "enable_write_for_admin" ON products;
    DROP POLICY IF EXISTS "Enable read access for all users" ON products;
    DROP POLICY IF EXISTS "Enable insert for admin users" ON products;
    DROP POLICY IF EXISTS "Enable update for admin users" ON products;
    DROP POLICY IF EXISTS "Enable delete for admin users" ON products;
END $$;

-- Create new clear policies
CREATE POLICY "products_read_policy"
  ON products FOR SELECT
  TO public
  USING (true);

CREATE POLICY "products_write_policy"
  ON products FOR ALL
  TO authenticated
  USING (
    (SELECT role FROM user_profiles WHERE id = auth.uid()) = 'admin'
  )
  WITH CHECK (
    (SELECT role FROM user_profiles WHERE id = auth.uid()) = 'admin'
  );

-- Ensure RLS is enabled
ALTER TABLE products ENABLE ROW LEVEL SECURITY;

-- Grant proper permissions
GRANT ALL ON products TO authenticated;
GRANT SELECT ON products TO anon;

-- Create index to optimize policy checks
CREATE INDEX IF NOT EXISTS idx_user_profiles_role ON user_profiles(role);