-- Drop existing policies
DROP POLICY IF EXISTS "Users can view their own order history" ON order_status_history;
DROP POLICY IF EXISTS "Admin can manage order history" ON order_status_history;

-- Create new simplified policies
CREATE POLICY "enable_user_read_own_history"
  ON order_status_history FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_status_history.order_id
      AND orders.user_id = auth.uid()
    )
  );

CREATE POLICY "enable_user_insert_own_history"
  ON order_status_history FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_status_history.order_id
      AND orders.user_id = auth.uid()
    )
  );

CREATE POLICY "enable_admin_all_history"
  ON order_status_history FOR ALL
  TO authenticated
  USING (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin')
  WITH CHECK (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin');

-- Grant necessary permissions
GRANT ALL ON order_status_history TO authenticated;