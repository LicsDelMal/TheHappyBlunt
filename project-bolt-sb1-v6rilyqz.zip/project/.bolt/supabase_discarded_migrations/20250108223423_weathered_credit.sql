-- Drop existing storage policies
DROP POLICY IF EXISTS "Public read access" ON storage.objects;
DROP POLICY IF EXISTS "Admin insert access" ON storage.objects;
DROP POLICY IF EXISTS "Admin update access" ON storage.objects;
DROP POLICY IF EXISTS "Admin delete access" ON storage.objects;

-- Update bucket configuration
UPDATE storage.buckets 
SET public = true
WHERE id = 'product-images';

-- Create simplified storage policies
CREATE POLICY "allow_public_read"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'product-images');

CREATE POLICY "allow_admin_all"
  ON storage.objects FOR ALL
  TO authenticated
  USING (
    bucket_id = 'product-images' AND
    (auth.jwt() ->> 'email') = 'admin@thehappyblunt.com'
  );

-- Ensure RLS is enabled
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;