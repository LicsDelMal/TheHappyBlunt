-- Drop existing trigger and function
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- Create improved function to handle new user creation with better error handling
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  -- Ensure we have a username
  IF NEW.raw_user_meta_data->>'username' IS NULL THEN
    RAISE EXCEPTION 'Username is required';
  END IF;

  -- Create user profile
  INSERT INTO public.user_profiles (
    id,
    username,
    role,
    is_active,
    last_login
  ) VALUES (
    NEW.id,
    NEW.raw_user_meta_data->>'username',
    CASE 
      WHEN NEW.raw_user_meta_data->>'username' = 'admin' THEN 'admin'
      ELSE 'user'
    END,
    CASE 
      WHEN NEW.raw_user_meta_data->>'username' = 'admin' THEN true
      ELSE false
    END,
    CURRENT_TIMESTAMP
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recreate trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Update RLS policies for user_profiles
DROP POLICY IF EXISTS "Users can view their own profile" ON user_profiles;
DROP POLICY IF EXISTS "Admin can view all profiles" ON user_profiles;

CREATE POLICY "Users can view their own profile"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (
    id = auth.uid() OR
    (SELECT role FROM user_profiles WHERE id = auth.uid()) = 'admin'
  );

CREATE POLICY "Admin can manage all profiles"
  ON user_profiles FOR ALL
  TO authenticated
  USING (
    (SELECT role FROM user_profiles WHERE id = auth.uid()) = 'admin'
  )
  WITH CHECK (
    (SELECT role FROM user_profiles WHERE id = auth.uid()) = 'admin'
  );