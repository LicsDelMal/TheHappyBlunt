-- Add category_id to products table
ALTER TABLE products
ADD COLUMN category_id uuid REFERENCES categories(id) ON DELETE SET NULL;

-- Create index for better performance
CREATE INDEX idx_products_category_id ON products(category_id);

-- Update existing products to link with appropriate categories
UPDATE products p
SET category_id = (
  SELECT c.id 
  FROM categories c 
  WHERE c.name = p.category 
  OR c.name = p.subcategory
  LIMIT 1
);