-- Create function to delete user from auth.users and cascade to profile
CREATE OR REPLACE FUNCTION delete_user_complete(user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Delete from auth.users which will cascade to user_profiles
  DELETE FROM auth.users WHERE id = user_id;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION delete_user_complete TO authenticated;

-- Update RPC call name in existing code
CREATE OR REPLACE FUNCTION delete_user(user_id uuid)
RETURNS void AS $$
BEGIN
  PERFORM delete_user_complete(user_id);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;