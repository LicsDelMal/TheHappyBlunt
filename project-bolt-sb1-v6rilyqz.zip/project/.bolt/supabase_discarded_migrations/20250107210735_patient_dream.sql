-- Drop existing policies for site-assets bucket
DROP POLICY IF EXISTS "Public read access for site assets" ON storage.objects;
DROP POLICY IF EXISTS "Admin write access for site assets" ON storage.objects;
DROP POLICY IF EXISTS "Admin update access for site assets" ON storage.objects;
DROP POLICY IF EXISTS "Admin delete access for site assets" ON storage.objects;

-- Create storage bucket if it doesn't exist
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name, public)
  VALUES ('site-assets', 'site-assets', true)
  ON CONFLICT (id) DO NOTHING;
END $$;

-- Set up storage policies
CREATE POLICY "Public read access for site assets"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'site-assets');

CREATE POLICY "Admin insert access for site assets"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'site-assets' AND
    (auth.jwt() -> 'user_metadata' ->> 'username') = 'admin'
  );

CREATE POLICY "Admin update access for site assets"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'site-assets' AND
    (auth.jwt() -> 'user_metadata' ->> 'username') = 'admin'
  );

CREATE POLICY "Admin delete access for site assets"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'site-assets' AND
    (auth.jwt() -> 'user_metadata' ->> 'username') = 'admin'
  );