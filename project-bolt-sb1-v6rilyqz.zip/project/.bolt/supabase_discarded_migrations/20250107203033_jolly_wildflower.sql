/*
  # Add product visibility and discount columns

  1. Changes
    - Add `is_visible` column to products table (boolean)
    - Add `discount_percent` column to products table (numeric)
    - Add `subcategory` column to products table (text)
    
  2. Default Values
    - `is_visible` defaults to true
    - `discount_percent` defaults to 0
*/

-- Add new columns with safe checks
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'products' AND column_name = 'is_visible'
  ) THEN
    ALTER TABLE products ADD COLUMN is_visible boolean DEFAULT true;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'products' AND column_name = 'discount_percent'
  ) THEN
    ALTER TABLE products ADD COLUMN discount_percent numeric DEFAULT 0 CHECK (discount_percent >= 0 AND discount_percent <= 100);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'products' AND column_name = 'subcategory'
  ) THEN
    ALTER TABLE products ADD COLUMN subcategory text;
  END IF;
END $$;

-- Update existing products to have default values
UPDATE products 
SET is_visible = true, 
    discount_percent = 0 
WHERE is_visible IS NULL 
   OR discount_percent IS NULL;

-- Add index for faster filtering
CREATE INDEX IF NOT EXISTS idx_products_visibility ON products(is_visible);
CREATE INDEX IF NOT EXISTS idx_products_category_subcategory ON products(category, subcategory);