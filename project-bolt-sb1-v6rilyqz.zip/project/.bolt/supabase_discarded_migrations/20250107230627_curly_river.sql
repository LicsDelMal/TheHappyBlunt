-- Add payment_method column to orders table
ALTER TABLE orders 
ADD COLUMN IF NOT EXISTS payment_method text;

-- Update existing orders to have a default value
UPDATE orders 
SET payment_method = 'cash' 
WHERE payment_method IS NULL;

-- Make the column required for future orders
ALTER TABLE orders 
ALTER COLUMN payment_method SET NOT NULL;