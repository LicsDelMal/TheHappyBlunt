/*
  # Add Coupons Management

  1. New Tables
    - `coupons`
      - `id` (uuid, primary key)
      - `code` (text, unique)
      - `name` (text)
      - `type` (text) - 'fixed' or 'percentage'
      - `value` (numeric)
      - `min_purchase` (numeric)
      - `max_uses` (integer)
      - `uses_count` (integer)
      - `start_date` (timestamptz)
      - `end_date` (timestamptz)
      - `is_active` (boolean)
      - `category_restrictions` (text[])
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `coupons` table
    - Add policies for admin management
*/

-- Create coupons table
CREATE TABLE coupons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  name text NOT NULL,
  type text NOT NULL CHECK (type IN ('fixed', 'percentage')),
  value numeric NOT NULL CHECK (value > 0),
  min_purchase numeric DEFAULT 0 CHECK (min_purchase >= 0),
  max_uses integer,
  uses_count integer DEFAULT 0,
  start_date timestamptz,
  end_date timestamptz,
  is_active boolean DEFAULT true,
  category_restrictions text[],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE coupons ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for all users"
  ON coupons FOR SELECT
  TO public
  USING (is_active = true AND (end_date IS NULL OR end_date > now()));

CREATE POLICY "Enable admin management"
  ON coupons FOR ALL
  TO authenticated
  USING (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin')
  WITH CHECK (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin');

-- Create indexes
CREATE INDEX idx_coupons_code ON coupons(code);
CREATE INDEX idx_coupons_active_dates ON coupons(is_active, start_date, end_date);

-- Create function to update timestamp
CREATE OR REPLACE FUNCTION update_coupon_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for timestamp update
CREATE TRIGGER update_coupon_timestamp
  BEFORE UPDATE ON coupons
  FOR EACH ROW
  EXECUTE FUNCTION update_coupon_timestamp();