-- Enable RLS on storage.objects if not already enabled
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Drop existing policies
DROP POLICY IF EXISTS "Public read access for site assets" ON storage.objects;
DROP POLICY IF EXISTS "Admin insert access for site assets" ON storage.objects;
DROP POLICY IF EXISTS "Admin update access for site assets" ON storage.objects;
DROP POLICY IF EXISTS "Admin delete access for site assets" ON storage.objects;

-- Create new policies with proper authentication checks
CREATE POLICY "Public read access for site assets"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'site-assets');

CREATE POLICY "Admin insert access for site assets"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'site-assets' AND
    auth.role() = 'authenticated' AND
    (auth.jwt() -> 'user_metadata' ->> 'username') = 'admin'
  );

CREATE POLICY "Admin update access for site assets"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'site-assets' AND
    auth.role() = 'authenticated' AND
    (auth.jwt() -> 'user_metadata' ->> 'username') = 'admin'
  );

CREATE POLICY "Admin delete access for site assets"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'site-assets' AND
    auth.role() = 'authenticated' AND
    (auth.jwt() -> 'user_metadata' ->> 'username') = 'admin'
  );