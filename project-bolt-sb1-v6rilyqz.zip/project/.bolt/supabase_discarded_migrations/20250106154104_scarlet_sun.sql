-- Update user_profiles policies
DROP POLICY IF EXISTS "Admin can manage profiles" ON user_profiles;

CREATE POLICY "Enable insert for admin users"
  ON user_profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.jwt() ->> 'email' = 'admin@thehappyblunt.com');

CREATE POLICY "Enable update for admin users"
  ON user_profiles FOR UPDATE
  TO authenticated
  USING (auth.jwt() ->> 'email' = 'admin@thehappyblunt.com')
  WITH CHECK (auth.jwt() ->> 'email' = 'admin@thehappyblunt.com');

CREATE POLICY "Enable delete for admin users"
  ON user_profiles FOR DELETE
  TO authenticated
  USING (auth.jwt() ->> 'email' = 'admin@thehappyblunt.com');

-- Add trigger to handle user profile updates
CREATE OR REPLACE FUNCTION handle_user_profile_update()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER user_profiles_update_timestamp
  BEFORE UPDATE ON user_profiles
  FOR EACH ROW
  EXECUTE FUNCTION handle_user_profile_update();