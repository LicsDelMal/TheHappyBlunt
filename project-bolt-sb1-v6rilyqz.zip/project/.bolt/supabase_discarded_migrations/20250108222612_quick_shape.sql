-- Drop existing policies
DROP POLICY IF EXISTS "Enable read access for all users" ON products;
DROP POLICY IF EXISTS "Enable insert for admin users" ON products;
DROP POLICY IF EXISTS "Enable update for admin users" ON products;
DROP POLICY IF EXISTS "Enable delete for admin users" ON products;

-- Create new simplified policies
CREATE POLICY "enable_read_for_all"
  ON products FOR SELECT
  TO public
  USING (true);

CREATE POLICY "enable_write_for_admin"
  ON products FOR ALL
  TO authenticated
  USING (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin')
  WITH CHECK (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin');

-- Ensure RLS is enabled
ALTER TABLE products ENABLE ROW LEVEL SECURITY;

-- Grant necessary permissions
GRANT ALL ON products TO authenticated;
GRANT SELECT ON products TO anon;