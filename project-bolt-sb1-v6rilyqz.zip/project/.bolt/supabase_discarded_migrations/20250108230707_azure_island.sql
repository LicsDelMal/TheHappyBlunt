-- Drop existing policies
DROP POLICY IF EXISTS "enable_categories_read" ON categories;
DROP POLICY IF EXISTS "enable_categories_write" ON categories;

-- Create new simplified policies
CREATE POLICY "allow_categories_read"
  ON categories FOR SELECT
  TO public
  USING (true);

CREATE POLICY "allow_categories_admin"
  ON categories FOR ALL
  TO authenticated
  USING ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com')
  WITH CHECK ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com');

-- Ensure RLS is enabled
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

-- Grant permissions
GRANT ALL ON categories TO authenticated;
GRANT SELECT ON categories TO anon;