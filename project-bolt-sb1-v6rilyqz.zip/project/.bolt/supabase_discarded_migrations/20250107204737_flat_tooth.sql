/*
  # Add site settings and storage configuration

  1. New Tables
    - `site_settings` for storing application configuration
      - General settings (site name, description, etc.)
      - Payment settings
      - Shipping settings
      - Notification settings
      - Security settings
      - Legal settings

  2. Storage
    - Create site-assets bucket for storing logos and other site assets
    - Set up appropriate security policies
*/

-- Create site_settings table
CREATE TABLE IF NOT EXISTS site_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  site_name text NOT NULL DEFAULT 'The Happy Blunt',
  description text,
  logo text,
  primary_color text DEFAULT '#047857',
  
  -- Payment settings
  payment_methods jsonb DEFAULT '[]'::jsonb,
  stripe_public_key text,
  stripe_secret_key text,
  
  -- Shipping settings
  shipping_zones jsonb DEFAULT '[]'::jsonb,
  free_shipping_threshold numeric DEFAULT 0,
  
  -- Notification settings
  email_notifications jsonb DEFAULT '{"orderConfirmation": true, "abandonedCart": true, "orderShipped": true}'::jsonb,
  email_sender text,
  email_template text,
  
  -- Security settings
  password_min_length integer DEFAULT 8,
  max_login_attempts integer DEFAULT 3,
  two_factor_auth boolean DEFAULT false,
  
  -- Legal settings
  terms_and_conditions text,
  privacy_policy text,
  age_verification boolean DEFAULT true,
  
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;

-- Create policy for admin access
CREATE POLICY "Enable full access for admin users" ON site_settings
  USING ((auth.jwt() -> 'user_metadata' ->> 'username') = 'admin')
  WITH CHECK ((auth.jwt() -> 'user_metadata' ->> 'username') = 'admin');

-- Create policy for public read access to certain fields
CREATE POLICY "Enable public read access to basic settings" ON site_settings
  FOR SELECT
  USING (true);

-- Create storage bucket for site assets if it doesn't exist
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name)
  VALUES ('site-assets', 'site-assets')
  ON CONFLICT (id) DO NOTHING;
END $$;

-- Set up storage policies
CREATE POLICY "Public read access for site assets"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'site-assets');

CREATE POLICY "Admin write access for site assets"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'site-assets' AND
    (auth.jwt() -> 'user_metadata' ->> 'username') = 'admin'
  );

CREATE POLICY "Admin update access for site assets"
  ON storage.objects FOR UPDATE
  USING (
    bucket_id = 'site-assets' AND
    (auth.jwt() -> 'user_metadata' ->> 'username') = 'admin'
  );

CREATE POLICY "Admin delete access for site assets"
  ON storage.objects FOR DELETE
  USING (
    bucket_id = 'site-assets' AND
    (auth.jwt() -> 'user_metadata' ->> 'username') = 'admin'
  );

-- Insert default settings
INSERT INTO site_settings (
  site_name,
  description
) VALUES (
  'The Happy Blunt',
  'Tu destino confiable para productos cannábicos de calidad'
) ON CONFLICT DO NOTHING;