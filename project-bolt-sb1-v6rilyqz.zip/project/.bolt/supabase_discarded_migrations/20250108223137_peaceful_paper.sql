-- Drop ALL existing policies
DROP POLICY IF EXISTS "products_read_policy" ON products;
DROP POLICY IF EXISTS "products_write_policy" ON products;
DROP POLICY IF EXISTS "enable_read_for_all" ON products;
DROP POLICY IF EXISTS "enable_write_for_admin" ON products;

-- Create simple policies
CREATE POLICY "allow_read"
  ON products FOR SELECT
  TO public
  USING (true);

CREATE POLICY "allow_admin_write"
  ON products FOR ALL 
  TO authenticated
  USING ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com')
  WITH CHECK ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com');

-- Ensure RLS is enabled
ALTER TABLE products ENABLE ROW LEVEL SECURITY;

-- Grant permissions
GRANT ALL ON products TO authenticated;
GRANT SELECT ON products TO anon;