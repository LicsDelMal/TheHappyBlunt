-- Drop existing table if it exists
DROP TABLE IF EXISTS categories CASCADE;

-- Create categories table
CREATE TABLE categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  parent_id uuid REFERENCES categories(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "allow_read"
  ON categories FOR SELECT
  TO public
  USING (true);

CREATE POLICY "allow_admin_write"
  ON categories FOR ALL 
  TO authenticated
  USING ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com')
  WITH CHECK ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com');

-- Insert main categories first
WITH inserted_main AS (
  INSERT INTO categories (name) 
  VALUES 
    ('Flor'),
    ('Vaporizadores')
  RETURNING id, name
),
-- Insert quality categories for Flor
inserted_qualities AS (
  INSERT INTO categories (name, parent_id)
  SELECT 
    quality,
    (SELECT id FROM inserted_main WHERE name = 'Flor')
  FROM unnest(ARRAY['Exótica', 'Premium', 'Alta Calidad', 'Standar']) AS quality
  RETURNING id, name
)
-- Insert weight categories for each quality
INSERT INTO categories (name, parent_id)
SELECT 
  weight,
  quality.id
FROM inserted_qualities quality
CROSS JOIN unnest(ARRAY['1Kg', '1/2Kg', '1/4Kg', 'Onza']) AS weight;

-- Insert Vaporizadores subcategories
INSERT INTO categories (name, parent_id)
SELECT 
  size,
  (SELECT id FROM categories WHERE name = 'Vaporizadores')
FROM unnest(ARRAY['1 Gramo', '2 Gramos']) AS size;

-- Add category_id to products table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'products' AND column_name = 'category_id'
  ) THEN
    ALTER TABLE products ADD COLUMN category_id uuid REFERENCES categories(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_categories_parent_id ON categories(parent_id);
CREATE INDEX IF NOT EXISTS idx_categories_name ON categories(name);
CREATE INDEX IF NOT EXISTS idx_products_category_id ON products(category_id);

-- Grant necessary permissions
GRANT ALL ON categories TO authenticated;
GRANT SELECT ON categories TO anon;

-- Verify the table exists and has data
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT FROM categories WHERE name = 'Flor'
  ) THEN
    RAISE EXCEPTION 'Categories table is empty or not properly initialized';
  END IF;
END $$;