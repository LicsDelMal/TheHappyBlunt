/*
  # Add sold count to products

  1. Changes
    - Add sold_count column to products table with default value of 0
    - Add index for better performance when sorting by sold_count
*/

-- Add sold_count column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'products' AND column_name = 'sold_count'
  ) THEN
    ALTER TABLE products ADD COLUMN sold_count integer DEFAULT 0;
    CREATE INDEX idx_products_sold_count ON products(sold_count DESC);
  END IF;
END $$;