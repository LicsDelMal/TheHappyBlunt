-- Drop existing policies
DROP POLICY IF EXISTS "orders_user_read" ON orders;
DROP POLICY IF EXISTS "orders_admin_all" ON orders;

-- Create new policies
CREATE POLICY "enable_user_read_own_orders"
  ON orders FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "enable_user_insert_own_orders"
  ON orders FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "enable_admin_all_orders"
  ON orders FOR ALL
  TO authenticated
  USING (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin')
  WITH CHECK (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin');

-- Grant necessary permissions
GRANT ALL ON orders TO authenticated;