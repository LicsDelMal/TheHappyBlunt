/*
  # User Management System

  1. New Tables
    - `user_profiles`: Extended user information
    - `user_activity_logs`: Track user actions
    - `login_attempts`: Track failed login attempts

  2. Security
    - Enable RLS on all tables
    - Add policies for admin access
*/

-- User Profiles table
CREATE TABLE user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users,
  full_name text,
  role text NOT NULL DEFAULT 'user',
  is_active boolean DEFAULT true,
  last_login timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- User Activity Logs
CREATE TABLE user_activity_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  action text NOT NULL,
  details jsonb,
  created_at timestamptz DEFAULT now()
);

-- Login Attempts
CREATE TABLE login_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  attempt_count integer DEFAULT 1,
  last_attempt timestamptz DEFAULT now(),
  is_blocked boolean DEFAULT false,
  blocked_until timestamptz
);

-- Enable RLS
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_activity_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE login_attempts ENABLE ROW LEVEL SECURITY;

-- Policies for user_profiles
CREATE POLICY "Users can view their own profile"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Admin can view all profiles"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (auth.jwt() ->> 'email' = 'admin@thehappyblunt.com');

CREATE POLICY "Admin can manage profiles"
  ON user_profiles FOR ALL
  TO authenticated
  USING (auth.jwt() ->> 'email' = 'admin@thehappyblunt.com');

-- Policies for activity logs
CREATE POLICY "Admin can view all logs"
  ON user_activity_logs FOR SELECT
  TO authenticated
  USING (auth.jwt() ->> 'email' = 'admin@thehappyblunt.com');

CREATE POLICY "Users can view their own logs"
  ON user_activity_logs FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Policies for login attempts
CREATE POLICY "Admin can view login attempts"
  ON login_attempts FOR SELECT
  TO authenticated
  USING (auth.jwt() ->> 'email' = 'admin@thehappyblunt.com');