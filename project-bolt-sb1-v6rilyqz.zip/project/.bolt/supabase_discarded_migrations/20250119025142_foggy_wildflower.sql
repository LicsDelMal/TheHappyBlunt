-- First, clear existing categories
DELETE FROM categories;

-- Insert main categories
INSERT INTO categories (name) VALUES
  ('Flor'),
  ('Vaporizadores')
RETURNING id, name;

-- Insert subcategories for Flor
WITH flor AS (
  SELECT id FROM categories WHERE name = 'Flor'
)
INSERT INTO categories (name, parent_id)
SELECT name, flor.id
FROM flor, unnest(ARRAY['Exótica', 'Premium', 'Alta Calidad', 'Standar']) AS name;

-- Insert weight subcategories for each Flor quality
WITH qualities AS (
  SELECT id, name 
  FROM categories 
  WHERE parent_id = (SELECT id FROM categories WHERE name = 'Flor')
)
INSERT INTO categories (name, parent_id)
SELECT weight, qualities.id
FROM qualities,
unnest(ARRAY['1Kg', '1/2Kg', '1/4Kg', 'Onza']) AS weight;

-- Insert subcategories for Vaporizadores
WITH vapes AS (
  SELECT id FROM categories WHERE name = 'Vaporizadores'
)
INSERT INTO categories (name, parent_id)
SELECT name, vapes.id
FROM vapes,
unnest(ARRAY['1 Gramo', '2 Gramos']) AS name;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_categories_hierarchy 
ON categories(parent_id, name);

-- Update products to use new category structure
UPDATE products
SET category = NULL
WHERE category NOT IN (
  SELECT name FROM categories
);