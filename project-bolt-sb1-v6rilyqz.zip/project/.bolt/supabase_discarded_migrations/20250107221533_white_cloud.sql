-- Drop existing policies
DROP POLICY IF EXISTS "Enable read access for all users" ON coupons;
DROP POLICY IF EXISTS "Enable admin management" ON coupons;

-- Create new simplified policies
CREATE POLICY "Public read access for coupons"
  ON coupons FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Admin full access for coupons"
  ON coupons FOR ALL
  TO authenticated
  USING (auth.role() = 'authenticated' AND (auth.jwt() -> 'user_metadata' ->> 'username') = 'admin')
  WITH CHECK (auth.role() = 'authenticated' AND (auth.jwt() -> 'user_metadata' ->> 'username') = 'admin');

-- Ensure RLS is enabled
ALTER TABLE coupons ENABLE ROW LEVEL SECURITY;

-- Grant necessary permissions
GRANT ALL ON coupons TO authenticated;