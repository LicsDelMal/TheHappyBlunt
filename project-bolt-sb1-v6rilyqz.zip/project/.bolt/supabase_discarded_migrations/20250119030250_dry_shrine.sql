-- Drop existing table if it exists
DROP TABLE IF EXISTS categories CASCADE;

-- Create categories table
CREATE TABLE categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  parent_id uuid REFERENCES categories(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "allow_read"
  ON categories FOR SELECT
  TO public
  USING (true);

CREATE POLICY "allow_admin_write"
  ON categories FOR ALL 
  TO authenticated
  USING ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com')
  WITH CHECK ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com');

-- Insert main categories
INSERT INTO categories (name) VALUES
  ('Flor'),
  ('Vaporizadores')
ON CONFLICT (name) DO NOTHING;

-- Get Flor category ID and insert quality subcategories
DO $$ 
DECLARE
  flor_id uuid;
BEGIN
  SELECT id INTO flor_id FROM categories WHERE name = 'Flor';
  
  -- Insert quality subcategories
  INSERT INTO categories (name, parent_id)
  VALUES 
    ('Exótica', flor_id),
    ('Premium', flor_id),
    ('Alta Calidad', flor_id),
    ('Standar', flor_id)
  ON CONFLICT (name) DO NOTHING;
END $$;

-- Get quality categories and insert weight subcategories
DO $$
DECLARE
  quality_rec RECORD;
BEGIN
  FOR quality_rec IN (
    SELECT id FROM categories WHERE parent_id = (SELECT id FROM categories WHERE name = 'Flor')
  ) LOOP
    INSERT INTO categories (name, parent_id)
    VALUES 
      ('1Kg', quality_rec.id),
      ('1/2Kg', quality_rec.id),
      ('1/4Kg', quality_rec.id),
      ('Onza', quality_rec.id)
    ON CONFLICT (name) DO NOTHING;
  END LOOP;
END $$;

-- Get Vaporizadores category ID and insert size subcategories
DO $$
DECLARE
  vapes_id uuid;
BEGIN
  SELECT id INTO vapes_id FROM categories WHERE name = 'Vaporizadores';
  
  INSERT INTO categories (name, parent_id)
  VALUES 
    ('1 Gramo', vapes_id),
    ('2 Gramos', vapes_id)
  ON CONFLICT (name) DO NOTHING;
END $$;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_categories_parent_id ON categories(parent_id);
CREATE INDEX IF NOT EXISTS idx_categories_name ON categories(name);

-- Grant necessary permissions
GRANT ALL ON categories TO authenticated;
GRANT SELECT ON categories TO anon;