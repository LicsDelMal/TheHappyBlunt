-- Add ON DELETE CASCADE to cart_items foreign key
ALTER TABLE cart_items
DROP CONSTRAINT cart_items_product_id_fkey,
ADD CONSTRAINT cart_items_product_id_fkey 
  FOREIGN KEY (product_id) 
  REFERENCES products(id) 
  ON DELETE CASCADE;