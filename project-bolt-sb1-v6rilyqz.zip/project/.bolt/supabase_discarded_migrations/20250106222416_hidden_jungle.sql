/*
  # Update authentication system
  
  1. Changes
    - Add username support
    - Update policies for username-based authentication
    - Update user creation handler
*/

-- Drop existing policies first
DROP POLICY IF EXISTS "Enable insert for admin users" ON products;
DROP POLICY IF EXISTS "Enable update for admin users" ON products;
DROP POLICY IF EXISTS "Enable delete for admin users" ON products;

-- Update user_profiles table
ALTER TABLE user_profiles 
ADD COLUMN IF NOT EXISTS username text UNIQUE;

-- Create new policies
CREATE POLICY "Enable insert for admin users"
  ON products FOR INSERT
  TO authenticated
  WITH CHECK ((auth.jwt() -> 'user_metadata' ->> 'username') = 'admin');

CREATE POLICY "Enable update for admin users"
  ON products FOR UPDATE
  TO authenticated
  USING ((auth.jwt() -> 'user_metadata' ->> 'username') = 'admin')
  WITH CHECK ((auth.jwt() -> 'user_metadata' ->> 'username') = 'admin');

CREATE POLICY "Enable delete for admin users"
  ON products FOR DELETE
  TO authenticated
  USING ((auth.jwt() -> 'user_metadata' ->> 'username') = 'admin');

-- Update user creation handler
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.user_profiles (id, username, role, is_active)
  VALUES (
    NEW.id,
    NEW.raw_user_meta_data->>'username',
    CASE 
      WHEN NEW.raw_user_meta_data->>'username' = 'admin' THEN 'admin'
      ELSE 'user'
    END,
    true
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;