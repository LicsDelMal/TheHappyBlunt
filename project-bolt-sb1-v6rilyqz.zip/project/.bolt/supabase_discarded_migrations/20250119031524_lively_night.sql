-- First, disable referential triggers temporarily to avoid cascading issues
ALTER TABLE categories DISABLE TRIGGER ALL;
ALTER TABLE products DISABLE TRIGGER ALL;

-- Clear all category associations from products
UPDATE products SET category_id = NULL;

-- Delete all categories
DELETE FROM categories;

-- Re-enable triggers
ALTER TABLE categories ENABLE TRIGGER ALL;
ALTER TABLE products ENABLE TRIGGER ALL;

-- Verify categories were deleted
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM categories) THEN
    RAISE EXCEPTION 'Categories were not properly deleted';
  END IF;
END $$;