-- Drop existing policies
DROP POLICY IF EXISTS "Enable full access for admin users" ON site_settings;
DROP POLICY IF EXISTS "Enable public read access to basic settings" ON site_settings;

-- Create new policies with proper authentication checks
CREATE POLICY "Admin can manage site settings"
  ON site_settings
  USING (auth.role() = 'authenticated' AND (auth.jwt() -> 'user_metadata' ->> 'username') = 'admin')
  WITH CHECK (auth.role() = 'authenticated' AND (auth.jwt() -> 'user_metadata' ->> 'username') = 'admin');

CREATE POLICY "Public can read site settings"
  ON site_settings FOR SELECT
  TO public
  USING (true);

-- Insert default settings if none exist
INSERT INTO site_settings (
  "siteName",
  description,
  "primaryColor",
  "emailNotifications",
  "passwordMinLength",
  "maxLoginAttempts",
  "twoFactorAuth",
  "ageVerification"
) VALUES (
  'The Happy Blunt',
  'Tu destino confiable para productos cannábicos de calidad',
  '#047857',
  '{"orderConfirmation": true, "abandonedCart": true, "orderShipped": true}'::jsonb,
  8,
  3,
  false,
  true
) ON CONFLICT DO NOTHING;