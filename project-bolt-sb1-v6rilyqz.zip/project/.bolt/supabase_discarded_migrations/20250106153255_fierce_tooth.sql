/*
  # Fix Admin Permissions and Storage

  1. Changes
    - Update RLS policies for products table
    - Create storage bucket for product images
    - Add proper admin role checks
  
  2. Security
    - Enable proper admin access to products
    - Set up storage permissions
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can view products" ON products;
DROP POLICY IF EXISTS "Admins can manage products" ON products;

-- Create new policies
CREATE POLICY "Enable read access for all users"
  ON products FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable insert for admin users"
  ON products FOR INSERT
  TO authenticated
  WITH CHECK (auth.jwt() ->> 'email' = 'admin@thehappyblunt.com');

CREATE POLICY "Enable update for admin users"
  ON products FOR UPDATE
  TO authenticated
  USING (auth.jwt() ->> 'email' = 'admin@thehappyblunt.com')
  WITH CHECK (auth.jwt() ->> 'email' = 'admin@thehappyblunt.com');

CREATE POLICY "Enable delete for admin users"
  ON products FOR DELETE
  TO authenticated
  USING (auth.jwt() ->> 'email' = 'admin@thehappyblunt.com');

-- Create storage bucket if it doesn't exist
DO $$
BEGIN
  INSERT INTO storage.buckets (id, name)
  VALUES ('product-images', 'product-images')
  ON CONFLICT (id) DO NOTHING;
END $$;

-- Set up storage policies
CREATE POLICY "Public read access"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'product-images');

CREATE POLICY "Admin insert access"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'product-images' AND
    auth.jwt() ->> 'email' = 'admin@thehappyblunt.com'
  );

CREATE POLICY "Admin update access"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'product-images' AND
    auth.jwt() ->> 'email' = 'admin@thehappyblunt.com'
  );

CREATE POLICY "Admin delete access"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'product-images' AND
    auth.jwt() ->> 'email' = 'admin@thehappyblunt.com'
  );