-- Drop existing policies
DROP POLICY IF EXISTS "Public read access for site assets" ON storage.objects;
DROP POLICY IF EXISTS "Admin insert access for site assets" ON storage.objects;
DROP POLICY IF EXISTS "Admin update access for site assets" ON storage.objects;
DROP POLICY IF EXISTS "Admin delete access for site assets" ON storage.objects;

-- Update bucket configuration
UPDATE storage.buckets 
SET public = true,
    file_size_limit = 5242880, -- 5MB
    allowed_mime_types = ARRAY['image/jpeg', 'image/png', 'image/webp']
WHERE id = 'site-assets';

-- Create simpler policies with less restrictive checks
CREATE POLICY "Public read access for site assets"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'site-assets');

CREATE POLICY "Admin write access for site assets"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'site-assets');

CREATE POLICY "Admin update access for site assets"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'site-assets');

CREATE POLICY "Admin delete access for site assets"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'site-assets');