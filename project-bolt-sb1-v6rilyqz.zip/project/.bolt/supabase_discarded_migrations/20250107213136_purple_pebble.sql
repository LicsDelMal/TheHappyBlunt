/*
  # Optimized Schema and Policies

  1. Schema Updates
    - Consolidates all necessary table modifications
    - Adds proper indexes for performance
    - Updates storage configuration
  
  2. Security
    - Simplifies RLS policies
    - Improves authentication checks
    - Optimizes access control
*/

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Anyone can read active profiles" ON user_profiles;
DROP POLICY IF EXISTS "Users can read their own profile" ON user_profiles;
DROP POLICY IF EXISTS "Admin can manage profiles" ON user_profiles;
DROP POLICY IF EXISTS "Enable read access for own profile" ON user_profiles;
DROP POLICY IF EXISTS "Enable read access for admins" ON user_profiles;
DROP POLICY IF EXISTS "Enable write access for admins" ON user_profiles;
DROP POLICY IF EXISTS "Enable basic read access" ON user_profiles;
DROP POLICY IF EXISTS "Enable admin write access" ON user_profiles;

-- Update storage configuration
UPDATE storage.buckets 
SET public = true,
    file_size_limit = 5242880, -- 5MB
    allowed_mime_types = ARRAY['image/jpeg', 'image/png', 'image/webp']
WHERE id = 'site-assets';

-- Create optimized indexes
CREATE INDEX IF NOT EXISTS idx_user_profiles_id_role ON user_profiles(id, role);
CREATE INDEX IF NOT EXISTS idx_user_profiles_active ON user_profiles(is_active);

-- Create simplified RLS policies
CREATE POLICY "basic_read_access"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (
    id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE id = auth.uid()
      AND raw_user_meta_data->>'username' = 'admin'
    )
  );

CREATE POLICY "admin_write_access"
  ON user_profiles FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE id = auth.uid()
      AND raw_user_meta_data->>'username' = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM auth.users
      WHERE id = auth.uid()
      AND raw_user_meta_data->>'username' = 'admin'
    )
  );

-- Optimize user creation function
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  v_username text;
  v_is_admin boolean;
BEGIN
  -- Extract username
  v_username := NEW.raw_user_meta_data->>'username';
  
  -- Validate username
  IF v_username IS NULL THEN
    RAISE EXCEPTION 'Username is required';
  END IF;

  -- Check if admin
  v_is_admin := v_username = 'admin';

  -- Create profile
  INSERT INTO public.user_profiles (
    id,
    username,
    role,
    is_active,
    last_login
  ) VALUES (
    NEW.id,
    v_username,
    CASE WHEN v_is_admin THEN 'admin' ELSE 'user' END,
    v_is_admin, -- Only admin starts active
    CURRENT_TIMESTAMP
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recreate trigger
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Storage policies
DROP POLICY IF EXISTS "Public read access for site assets" ON storage.objects;
DROP POLICY IF EXISTS "Admin write access for site assets" ON storage.objects;
DROP POLICY IF EXISTS "Admin update access for site assets" ON storage.objects;
DROP POLICY IF EXISTS "Admin delete access for site assets" ON storage.objects;

CREATE POLICY "storage_read_access"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'site-assets');

CREATE POLICY "storage_write_access"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'site-assets' AND
    auth.jwt() -> 'user_metadata' ->> 'username' = 'admin'
  );

CREATE POLICY "storage_update_access"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'site-assets' AND
    auth.jwt() -> 'user_metadata' ->> 'username' = 'admin'
  );

CREATE POLICY "storage_delete_access"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'site-assets' AND
    auth.jwt() -> 'user_metadata' ->> 'username' = 'admin'
  );

-- Update statistics
ANALYZE user_profiles;
ANALYZE auth.users;