-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can view categories" ON categories;
DROP POLICY IF EXISTS "Admins can manage categories" ON categories;

-- Create new simplified policies
CREATE POLICY "enable_categories_read"
  ON categories FOR SELECT
  TO public
  USING (true);

CREATE POLICY "enable_categories_write"
  ON categories FOR ALL
  TO authenticated
  USING (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin')
  WITH CHECK (auth.jwt() -> 'user_metadata' ->> 'username' = 'admin');

-- Ensure RLS is enabled
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

-- Grant necessary permissions
GRANT ALL ON categories TO authenticated;
GRANT SELECT ON categories TO anon;

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_categories_name ON categories(name);