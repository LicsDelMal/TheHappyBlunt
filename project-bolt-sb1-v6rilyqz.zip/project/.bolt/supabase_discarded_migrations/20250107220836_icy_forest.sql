-- Delete all existing rows
DELETE FROM site_settings;

-- Insert a single row with default values
INSERT INTO site_settings (
  "siteName",
  description,
  "primaryColor",
  "paymentMethods",
  "shippingZones",
  "freeShippingThreshold",
  "emailNotifications",
  "passwordMinLength",
  "maxLoginAttempts",
  "twoFactorAuth",
  "ageVerification"
) VALUES (
  'The Happy Blunt',
  'Tu destino confiable para productos cannábicos de calidad',
  '#047857',
  '[]'::jsonb,
  '[]'::jsonb,
  0,
  '{"orderConfirmation": true, "abandonedCart": true, "orderShipped": true}'::jsonb,
  8,
  3,
  false,
  true
);

-- Add a constraint to ensure only one row exists
ALTER TABLE site_settings ADD CONSTRAINT site_settings_single_row UNIQUE ("siteName");