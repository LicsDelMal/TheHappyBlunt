/*
  # Fix Categories RLS Policies

  1. Changes
    - Drop existing RLS policies
    - Create new policies that check user role correctly
    - Add function to check if user is admin

  2. Security
    - Only admins can modify categories
    - Everyone can view categories
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Categories are viewable by everyone" ON categories;
DROP POLICY IF EXISTS "Categories are editable by admin" ON categories;

-- Create function to check if user is admin
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1
    FROM user_profiles
    WHERE id = auth.uid()
    AND role = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create new policies
CREATE POLICY "Categories are viewable by everyone"
ON public.categories
FOR SELECT
USING (true);

CREATE POLICY "Categories are insertable by admin"
ON public.categories
FOR INSERT
TO authenticated
WITH CHECK (is_admin());

CREATE POLICY "Categories are updatable by admin"
ON public.categories
FOR UPDATE
TO authenticated
USING (is_admin())
WITH CHECK (is_admin());

CREATE POLICY "Categories are deletable by admin"
ON public.categories
FOR DELETE
TO authenticated
USING (is_admin());

-- Grant execute permission on the function
GRANT EXECUTE ON FUNCTION public.is_admin TO authenticated;