/*
  # Add Cascade Delete for Orders

  1. Changes
    - Modify foreign key constraints to use ON DELETE CASCADE for:
      - order_items
      - order_status_history
      - cart_items
    - This ensures all related records are automatically deleted when an order is deleted

  2. Security
    - Maintains existing RLS policies
    - No changes to access control
*/

-- Drop existing foreign key constraints
ALTER TABLE IF EXISTS order_items
  DROP CONSTRAINT IF EXISTS order_items_order_id_fkey;

ALTER TABLE IF EXISTS order_status_history
  DROP CONSTRAINT IF EXISTS order_status_history_order_id_fkey;

-- Recreate foreign key constraints with CASCADE
ALTER TABLE order_items
  ADD CONSTRAINT order_items_order_id_fkey
  FOREIGN KEY (order_id)
  REFERENCES orders(id)
  ON DELETE CASCADE;

ALTER TABLE order_status_history
  ADD CONSTRAINT order_status_history_order_id_fkey
  FOREIGN KEY (order_id)
  REFERENCES orders(id)
  ON DELETE CASCADE;

-- Add comment explaining the cascade behavior
COMMENT ON CONSTRAINT order_items_order_id_fkey ON order_items IS 
  'Automatically deletes order items when the parent order is deleted';

COMMENT ON CONSTRAINT order_status_history_order_id_fkey ON order_status_history IS 
  'Automatically deletes status history when the parent order is deleted';