-- Update logo URL in site_settings table
UPDATE site_settings
SET 
  logo = 'https://pdfclclvzeamwwwcbtjn.supabase.co/storage/v1/object/public/product-images//logo.png',
  navbar_logo = 'https://pdfclclvzeamwwwcbtjn.supabase.co/storage/v1/object/public/product-images//logo.png',
  home_logo = 'https://pdfclclvzeamwwwcbtjn.supabase.co/storage/v1/object/public/product-images//logo.png'
WHERE id = (SELECT id FROM site_settings LIMIT 1);

-- Insert if no record exists
INSERT INTO site_settings (logo, navbar_logo, home_logo)
SELECT 
  'https://pdfclclvzeamwwwcbtjn.supabase.co/storage/v1/object/public/product-images//logo.png',
  'https://pdfclclvzeamwwwcbtjn.supabase.co/storage/v1/object/public/product-images//logo.png',
  'https://pdfclclvzeamwwwcbtjn.supabase.co/storage/v1/object/public/product-images//logo.png'
WHERE NOT EXISTS (SELECT 1 FROM site_settings);