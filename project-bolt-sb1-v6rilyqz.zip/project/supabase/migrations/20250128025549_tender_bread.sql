/*
  # Fix User Profiles RLS Policies

  1. Changes
    - Drop existing RLS policies
    - Create new RLS policies for user_profiles table
    - Add function to check if user is admin
    
  2. Security
    - Enable RLS on user_profiles table
    - Add policies for:
      - Select: Users can read their own profile, admins can read all
      - Insert: Service role can create profiles
      - Update: Users can update their own profile, admins can update all
      - Delete: Only admins can delete profiles
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view own profile" ON user_profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON user_profiles;
DROP POLICY IF EXISTS "Admins can manage all profiles" ON user_profiles;

-- Create admin check function if it doesn't exist
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean AS $$
BEGIN
  -- Check if the user has admin role in user_profiles
  RETURN EXISTS (
    SELECT 1
    FROM user_profiles
    WHERE id = auth.uid()
    AND role = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Enable RLS
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

-- Create new policies
CREATE POLICY "Users can read own profile"
ON user_profiles
FOR SELECT
USING (
  auth.uid() = id 
  OR 
  is_admin() 
  OR 
  (SELECT current_setting('role') = 'service_role')
);

CREATE POLICY "Service role can create profiles"
ON user_profiles
FOR INSERT
WITH CHECK (
  (SELECT current_setting('role') = 'service_role')
  OR
  auth.uid() = id
);

CREATE POLICY "Users can update own profile"
ON user_profiles
FOR UPDATE
USING (
  auth.uid() = id 
  OR 
  is_admin()
)
WITH CHECK (
  auth.uid() = id 
  OR 
  is_admin()
);

CREATE POLICY "Only admins can delete profiles"
ON user_profiles
FOR DELETE
USING (is_admin());

-- Grant necessary permissions
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT ALL ON public.user_profiles TO authenticated;
GRANT SELECT ON public.user_profiles TO anon;
GRANT EXECUTE ON FUNCTION public.is_admin TO authenticated;

-- Add comments
COMMENT ON POLICY "Users can read own profile" ON user_profiles IS 'Users can read their own profile, admins can read all profiles';
COMMENT ON POLICY "Service role can create profiles" ON user_profiles IS 'Only the service role can create new profiles';
COMMENT ON POLICY "Users can update own profile" ON user_profiles IS 'Users can update their own profile, admins can update any profile';
COMMENT ON POLICY "Only admins can delete profiles" ON user_profiles IS 'Only administrators can delete user profiles';