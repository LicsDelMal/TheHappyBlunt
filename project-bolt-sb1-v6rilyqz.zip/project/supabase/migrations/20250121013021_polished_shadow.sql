/*
  # Set up product categories hierarchy
  
  1. New Categories
    - Main categories: FLOR, COMESTIBLES, EXTRACTOS, INSUMOS, PSICOTROPICOS
    - Subcategories and nested categories with proper hierarchy
    - Unique naming scheme to avoid duplicates
  
  2. Security
    - Inherits existing RLS policies
*/

-- Insert main categories
INSERT INTO categories (name, level, display_order) VALUES
-- Main categories (level 1)
('FLOR', 1, 10),
('COMESTIBLES', 1, 20),
('EXTRACTOS', 1, 30),
('INSUMOS', 1, 40),
('PSICOTROPICOS', 1, 50);

-- Helper function to get category ID
CREATE OR REPLACE FUNCTION get_category_id(cat_name text) 
RETURNS uuid AS $$
  SELECT id FROM categories WHERE name = cat_name LIMIT 1;
$$ LANGUAGE SQL;

-- Insert FLOR subcategories
DO $$ 
DECLARE
  flor_id uuid := get_category_id('FLOR');
  kg_id uuid;
  halfkg_id uuid;
  quarterkg_id uuid;
  oz_id uuid;
  toques_id uuid;
BEGIN
  -- Cantidades (level 2)
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('1KG', flor_id, 2, 10) RETURNING id INTO kg_id;
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('1/2KG', flor_id, 2, 20) RETURNING id INTO halfkg_id;
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('1/4KG', flor_id, 2, 30) RETURNING id INTO quarterkg_id;
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('ONZAS', flor_id, 2, 40) RETURNING id INTO oz_id;
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('TOQUES', flor_id, 2, 50) RETURNING id INTO toques_id;

  -- Calidades para cada cantidad (level 3)
  -- 1KG
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('Regular 1KG', kg_id, 3, 10),
  ('Quality 1KG', kg_id, 3, 20),
  ('Exotica 1KG', kg_id, 3, 30);

  -- 1/2KG
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('Regular 1/2KG', halfkg_id, 3, 10),
  ('Quality 1/2KG', halfkg_id, 3, 20),
  ('Exotica 1/2KG', halfkg_id, 3, 30);

  -- 1/4KG
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('Regular 1/4KG', quarterkg_id, 3, 10),
  ('Quality 1/4KG', quarterkg_id, 3, 20),
  ('Exotica 1/4KG', quarterkg_id, 3, 30);

  -- Onzas
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('Regular OZ', oz_id, 3, 10),
  ('Quality OZ', oz_id, 3, 20),
  ('Exotica OZ', oz_id, 3, 30),
  ('Hydro OZ', oz_id, 3, 40),
  ('Indoor OZ', oz_id, 3, 50),
  ('Greenhouse OZ', oz_id, 3, 60);

  -- Toques
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('12na Natural', toques_id, 3, 10),
  ('12na Empanizada', toques_id, 3, 20),
  ('12na de Hydro', toques_id, 3, 30),
  ('Blunt Empanizado', toques_id, 3, 40),
  ('Baby Jeetter', toques_id, 3, 50);
END $$;

-- Insert COMESTIBLES subcategories
DO $$ 
DECLARE
  comestibles_id uuid := get_category_id('COMESTIBLES');
BEGIN
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('Americanos', comestibles_id, 2, 10),
  ('Caseros', comestibles_id, 2, 20);
END $$;

-- Insert EXTRACTOS subcategories
DO $$ 
DECLARE
  extractos_id uuid := get_category_id('EXTRACTOS');
  cartuchos_id uuid;
  desechables_id uuid;
  solidos_id uuid;
BEGIN
  -- Level 2
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('Cartuchos', extractos_id, 2, 10) RETURNING id INTO cartuchos_id;
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('Desechables', extractos_id, 2, 20) RETURNING id INTO desechables_id;
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('Solidos', extractos_id, 2, 30) RETURNING id INTO solidos_id;

  -- Cartuchos subcategories
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('Originales Cart', cartuchos_id, 3, 10),
  ('De Lab 2gr Cart', cartuchos_id, 3, 20);

  -- Desechables subcategories
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('Originales 1g', desechables_id, 3, 10),
  ('Originales 2g', desechables_id, 3, 20),
  ('Originales 3g', desechables_id, 3, 30),
  ('De Lab 1g', desechables_id, 3, 40),
  ('De Lab 2g', desechables_id, 3, 50),
  ('De Lab 3g', desechables_id, 3, 60);

  -- Solidos subcategories
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('Solid Wax', solidos_id, 3, 10),
  ('Rossin', solidos_id, 3, 20);
END $$;

-- Insert INSUMOS subcategories
DO $$ 
DECLARE
  insumos_id uuid := get_category_id('INSUMOS');
BEGIN
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('Para Wax', insumos_id, 2, 10),
  ('Para Weed', insumos_id, 2, 20);
END $$;

-- Insert PSICOTROPICOS subcategories
DO $$ 
DECLARE
  psicotropicos_id uuid := get_category_id('PSICOTROPICOS');
  lsd_id uuid;
  hongos_id uuid;
BEGIN
  -- Level 2
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('LSD', psicotropicos_id, 2, 10) RETURNING id INTO lsd_id;
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('Hongos', psicotropicos_id, 2, 20) RETURNING id INTO hongos_id;

  -- LSD subcategories
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('Triangulo', lsd_id, 3, 10),
  ('Cuadro', lsd_id, 3, 20),
  ('Gel tap', lsd_id, 3, 30);

  -- Hongos subcategories
  INSERT INTO categories (name, parent_id, level, display_order) VALUES
  ('Bolsa 2gr', hongos_id, 3, 10),
  ('Pastilla microdosis', hongos_id, 3, 20),
  ('Chocohongos', hongos_id, 3, 30);
END $$;

-- Drop helper function
DROP FUNCTION get_category_id;