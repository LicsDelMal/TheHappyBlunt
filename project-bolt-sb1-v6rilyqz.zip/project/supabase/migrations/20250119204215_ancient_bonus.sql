/*
  # Create Categories Table

  1. New Tables
    - `categories`
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `description` (text)
      - `parent_id` (uuid, self-referential foreign key)
      - `level` (integer)
      - `display_order` (integer)
      - `is_active` (boolean)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for read and write access
    - Add function for updating timestamps
*/

-- Create categories table
CREATE TABLE IF NOT EXISTS public.categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  parent_id uuid REFERENCES public.categories(id) ON DELETE CASCADE,
  level integer NOT NULL DEFAULT 1,
  display_order integer DEFAULT 0,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT categories_name_unique UNIQUE(name)
);

-- Enable RLS
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Categories are viewable by everyone" 
  ON public.categories
  FOR SELECT 
  USING (true);

CREATE POLICY "Categories are editable by admin" 
  ON public.categories
  FOR ALL 
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin')
  WITH CHECK (auth.jwt() ->> 'role' = 'admin');

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for updating timestamp
CREATE TRIGGER set_updated_at
  BEFORE UPDATE ON public.categories
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

-- Add table comments
COMMENT ON TABLE public.categories IS 'Tabla para almacenar las categorías de productos';
COMMENT ON COLUMN public.categories.id IS 'Identificador único de la categoría';
COMMENT ON COLUMN public.categories.name IS 'Nombre de la categoría';
COMMENT ON COLUMN public.categories.description IS 'Descripción detallada de la categoría';
COMMENT ON COLUMN public.categories.parent_id IS 'ID de la categoría padre (para categorías jerárquicas)';
COMMENT ON COLUMN public.categories.level IS 'Nivel en la jerarquía de categorías';
COMMENT ON COLUMN public.categories.display_order IS 'Orden de visualización';
COMMENT ON COLUMN public.categories.is_active IS 'Estado de la categoría (activo/inactivo)';
COMMENT ON COLUMN public.categories.created_at IS 'Fecha de creación del registro';
COMMENT ON COLUMN public.categories.updated_at IS 'Fecha de última actualización del registro';

-- Create indexes for better performance
CREATE INDEX idx_categories_parent_id ON public.categories(parent_id);
CREATE INDEX idx_categories_level ON public.categories(level);
CREATE INDEX idx_categories_display_order ON public.categories(display_order);
CREATE INDEX idx_categories_is_active ON public.categories(is_active);

-- Grant permissions
GRANT ALL ON public.categories TO authenticated;
GRANT SELECT ON public.categories TO anon;