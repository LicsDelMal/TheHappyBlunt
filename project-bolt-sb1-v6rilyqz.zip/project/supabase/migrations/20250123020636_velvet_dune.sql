/*
  # Fix Order Status Constraint

  1. Changes
    - Drop existing status check constraint if exists
    - Add new status check constraint with correct values
    - Update any existing orders to use new status values
    - Add status enum type for better type safety

  2. Security
    - Maintains existing RLS policies
    - No changes to access control
*/

-- Create enum type for order status
DO $$ BEGIN
  CREATE TYPE order_status AS ENUM (
    'pendiente',
    'en_proceso',
    'enviado',
    'entregado',
    'cancelado'
  );
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Drop existing check constraint if exists
ALTER TABLE orders
  DROP CONSTRAINT IF EXISTS orders_status_check;

-- Update any existing orders to use new status values
UPDATE orders
  SET status = 'pendiente' WHERE status = 'pending';
UPDATE orders
  SET status = 'en_proceso' WHERE status = 'processing';
UPDATE orders
  SET status = 'enviado' WHERE status = 'shipped';
UPDATE orders
  SET status = 'entregado' WHERE status = 'delivered';
UPDATE orders
  SET status = 'cancelado' WHERE status = 'cancelled';

-- Add new check constraint
ALTER TABLE orders
  ADD CONSTRAINT orders_status_check 
  CHECK (status IN ('pendiente', 'en_proceso', 'enviado', 'entregado', 'cancelado'));

-- Add comment explaining valid status values
COMMENT ON COLUMN orders.status IS 
  'Estado del pedido: pendiente, en_proceso, enviado, entregado, cancelado';