-- Update site_settings table to support separate logos
ALTER TABLE site_settings 
  ADD COLUMN IF NOT EXISTS navbar_logo text,
  ADD COLUMN IF NOT EXISTS home_logo text;

-- If there's an existing logo, copy it to navbar_logo
UPDATE site_settings 
SET navbar_logo = logo 
WHERE logo IS NOT NULL AND navbar_logo IS NULL;