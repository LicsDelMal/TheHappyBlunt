/*
  # Add Soft Delete for Products

  1. Changes
    - Add deleted_at column to products table
    - Create soft_delete_product function
    - Update RLS policies to handle soft deleted records
    
  2. Security
    - Only admins can soft delete products
    - Soft deleted products are hidden from normal queries
*/

-- Add deleted_at column if it doesn't exist
ALTER TABLE products 
ADD COLUMN IF NOT EXISTS deleted_at timestamptz;

-- Create index for better performance on deleted_at queries
CREATE INDEX IF NOT EXISTS idx_products_deleted_at 
ON products(deleted_at);

-- Create soft delete function
CREATE OR REPLACE FUNCTION public.soft_delete_product(product_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Check if user is admin
  IF NOT EXISTS (
    SELECT 1 
    FROM user_profiles 
    WHERE id = auth.uid() 
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Only administrators can delete products';
  END IF;

  -- Perform soft delete
  UPDATE products
  SET 
    deleted_at = CURRENT_TIMESTAMP,
    is_visible = false
  WHERE id = product_id
  AND deleted_at IS NULL;

  -- Return true if a row was updated
  RETURN FOUND;
END;
$$;

-- Update existing policies or create new ones
DROP POLICY IF EXISTS "Products are viewable by everyone" ON products;
CREATE POLICY "Products are viewable by everyone"
ON products
FOR SELECT
USING (
  CASE 
    WHEN auth.uid() IS NULL OR NOT EXISTS (
      SELECT 1 FROM user_profiles 
      WHERE id = auth.uid() 
      AND role = 'admin'
    ) THEN
      deleted_at IS NULL AND is_visible = true
    ELSE
      true -- Admins can see all products
  END
);

-- Grant execute permission on the function
GRANT EXECUTE ON FUNCTION public.soft_delete_product TO authenticated;

-- Add helpful comments
COMMENT ON COLUMN products.deleted_at IS 'Timestamp when the product was soft deleted';
COMMENT ON FUNCTION public.soft_delete_product IS 'Soft deletes a product by setting deleted_at timestamp and making it invisible';