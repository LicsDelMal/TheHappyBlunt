-- Create categories table with improved structure
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  parent_id uuid REFERENCES categories(id) ON DELETE CASCADE,
  level integer NOT NULL DEFAULT 1,
  display_order integer DEFAULT 0,
  status boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(name, parent_id)
);

-- Enable RLS
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "allow_read"
  ON categories FOR SELECT
  TO public
  USING (true);

CREATE POLICY "allow_admin_write"
  ON categories FOR ALL 
  TO authenticated
  USING ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com')
  WITH CHECK ((auth.jwt() ->> 'email') = 'admin@thehappyblunt.com');

-- Create indexes for better performance
CREATE INDEX idx_categories_parent_id ON categories(parent_id);
CREATE INDEX idx_categories_level ON categories(level);
CREATE INDEX idx_categories_display_order ON categories(display_order);
CREATE INDEX idx_categories_status ON categories(status);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_categories_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for timestamp updates
CREATE TRIGGER update_categories_timestamp
  BEFORE UPDATE ON categories
  FOR EACH ROW
  EXECUTE FUNCTION update_categories_timestamp();

-- Add comments
COMMENT ON TABLE categories IS 'Tabla para almacenar las categorías de productos';
COMMENT ON COLUMN categories.id IS 'Identificador único de la categoría';
COMMENT ON COLUMN categories.name IS 'Nombre de la categoría';
COMMENT ON COLUMN categories.description IS 'Descripción detallada de la categoría';
COMMENT ON COLUMN categories.parent_id IS 'ID de la categoría padre (para jerarquía)';
COMMENT ON COLUMN categories.level IS 'Nivel en la jerarquía de categorías';
COMMENT ON COLUMN categories.display_order IS 'Orden de visualización';
COMMENT ON COLUMN categories.status IS 'Estado de la categoría (activo/inactivo)';
COMMENT ON COLUMN categories.created_at IS 'Fecha de creación del registro';
COMMENT ON COLUMN categories.updated_at IS 'Fecha de última actualización del registro';

-- Grant necessary permissions
GRANT ALL ON categories TO authenticated;
GRANT SELECT ON categories TO anon;