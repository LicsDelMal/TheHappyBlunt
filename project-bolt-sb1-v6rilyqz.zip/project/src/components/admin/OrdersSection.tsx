import React, { useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import { Trash2 } from 'lucide-react';
import type { Order } from '../../types';
import OrdersFilter from './orders/OrdersFilter';
import OrdersTable from './orders/OrdersTable';
import { useOrders } from './orders/hooks/useOrders';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

export default function OrdersSection() {
  const { orders, userProfiles, loading, error, updatingOrderId, updateOrderStatus, fetchOrders } = useOrders();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<keyof Order>('created_at');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  const handleSort = (field: keyof Order) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const handleDeleteOrder = async (orderId: string) => {
    if (!window.confirm('¿Estás seguro de que deseas eliminar este pedido? Esta acción no se puede deshacer.')) {
      return;
    }

    try {
      // Delete in the correct order to respect foreign key constraints
      
      // 1. First delete order status history
      const { error: historyError } = await supabase
        .from('order_status_history')
        .delete()
        .eq('order_id', orderId);

      if (historyError) throw historyError;

      // 2. Then delete order items
      const { error: itemsError } = await supabase
        .from('order_items')
        .delete()
        .eq('order_id', orderId);

      if (itemsError) throw itemsError;

      // 3. Finally delete the order itself
      const { error: orderError } = await supabase
        .from('orders')
        .delete()
        .eq('id', orderId);

      if (orderError) throw orderError;

      await fetchOrders();
    } catch (err) {
      console.error('Error deleting order:', err);
      alert('Error al eliminar el pedido. Por favor, intenta de nuevo.');
    }
  };

  const filteredOrders = orders
    .filter(order => {
      if (statusFilter !== 'all' && order.status !== statusFilter) return false;
      
      const searchLower = searchTerm.toLowerCase();
      return (
        order.id.toLowerCase().includes(searchLower) ||
        userProfiles[order.user_id]?.username?.toLowerCase().includes(searchLower) ||
        (order.shipping_address?.region || '').toLowerCase().includes(searchLower)
      );
    })
    .sort((a, b) => {
      const aValue = a[sortField];
      const bValue = b[sortField];
      const comparison = aValue > bValue ? 1 : -1;
      return sortDirection === 'asc' ? comparison : -comparison;
    });

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <OrdersFilter
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        statusFilter={statusFilter}
        setStatusFilter={setStatusFilter}
      />

      {error && (
        <div className="bg-red-900 border border-red-700 text-red-200 p-4 rounded">
          {error}
        </div>
      )}

      <OrdersTable
        orders={filteredOrders}
        sortField={sortField}
        sortDirection={sortDirection}
        handleSort={handleSort}
        updateOrderStatus={updateOrderStatus}
        updatingOrderId={updatingOrderId}
        userProfiles={userProfiles}
        onDeleteOrder={handleDeleteOrder}
      />
    </div>
  );
}