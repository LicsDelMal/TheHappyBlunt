export const STATUS_COLORS = {
  'pendiente': 'bg-yellow-900 text-yellow-200',
  'en_proceso': 'bg-blue-900 text-blue-200',
  'enviado': 'bg-green-900 text-green-200',
  'entregado': 'bg-green-900 text-green-200',
  'cancelado': 'bg-red-900 text-red-200'
} as const;

export const STATUS_LABELS = {
  'pendiente': 'Pendiente',
  'en_proceso': 'En Proceso',
  'enviado': 'Enviado',
  'entregado': 'Entregado',
  'cancelado': 'Cancelado'
} as const;