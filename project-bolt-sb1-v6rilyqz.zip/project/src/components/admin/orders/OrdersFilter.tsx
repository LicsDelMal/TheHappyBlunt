import React from 'react';
import { Search } from 'lucide-react';

interface OrdersFilterProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  statusFilter: string;
  setStatusFilter: (status: string) => void;
}

export default function OrdersFilter({
  searchTerm,
  setSearchTerm,
  statusFilter,
  setStatusFilter
}: OrdersFilterProps) {
  return (
    <div className="flex flex-wrap gap-4 items-center justify-between">
      <div className="flex-1 min-w-[300px]">
        <div className="relative">
          <input
            type="text"
            placeholder="Buscar pedidos..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-primary"
          />
          <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
        </div>
      </div>

      <select
        value={statusFilter}
        onChange={(e) => setStatusFilter(e.target.value)}
        className="px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-primary"
      >
        <option value="all">Todos los estados</option>
        <option value="pending">Pendientes</option>
        <option value="processing">En proceso</option>
        <option value="shipped">Enviados</option>
        <option value="delivered">Entregados</option>
        <option value="cancelled">Cancelados</option>
      </select>
    </div>
  );
}