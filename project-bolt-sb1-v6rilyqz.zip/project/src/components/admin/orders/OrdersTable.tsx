import React, { useState } from 'react';
import { MoreHorizontal, Download, Search, ArrowUpDown, ChevronDown, ChevronUp, MapPin, Phone, Mail, Package, DollarSign, Calendar, Clock, Trash2 } from 'lucide-react';
import type { Order } from '../../../types';
import { STATUS_COLORS, STATUS_LABELS } from './constants';

interface OrdersTableProps {
  orders: Order[];
  sortField: keyof Order;
  sortDirection: 'asc' | 'desc';
  handleSort: (field: keyof Order) => void;
  updateOrderStatus: (orderId: string, newStatus: string) => Promise<void>;
  updatingOrderId: string | null;
  userProfiles: Record<string, any>;
  onDeleteOrder: (orderId: string) => void;
}

export default function OrdersTable({
  orders,
  sortField,
  sortDirection,
  handleSort,
  updateOrderStatus,
  updatingOrderId,
  userProfiles,
  onDeleteOrder
}: OrdersTableProps) {
  const [expandedOrders, setExpandedOrders] = useState<Record<string, boolean>>({});

  const toggleOrderDetails = (orderId: string) => {
    setExpandedOrders(prev => ({
      ...prev,
      [orderId]: !prev[orderId]
    }));
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleString('es-MX', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="bg-gray-800 rounded-lg shadow overflow-x-auto">
      <table className="w-full">
        <thead className="bg-gray-900">
          <tr>
            <th className="w-8"></th>
            <th className="text-left py-3 px-4">
              <button
                onClick={() => handleSort('id')}
                className="flex items-center gap-1 text-gray-300 hover:text-primary"
              >
                ID Pedido
                <ArrowUpDown className="h-4 w-4" />
              </button>
            </th>
            <th className="text-left py-3 px-4">
              <button
                onClick={() => handleSort('user_id')}
                className="flex items-center gap-1 text-gray-300 hover:text-primary"
              >
                Cliente
                <ArrowUpDown className="h-4 w-4" />
              </button>
            </th>
            <th className="text-left py-3 px-4">
              <button
                onClick={() => handleSort('total_amount')}
                className="flex items-center gap-1 text-gray-300 hover:text-primary"
              >
                Total
                <ArrowUpDown className="h-4 w-4" />
              </button>
            </th>
            <th className="text-left py-3 px-4">Estado</th>
            <th className="text-left py-3 px-4">
              <button
                onClick={() => handleSort('created_at')}
                className="flex items-center gap-1 text-gray-300 hover:text-primary"
              >
                Fecha
                <ArrowUpDown className="h-4 w-4" />
              </button>
            </th>
            <th className="text-left py-3 px-4">Acciones</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-700">
          {orders.map(order => (
            <React.Fragment key={order.id}>
              <tr className={`hover:bg-gray-700 ${expandedOrders[order.id] ? 'bg-gray-700' : ''}`}>
                <td className="py-3 px-4">
                  <button
                    onClick={() => toggleOrderDetails(order.id)}
                    className="p-1 hover:bg-gray-600 rounded-full transition-colors"
                  >
                    {expandedOrders[order.id] ? (
                      <ChevronUp className="h-4 w-4 text-gray-400" />
                    ) : (
                      <ChevronDown className="h-4 w-4 text-gray-400" />
                    )}
                  </button>
                </td>
                <td className="py-3 px-4 text-white">#{order.id.slice(0, 8)}</td>
                <td className="py-3 px-4">
                  <div className="flex flex-col">
                    <span className="text-white">
                      {userProfiles[order.user_id]?.username || 'Usuario Desconocido'}
                    </span>
                    <span className="text-sm text-gray-400">
                      {userProfiles[order.user_id]?.email}
                    </span>
                  </div>
                </td>
                <td className="py-3 px-4 text-white">
                  ${order.total_amount.toFixed(2)}
                </td>
                <td className="py-3 px-4">
                  <select
                    value={order.status}
                    onChange={(e) => updateOrderStatus(order.id, e.target.value)}
                    disabled={updatingOrderId === order.id}
                    className={`px-3 py-1 rounded text-sm ${STATUS_COLORS[order.status]} bg-transparent border border-current`}
                  >
                    <option value="pendiente">Pendiente</option>
                    <option value="en_proceso">En proceso</option>
                    <option value="enviado">Enviado</option>
                    <option value="entregado">Entregado</option>
                    <option value="cancelado">Cancelado</option>
                  </select>
                </td>
                <td className="py-3 px-4 text-gray-300">
                  {formatDate(order.created_at)}
                </td>
                <td className="py-3 px-4">
                  <div className="flex gap-2">
                    <button
                      onClick={() => updateOrderStatus(order.id, order.status === 'entregado' ? 'pendiente' : 'entregado')}
                      disabled={updatingOrderId === order.id}
                      className={`px-3 py-1 rounded text-sm ${
                        order.status === 'entregado'
                          ? 'bg-yellow-900 text-yellow-200 hover:bg-yellow-800'
                          : 'bg-green-900 text-green-200 hover:bg-green-800'
                      }`}
                    >
                      {updatingOrderId === order.id ? 'Actualizando...' : 
                        order.status === 'entregado' ? 'Marcar Pendiente' : 'Marcar Completado'}
                    </button>
                    <button
                      onClick={() => onDeleteOrder(order.id)}
                      className="text-red-400 hover:text-red-300"
                      title="Eliminar pedido"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </td>
              </tr>
              {expandedOrders[order.id] && (
                <tr className="bg-gray-700">
                  <td colSpan={7} className="py-4 px-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Información de Envío */}
                      <div className="space-y-4">
                        <h4 className="text-lg font-semibold text-white flex items-center gap-2">
                          <MapPin className="h-5 w-5 text-primary" />
                          Información de Envío
                        </h4>
                        <div className="bg-gray-800 rounded-lg p-4 space-y-2">
                          <p className="text-white">
                            <span className="text-gray-400">Nombre:</span>{' '}
                            {order.shipping_address?.fullName}
                          </p>
                          <p className="text-white">
                            <span className="text-gray-400">Teléfono:</span>{' '}
                            {order.shipping_address?.phone}
                          </p>
                          {order.shipping_address?.email && (
                            <p className="text-white">
                              <span className="text-gray-400">Email:</span>{' '}
                              {order.shipping_address?.email}
                            </p>
                          )}
                          <p className="text-white">
                            <span className="text-gray-400">Dirección:</span>{' '}
                            {order.shipping_address?.address}
                          </p>
                          {order.shipping_address?.betweenStreets && (
                            <p className="text-white">
                              <span className="text-gray-400">Entre calles:</span>{' '}
                              {order.shipping_address?.betweenStreets}
                            </p>
                          )}
                          {order.shipping_address?.references && (
                            <p className="text-white">
                              <span className="text-gray-400">Referencias:</span>{' '}
                              {order.shipping_address?.references}
                            </p>
                          )}
                          <p className="text-white">
                            <span className="text-gray-400">Ciudad:</span>{' '}
                            {order.shipping_address?.city}
                          </p>
                          <p className="text-white">
                            <span className="text-gray-400">Estado:</span>{' '}
                            {order.shipping_address?.state}
                          </p>
                          <p className="text-white">
                            <span className="text-gray-400">Código Postal:</span>{' '}
                            {order.shipping_address?.zipCode}
                          </p>
                        </div>
                      </div>

                      {/* Detalles del Pedido */}
                      <div className="space-y-4">
                        <h4 className="text-lg font-semibold text-white flex items-center gap-2">
                          <Package className="h-5 w-5 text-primary" />
                          Detalles del Pedido
                        </h4>
                        <div className="bg-gray-800 rounded-lg p-4">
                          <div className="space-y-3">
                            {order.order_items?.map((item: any) => (
                              <div key={item.id} className="flex justify-between items-center py-2 border-b border-gray-700 last:border-0">
                                <div className="flex-1">
                                  <p className="text-white font-medium">{item.products?.name}</p>
                                  <p className="text-sm text-gray-400">Cantidad: {item.quantity}</p>
                                </div>
                                <p className="text-white">${(item.price * item.quantity).toFixed(2)}</p>
                              </div>
                            ))}
                            <div className="flex justify-between items-center pt-3 border-t border-gray-600">
                              <span className="text-gray-400">Total</span>
                              <span className="text-lg font-bold text-primary">
                                ${order.total_amount.toFixed(2)}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Información Adicional */}
                      <div className="md:col-span-2 space-y-4">
                        <h4 className="text-lg font-semibold text-white flex items-center gap-2">
                          <Clock className="h-5 w-5 text-primary" />
                          Información Adicional
                        </h4>
                        <div className="bg-gray-800 rounded-lg p-4">
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                              <p className="text-gray-400 text-sm">Método de Pago</p>
                              <p className="text-white capitalize">{order.payment_method}</p>
                            </div>
                            <div>
                              <p className="text-gray-400 text-sm">Fecha de Creación</p>
                              <p className="text-white">{formatDate(order.created_at)}</p>
                            </div>
                            <div>
                              <p className="text-gray-400 text-sm">Última Actualización</p>
                              <p className="text-white">{formatDate(order.updated_at || order.created_at)}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
              )}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
}