import React from 'react';

interface DataPoint {
  date: string;
  value: number;
}

interface LineChartProps {
  data: DataPoint[];
}

export default function LineChart({ data }: LineChartProps) {
  // Get min and max values for scaling
  const values = data.map(d => d.value);
  const max = Math.max(...values);
  const min = Math.min(...values);
  const range = max - min;

  // Calculate points for the path
  const points = data.map((d, i) => {
    const x = (i / (data.length - 1)) * 100;
    const y = 100 - ((d.value - min) / range) * 100;
    return `${x},${y}`;
  }).join(' ');

  return (
    <div className="w-full h-64 relative">
      <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
        {/* Grid lines */}
        {[0, 25, 50, 75, 100].map(y => (
          <line
            key={y}
            x1="0"
            y1={y}
            x2="100"
            y2={y}
            stroke="#374151"
            strokeWidth="0.5"
          />
        ))}

        {/* Line chart */}
        <polyline
          points={points}
          fill="none"
          stroke="#FF1B6B"
          strokeWidth="2"
        />

        {/* Area under the line */}
        <path
          d={`M0,100 ${points} 100,100 Z`}
          fill="url(#gradient)"
          opacity="0.2"
        />

        {/* Gradient definition */}
        <defs>
          <linearGradient id="gradient" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="#FF1B6B" />
            <stop offset="100%" stopColor="#FF1B6B" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>

      {/* Y-axis labels */}
      <div className="absolute left-0 top-0 h-full flex flex-col justify-between text-xs text-gray-400">
        {[max, max * 0.75, max * 0.5, max * 0.25, 0].map(value => (
          <span key={value}>${value.toFixed(0)}</span>
        ))}
      </div>

      {/* X-axis labels */}
      <div className="absolute bottom-0 w-full flex justify-between text-xs text-gray-400">
        {data.map(d => (
          <span key={d.date}>{d.date}</span>
        ))}
      </div>
    </div>
  );
}