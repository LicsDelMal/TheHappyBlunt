import React from 'react';

interface DataPoint {
  label: string;
  value: number;
}

interface DoughnutChartProps {
  data: DataPoint[];
}

export default function DoughnutChart({ data }: DoughnutChartProps) {
  const total = data.reduce((sum, item) => sum + item.value, 0);
  let currentAngle = 0;

  const colors = [
    '#FF1B6B', // primary
    '#45CAFF', // secondary
    '#A0FF1B', // accent
    '#FFB800', // yellow
    '#9C27B0', // purple
    '#00BCD4', // cyan
  ];

  return (
    <div className="relative w-64 h-64 mx-auto">
      <svg viewBox="0 0 100 100" className="transform -rotate-90">
        {data.map((item, index) => {
          const percentage = (item.value / total) * 100;
          const angle = (percentage / 100) * 360;
          
          // Calculate the SVG arc path
          const x1 = 50 + 35 * Math.cos((currentAngle * Math.PI) / 180);
          const y1 = 50 + 35 * Math.sin((currentAngle * Math.PI) / 180);
          const x2 = 50 + 35 * Math.cos(((currentAngle + angle) * Math.PI) / 180);
          const y2 = 50 + 35 * Math.sin(((currentAngle + angle) * Math.PI) / 180);
          
          const largeArcFlag = angle > 180 ? 1 : 0;
          const path = `
            M 50 50
            L ${x1} ${y1}
            A 35 35 0 ${largeArcFlag} 1 ${x2} ${y2}
            Z
          `;

          currentAngle += angle;

          return (
            <path
              key={index}
              d={path}
              fill={colors[index % colors.length]}
            />
          );
        })}
        {/* Inner circle for doughnut effect */}
        <circle cx="50" cy="50" r="25" fill="#1F2937" />
      </svg>

      {/* Legend */}
      <div className="absolute top-0 -right-32 h-full flex flex-col justify-center space-y-2">
        {data.map((item, index) => (
          <div key={index} className="flex items-center">
            <div
              className="w-3 h-3 rounded-full mr-2"
              style={{ backgroundColor: colors[index % colors.length] }}
            />
            <span className="text-sm text-gray-300">
              {item.label} ({(item.value / total * 100).toFixed(1)}%)
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}