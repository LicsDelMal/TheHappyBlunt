import React from 'react';

interface DataPoint {
  label: string;
  value: number;
}

interface BarChartProps {
  data: DataPoint[];
}

export default function BarChart({ data }: BarChartProps) {
  const max = Math.max(...data.map(d => d.value));

  return (
    <div className="w-full h-64">
      <div className="flex h-full items-end space-x-2">
        {data.map((item, index) => {
          const height = (item.value / max) * 100;
          return (
            <div
              key={index}
              className="flex-1 flex flex-col items-center"
            >
              <div
                className="w-full bg-primary rounded-t"
                style={{ height: `${height}%` }}
              />
              <div className="mt-2 text-xs text-gray-400 truncate w-full text-center">
                {item.label}
              </div>
              <div className="text-xs text-white">
                ${item.value.toFixed(0)}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}