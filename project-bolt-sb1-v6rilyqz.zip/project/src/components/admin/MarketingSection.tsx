import React, { useState } from 'react';
import { Plus, Search, ArrowUpDown } from 'lucide-react';
import CouponForm from './marketing/CouponForm';
import CouponList from './marketing/CouponList';
import type { Coupon } from '../../types';

export default function MarketingSection() {
  const [showCouponForm, setShowCouponForm] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState<Coupon | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<keyof Coupon>('created_at');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-4 items-center justify-between">
        <div className="flex-1 min-w-[300px]">
          <div className="relative">
            <input
              type="text"
              placeholder="Buscar cupones..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-primary"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
        </div>

        <button
          onClick={() => {
            setEditingCoupon(null);
            setShowCouponForm(true);
          }}
          className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-opacity-90 flex items-center gap-2"
        >
          <Plus className="h-4 w-4" />
          Nuevo Cupón
        </button>
      </div>

      <CouponList
        searchTerm={searchTerm}
        sortField={sortField}
        sortDirection={sortDirection}
        onSort={(field) => {
          if (sortField === field) {
            setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
          } else {
            setSortField(field);
            setSortDirection('asc');
          }
        }}
        onEdit={(coupon) => {
          setEditingCoupon(coupon);
          setShowCouponForm(true);
        }}
      />

      {showCouponForm && (
        <CouponForm
          coupon={editingCoupon}
          onClose={() => {
            setShowCouponForm(false);
            setEditingCoupon(null);
          }}
        />
      )}
    </div>
  );
}