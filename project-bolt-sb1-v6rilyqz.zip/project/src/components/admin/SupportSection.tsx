import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import { Search, ArrowUpDown, MessageCircle, AlertCircle } from 'lucide-react';
import type { SupportTicket, UserProfile } from '../../types';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

const PRIORITY_COLORS = {
  low: 'bg-blue-900 text-blue-200',
  normal: 'bg-green-900 text-green-200',
  high: 'bg-yellow-900 text-yellow-200',
  urgent: 'bg-red-900 text-red-200'
};

const STATUS_COLORS = {
  pending: 'bg-yellow-900 text-yellow-200',
  'in_progress': 'bg-blue-900 text-blue-200',
  resolved: 'bg-green-900 text-green-200',
  closed: 'bg-gray-900 text-gray-200'
};

export default function SupportSection() {
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [users, setUsers] = useState<Record<string, UserProfile>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [sortField, setSortField] = useState<keyof SupportTicket>('created_at');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  useEffect(() => {
    fetchTickets();
    fetchUsers();
  }, []);

  const fetchTickets = async () => {
    try {
      const { data, error } = await supabase
        .from('support_tickets')
        .select('*');

      if (error) throw error;
      setTickets(data || []);
    } catch (err) {
      console.error('Error fetching tickets:', err);
      setError('Error al cargar los tickets');
    } finally {
      setLoading(false);
    }
  };

  const fetchUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*');

      if (error) throw error;
      
      const userMap = (data || []).reduce((acc, user) => {
        acc[user.id] = user;
        return acc;
      }, {} as Record<string, UserProfile>);
      
      setUsers(userMap);
    } catch (err) {
      console.error('Error fetching users:', err);
    }
  };

  const updateTicket = async (ticketId: string, updates: Partial<SupportTicket>) => {
    try {
      const { error } = await supabase
        .from('support_tickets')
        .update(updates)
        .eq('id', ticketId);

      if (error) throw error;
      await fetchTickets();
    } catch (err) {
      console.error('Error updating ticket:', err);
      setError('Error al actualizar el ticket');
    }
  };

  const handleSort = (field: keyof SupportTicket) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const filteredTickets = tickets
    .filter(ticket => {
      if (statusFilter !== 'all' && ticket.status !== statusFilter) return false;
      if (priorityFilter !== 'all' && ticket.priority !== priorityFilter) return false;
      
      const searchLower = searchTerm.toLowerCase();
      return (
        ticket.subject.toLowerCase().includes(searchLower) ||
        users[ticket.user_id]?.username?.toLowerCase().includes(searchLower)
      );
    })
    .sort((a, b) => {
      const aValue = a[sortField];
      const bValue = b[sortField];
      const comparison = aValue > bValue ? 1 : -1;
      return sortDirection === 'asc' ? comparison : -comparison;
    });

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex flex-wrap gap-4 items-center justify-between">
        <div className="flex-1 min-w-[300px]">
          <div className="relative">
            <input
              type="text"
              placeholder="Buscar tickets..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-primary"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
        </div>

        <div className="flex gap-4">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-primary"
          >
            <option value="all">Todos los estados</option>
            <option value="pending">Pendientes</option>
            <option value="in_progress">En proceso</option>
            <option value="resolved">Resueltos</option>
            <option value="closed">Cerrados</option>
          </select>

          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-primary"
          >
            <option value="all">Todas las prioridades</option>
            <option value="low">Baja</option>
            <option value="normal">Normal</option>
            <option value="high">Alta</option>
            <option value="urgent">Urgente</option>
          </select>
        </div>
      </div>

      {/* Tickets Table */}
      <div className="bg-gray-800 rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-900">
            <tr>
              <th className="text-left py-3 px-4">
                <button
                  onClick={() => handleSort('subject')}
                  className="flex items-center gap-1 text-gray-300 hover:text-primary"
                >
                  Asunto
                  <ArrowUpDown className="h-4 w-4" />
                </button>
              </th>
              <th className="text-left py-3 px-4">Usuario</th>
              <th className="text-left py-3 px-4">
                <button
                  onClick={() => handleSort('priority')}
                  className="flex items-center gap-1 text-gray-300 hover:text-primary"
                >
                  Prioridad
                  <ArrowUpDown className="h-4 w-4" />
                </button>
              </th>
              <th className="text-left py-3 px-4">Estado</th>
              <th className="text-left py-3 px-4">
                <button
                  onClick={() => handleSort('created_at')}
                  className="flex items-center gap-1 text-gray-300 hover:text-primary"
                >
                  Fecha
                  <ArrowUpDown className="h-4 w-4" />
                </button>
              </th>
              <th className="text-left py-3 px-4">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-700">
            {filteredTickets.map(ticket => (
              <tr key={ticket.id} className="hover:bg-gray-700">
                <td className="py-3 px-4 text-white">{ticket.subject}</td>
                <td className="py-3 px-4 text-white">
                  {users[ticket.user_id]?.username || 'Usuario desconocido'}
                </td>
                <td className="py-3 px-4">
                  <select
                    value={ticket.priority}
                    onChange={(e) => updateTicket(ticket.id, { priority: e.target.value as any })}
                    className={`px-2 py-1 rounded text-sm ${PRIORITY_COLORS[ticket.priority]}`}
                  >
                    <option value="low">Baja</option>
                    <option value="normal">Normal</option>
                    <option value="high">Alta</option>
                    <option value="urgent">Urgente</option>
                  </select>
                </td>
                <td className="py-3 px-4">
                  <select
                    value={ticket.status}
                    onChange={(e) => updateTicket(ticket.id, { status: e.target.value as any })}
                    className={`px-2 py-1 rounded text-sm ${STATUS_COLORS[ticket.status]}`}
                  >
                    <option value="pending">Pendiente</option>
                    <option value="in_progress">En proceso</option>
                    <option value="resolved">Resuelto</option>
                    <option value="closed">Cerrado</option>
                  </select>
                </td>
                <td className="py-3 px-4 text-gray-300">
                  {new Date(ticket.created_at).toLocaleString()}
                </td>
                <td className="py-3 px-4">
                  <div className="flex gap-2">
                    <button
                      onClick={() => {/* TODO: Implement chat/message view */}}
                      className="text-blue-400 hover:text-blue-300"
                      title="Ver mensajes"
                    >
                      <MessageCircle className="h-4 w-4" />
                    </button>
                    {ticket.priority === 'urgent' && (
                      <AlertCircle 
                        className="h-4 w-4 text-red-400" 
                        title="Ticket urgente"
                      />
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}