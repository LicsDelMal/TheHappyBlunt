import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import { Plus, Edit, Trash2, Search, ArrowUpDown, ChevronLeft, ChevronRight, Download, Upload, Eye, EyeOff, Tag } from 'lucide-react';
import ProductForm from '../ProductForm';
import DeleteConfirmation from '../DeleteConfirmation';
import type { Product } from '../../types';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

interface ProductsSectionProps {
  products: Product[];
  categories: Record<string, string[]>;
  onProductsChange: () => void;
}

const ITEMS_PER_PAGE = 10;

export default function ProductsSection({ products, categories, onProductsChange }: ProductsSectionProps) {
  const [showProductForm, setShowProductForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [deletingProduct, setDeletingProduct] = useState<Product | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [sortField, setSortField] = useState<keyof Product>('name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [error, setError] = useState('');
  const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
  const [showBulkActions, setShowBulkActions] = useState(false);
  const [showDiscountModal, setShowDiscountModal] = useState(false);
  const [discountAmount, setDiscountAmount] = useState(0);
  const [loading, setLoading] = useState(false);

  // Reset to first page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [selectedCategory, searchTerm, sortField, sortDirection]);

  const handleDelete = async (product: Product) => {
    try {
      setLoading(true);
      setError('');

      // First try soft delete
      const { data: softDeleteResult, error: softDeleteError } = await supabase
        .rpc('soft_delete_product', {
          product_id: product.id
        });

      if (softDeleteError) {
        console.error('Soft delete failed:', softDeleteError);
        
        // If soft delete fails, try hard delete
        const { error: hardDeleteError } = await supabase
          .from('products')
          .delete()
          .eq('id', product.id);

        if (hardDeleteError) throw hardDeleteError;
      }

      await onProductsChange();
      setDeletingProduct(null);
    } catch (err) {
      console.error('Error deleting product:', err);
      setError('Error al eliminar el producto. Por favor, inténtelo de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  const handleSort = (field: keyof Product) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const handleBulkVisibility = async (visible: boolean) => {
    try {
      setLoading(true);
      const { error } = await supabase
        .from('products')
        .update({ is_visible: visible })
        .in('id', selectedProducts);

      if (error) throw error;
      await onProductsChange();
      setSelectedProducts([]);
    } catch (err) {
      console.error('Error updating visibility:', err);
      setError('Error al actualizar la visibilidad de los productos');
    } finally {
      setLoading(false);
    }
  };

  const handleBulkDiscount = async () => {
    try {
      setLoading(true);
      const { error } = await supabase
        .from('products')
        .update({ 
          price: supabase.raw(`price * (1 - ${discountAmount / 100})::numeric`),
          discount_percent: discountAmount 
        })
        .in('id', selectedProducts);

      if (error) throw error;
      await onProductsChange();
      setSelectedProducts([]);
      setShowDiscountModal(false);
    } catch (err) {
      console.error('Error applying discount:', err);
      setError('Error al aplicar el descuento');
    } finally {
      setLoading(false);
    }
  };

  const filteredProducts = products
    .filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = !selectedCategory || product.category === selectedCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      const aValue = a[sortField];
      const bValue = b[sortField];
      const comparison = aValue > bValue ? 1 : -1;
      return sortDirection === 'asc' ? comparison : -comparison;
    });

  const paginatedProducts = filteredProducts.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  return (
    <div className="space-y-6">
      {/* Search and Filters */}
      <div className="flex flex-wrap gap-4 items-center justify-between">
        <div className="flex-1 min-w-[300px]">
          <div className="relative">
            <input
              type="text"
              placeholder="Buscar productos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-primary"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
        </div>

        <div className="flex gap-4">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-primary"
          >
            <option value="">Todas las categorías</option>
            {Object.keys(categories).map((cat) => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>

          <button
            onClick={() => {
              setEditingProduct(null);
              setShowProductForm(true);
            }}
            className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-opacity-90 flex items-center gap-2"
          >
            <Plus className="h-4 w-4" />
            Nuevo Producto
          </button>
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="bg-red-900 border border-red-700 text-red-200 p-4 rounded-lg">
          {error}
        </div>
      )}

      {/* Products Table */}
      <div className="bg-gray-800 rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-900">
            <tr>
              <th className="w-4 p-4">
                <input
                  type="checkbox"
                  onChange={(e) => {
                    setSelectedProducts(
                      e.target.checked ? products.map(p => p.id) : []
                    );
                  }}
                  className="rounded border-gray-600 text-primary focus:ring-primary"
                />
              </th>
              <th className="text-left py-3 px-4">
                <button
                  onClick={() => handleSort('name')}
                  className="flex items-center gap-1 text-white hover:text-primary"
                >
                  Nombre
                  <ArrowUpDown className="h-4 w-4" />
                </button>
              </th>
              <th className="text-left py-3 px-4">Categoría</th>
              <th className="text-left py-3 px-4">Precio</th>
              <th className="text-left py-3 px-4">Stock</th>
              <th className="text-left py-3 px-4">Estado</th>
              <th className="text-left py-3 px-4">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-700">
            {paginatedProducts.map(product => (
              <tr key={product.id} className="hover:bg-gray-700">
                <td className="p-4">
                  <input
                    type="checkbox"
                    checked={selectedProducts.includes(product.id)}
                    onChange={(e) => {
                      setSelectedProducts(
                        e.target.checked
                          ? [...selectedProducts, product.id]
                          : selectedProducts.filter(id => id !== product.id)
                      );
                    }}
                    className="rounded border-gray-600 text-primary focus:ring-primary"
                  />
                </td>
                <td className="py-3 px-4 text-white">{product.name}</td>
                <td className="py-3 px-4 text-white">{product.category}</td>
                <td className="py-3 px-4 text-white">
                  ${product.price.toFixed(2)}
                  {product.discount_percent > 0 && (
                    <span className="ml-2 text-sm text-red-400">
                      -{product.discount_percent}%
                    </span>
                  )}
                </td>
                <td className="py-3 px-4">
                  <span className={`px-2 py-1 rounded-full text-sm ${
                    product.stock > 10
                      ? 'bg-green-900 text-green-200'
                      : product.stock > 0
                      ? 'bg-yellow-900 text-yellow-200'
                      : 'bg-red-900 text-red-200'
                  }`}>
                    {product.stock}
                  </span>
                </td>
                <td className="py-3 px-4">
                  <span className={`px-2 py-1 rounded-full text-sm ${
                    product.is_visible
                      ? 'bg-green-900 text-green-200'
                      : 'bg-gray-900 text-gray-200'
                  }`}>
                    {product.is_visible ? 'Visible' : 'Oculto'}
                  </span>
                </td>
                <td className="py-3 px-4">
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        setEditingProduct(product);
                        setShowProductForm(true);
                      }}
                      className="text-blue-400 hover:text-blue-300"
                      title="Editar"
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => setDeletingProduct(product)}
                      className="text-red-400 hover:text-red-300"
                      title="Eliminar"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleBulkVisibility(!product.is_visible)}
                      className="text-gray-400 hover:text-gray-300"
                      title={product.is_visible ? 'Ocultar' : 'Mostrar'}
                    >
                      {product.is_visible ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Pagination */}
        {filteredProducts.length > ITEMS_PER_PAGE && (
          <div className="flex justify-between items-center p-4 border-t border-gray-700">
            <p className="text-sm text-gray-400">
              Mostrando {(currentPage - 1) * ITEMS_PER_PAGE + 1} a{' '}
              {Math.min(currentPage * ITEMS_PER_PAGE, filteredProducts.length)} de{' '}
              {filteredProducts.length} productos
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-2 border border-gray-600 rounded hover:bg-gray-600 disabled:opacity-50 text-white"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <button
                onClick={() => setCurrentPage(p => p + 1)}
                disabled={currentPage * ITEMS_PER_PAGE >= filteredProducts.length}
                className="p-2 border border-gray-600 rounded hover:bg-gray-600 disabled:opacity-50 text-white"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      {showProductForm && (
        <ProductForm
          product={editingProduct || undefined}
          onClose={() => {
            setShowProductForm(false);
            setEditingProduct(null);
          }}
          onSuccess={() => {
            onProductsChange();
            setShowProductForm(false);
            setEditingProduct(null);
          }}
        />
      )}

      {deletingProduct && (
        <DeleteConfirmation
          title="¿Eliminar producto?"
          message={`¿Estás seguro de que deseas eliminar el producto "${deletingProduct.name}"? Esta acción no se puede deshacer.`}
          onConfirm={() => handleDelete(deletingProduct)}
          onCancel={() => setDeletingProduct(null)}
          loading={loading}
        />
      )}

      {showDiscountModal && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md">
            <h3 className="text-xl font-bold text-white mb-4">
              Aplicar Descuento
            </h3>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Porcentaje de descuento
              </label>
              <input
                type="number"
                min="0"
                max="100"
                value={discountAmount}
                onChange={(e) => setDiscountAmount(Number(e.target.value))}
                className="w-full p-2 bg-gray-700 border border-gray-600 rounded text-white"
              />
            </div>
            <div className="flex justify-end gap-4">
              <button
                onClick={() => setShowDiscountModal(false)}
                className="px-4 py-2 text-gray-400 hover:text-white"
                disabled={loading}
              >
                Cancelar
              </button>
              <button
                onClick={handleBulkDiscount}
                className="px-4 py-2 bg-primary text-white rounded hover:bg-opacity-90 disabled:opacity-50"
                disabled={loading}
              >
                {loading ? 'Aplicando...' : 'Aplicar'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}