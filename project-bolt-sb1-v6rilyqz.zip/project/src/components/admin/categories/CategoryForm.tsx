import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import type { Category } from '../../../types';

interface CategoryFormProps {
  category?: Category;
  categories: Category[];
  parentId?: string;
  onClose: () => void;
  onSubmit: (data: Partial<Category>) => Promise<void>;
}

export default function CategoryForm({ 
  category,
  categories,
  parentId,
  onClose,
  onSubmit
}: CategoryFormProps) {
  const [formData, setFormData] = useState({
    name: category?.name || '',
    parent_id: category?.parent_id || parentId || '',
    display_order: category?.display_order?.toString() || '0'
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Get available parent categories (exclude self and children)
  const getAvailableParents = () => {
    if (!category) return categories.filter(c => !c.parent_id);
    
    const childIds = new Set<string>();
    const getChildIds = (parentId: string) => {
      categories
        .filter(c => c.parent_id === parentId)
        .forEach(child => {
          childIds.add(child.id);
          getChildIds(child.id);
        });
    };
    
    if (category.id) {
      getChildIds(category.id);
    }
    
    return categories.filter(c => 
      c.id !== category.id && !childIds.has(c.id)
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await onSubmit({
        ...formData,
        display_order: parseInt(formData.display_order)
      });
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al guardar la categoría');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md relative border border-gray-700">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white"
        >
          <X className="h-6 w-6" />
        </button>

        <h2 className="text-2xl font-bold text-white mb-6">
          {category ? 'Editar Categoría' : 'Nueva Categoría'}
        </h2>

        {error && (
          <div className="mb-4 bg-red-900 border border-red-700 text-red-200 p-4 rounded">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Nombre
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full p-2 bg-gray-700 border border-gray-600 rounded text-white"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Categoría Padre
            </label>
            <select
              value={formData.parent_id}
              onChange={(e) => setFormData({ ...formData, parent_id: e.target.value })}
              className="w-full p-2 bg-gray-700 border border-gray-600 rounded text-white"
            >
              <option value="">Ninguna (Categoría Principal)</option>
              {getAvailableParents().map(cat => (
                <option key={cat.id} value={cat.id}>
                  {cat.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Orden de Visualización
            </label>
            <input
              type="number"
              value={formData.display_order}
              onChange={(e) => setFormData({ ...formData, display_order: e.target.value })}
              className="w-full p-2 bg-gray-700 border border-gray-600 rounded text-white"
              min="0"
              required
            />
          </div>

          <div className="flex justify-end gap-4 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-400 hover:text-white"
              disabled={loading}
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-primary text-white rounded hover:bg-opacity-90 disabled:opacity-50"
              disabled={loading}
            >
              {loading ? 'Guardando...' : (category ? 'Actualizar' : 'Crear')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}