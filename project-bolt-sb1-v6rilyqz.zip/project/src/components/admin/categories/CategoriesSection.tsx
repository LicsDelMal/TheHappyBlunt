import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import { Plus, Search } from 'lucide-react';
import CategoryTree from './CategoryTree';
import CategoryForm from './CategoryForm';
import DeleteConfirmation from '../../DeleteConfirmation';
import type { Category } from '../../../types';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

export default function CategoriesSection() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [deletingCategory, setDeletingCategory] = useState<Category | null>(null);
  const [selectedParentId, setSelectedParentId] = useState<string | null>(null);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .order('display_order');

      if (error) throw error;
      setCategories(data || []);
    } catch (err) {
      console.error('Error fetching categories:', err);
      setError('Error al cargar las categorías');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (data: Partial<Category>) => {
    try {
      // Si parent_id está vacío, establecerlo como null explícitamente
      const categoryData = {
        ...data,
        parent_id: data.parent_id || null
      };

      if (editingCategory) {
        const { error } = await supabase
          .from('categories')
          .update(categoryData)
          .eq('id', editingCategory.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('categories')
          .insert([categoryData]);

        if (error) throw error;
      }

      await fetchCategories();
      setShowForm(false);
      setEditingCategory(null);
      setSelectedParentId(null);
    } catch (err) {
      console.error('Error saving category:', err);
      throw new Error('Error al guardar la categoría');
    }
  };

  const handleDelete = async (category: Category) => {
    try {
      const { error } = await supabase
        .from('categories')
        .delete()
        .eq('id', category.id);

      if (error) throw error;
      await fetchCategories();
      setDeletingCategory(null);
    } catch (err) {
      console.error('Error deleting category:', err);
      setError('Error al eliminar la categoría');
    }
  };

  const filteredCategories = categories.filter(category =>
    category.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-4 items-center justify-between">
        <div className="flex-1 min-w-[300px]">
          <div className="relative">
            <input
              type="text"
              placeholder="Buscar categorías..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-primary"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
        </div>

        <button
          onClick={() => {
            setEditingCategory(null);
            setSelectedParentId(null);
            setShowForm(true);
          }}
          className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-opacity-90 flex items-center gap-2"
        >
          <Plus className="h-4 w-4" />
          Nueva Categoría
        </button>
      </div>

      {error && (
        <div className="bg-red-900 border border-red-700 text-red-200 p-4 rounded">
          {error}
        </div>
      )}

      <div className="bg-gray-800 rounded-lg p-6">
        <CategoryTree
          categories={filteredCategories}
          onEdit={(category) => {
            setEditingCategory(category);
            setShowForm(true);
          }}
          onDelete={setDeletingCategory}
          onAdd={(parentId) => {
            setEditingCategory(null);
            setSelectedParentId(parentId);
            setShowForm(true);
          }}
        />
      </div>

      {showForm && (
        <CategoryForm
          category={editingCategory}
          categories={categories}
          parentId={selectedParentId}
          onClose={() => {
            setShowForm(false);
            setEditingCategory(null);
            setSelectedParentId(null);
          }}
          onSubmit={handleSubmit}
        />
      )}

      {deletingCategory && (
        <DeleteConfirmation
          title="¿Eliminar categoría?"
          message={`¿Estás seguro de que deseas eliminar la categoría "${deletingCategory.name}" y todas sus subcategorías? Esta acción no se puede deshacer.`}
          onConfirm={() => handleDelete(deletingCategory)}
          onCancel={() => setDeletingCategory(null)}
        />
      )}
    </div>
  );
}