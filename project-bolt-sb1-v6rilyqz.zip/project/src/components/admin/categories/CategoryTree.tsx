import React, { useState } from 'react';
import { ChevronRight, ChevronDown, Edit, Trash2, Plus } from 'lucide-react';
import type { Category } from '../../../types';

interface CategoryTreeProps {
  categories: Category[];
  onEdit: (category: Category) => void;
  onDelete: (category: Category) => void;
  onAdd: (parentId?: string) => void;
}

interface TreeNode extends Category {
  children: TreeNode[];
}

const buildTree = (categories: Category[]): TreeNode[] => {
  const nodes: { [key: string]: TreeNode } = {};
  const roots: TreeNode[] = [];

  // First pass: create nodes
  categories.forEach(cat => {
    nodes[cat.id] = { ...cat, children: [] };
  });

  // Second pass: build tree
  categories.forEach(cat => {
    if (cat.parent_id && nodes[cat.parent_id]) {
      nodes[cat.parent_id].children.push(nodes[cat.id]);
    } else {
      roots.push(nodes[cat.id]);
    }
  });

  // Sort by display_order
  const sortNodes = (nodes: TreeNode[]) => {
    nodes.sort((a, b) => (a.display_order || 0) - (b.display_order || 0));
    nodes.forEach(node => {
      if (node.children.length > 0) {
        sortNodes(node.children);
      }
    });
  };

  sortNodes(roots);
  return roots;
};

const CategoryNode: React.FC<{
  node: TreeNode;
  level: number;
  onEdit: (category: Category) => void;
  onDelete: (category: Category) => void;
  onAdd: (parentId?: string) => void;
}> = ({ node, level, onEdit, onDelete, onAdd }) => {
  const [isExpanded, setIsExpanded] = useState(true);

  return (
    <div className="select-none">
      <div 
        className={`
          flex items-center gap-2 p-2 rounded-lg hover:bg-gray-700 transition-colors
          ${level === 0 ? 'bg-gray-800' : ''}
        `}
        style={{ marginLeft: `${level * 20}px` }}
      >
        {node.children.length > 0 && (
          <button 
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 hover:bg-gray-600 rounded"
          >
            {isExpanded ? (
              <ChevronDown className="h-4 w-4 text-gray-400" />
            ) : (
              <ChevronRight className="h-4 w-4 text-gray-400" />
            )}
          </button>
        )}
        
        <span className="flex-1 text-white">{node.name}</span>
        
        <div className="flex items-center gap-1">
          <button
            onClick={() => onAdd(node.id)}
            className="p-1 text-gray-400 hover:text-white hover:bg-gray-600 rounded"
            title="Agregar subcategoría"
          >
            <Plus className="h-4 w-4" />
          </button>
          <button
            onClick={() => onEdit(node)}
            className="p-1 text-blue-400 hover:text-blue-300 hover:bg-gray-600 rounded"
            title="Editar"
          >
            <Edit className="h-4 w-4" />
          </button>
          <button
            onClick={() => onDelete(node)}
            className="p-1 text-red-400 hover:text-red-300 hover:bg-gray-600 rounded"
            title="Eliminar"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </div>

      {isExpanded && node.children.length > 0 && (
        <div className="mt-1">
          {node.children.map(child => (
            <CategoryNode
              key={child.id}
              node={child}
              level={level + 1}
              onEdit={onEdit}
              onDelete={onDelete}
              onAdd={onAdd}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default function CategoryTree({ categories, onEdit, onDelete, onAdd }: CategoryTreeProps) {
  const tree = buildTree(categories);

  return (
    <div className="space-y-2">
      {tree.map(node => (
        <CategoryNode
          key={node.id}
          node={node}
          level={0}
          onEdit={onEdit}
          onDelete={onDelete}
          onAdd={onAdd}
        />
      ))}
    </div>
  );
}