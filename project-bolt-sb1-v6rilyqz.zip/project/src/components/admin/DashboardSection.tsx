import React, { useState } from 'react';
import { Package, Users, TrendingUp, DollarSign, ShoppingCart, Clock, Calendar, MapPin } from 'lucide-react';
import type { Product, UserProfile, Order } from '../../types';
import { LineChart, BarChart, DoughnutChart } from './charts';

interface DashboardSectionProps {
  products: Product[];
  users: UserProfile[];
  orders?: Order[];
}

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ElementType;
  trend?: number;
  className?: string;
}

const StatCard = ({ title, value, icon: Icon, trend, className = '' }: StatCardProps) => (
  <div className={`bg-gray-800 rounded-lg p-6 ${className}`}>
    <div className="flex items-center justify-between mb-4">
      <h3 className="text-lg font-semibold text-gray-300">{title}</h3>
      <Icon className="h-6 w-6 text-primary" />
    </div>
    <p className="text-3xl font-bold text-white mb-2">{value}</p>
    {trend !== undefined && (
      <div className={`flex items-center text-sm ${trend >= 0 ? 'text-green-400' : 'text-red-400'}`}>
        <TrendingUp className={`h-4 w-4 mr-1 ${trend < 0 ? 'transform rotate-180' : ''}`} />
        <span>{Math.abs(trend)}% vs mes anterior</span>
      </div>
    )}
  </div>
);

export default function DashboardSection({ products, users, orders = [] }: DashboardSectionProps) {
  const [timeRange, setTimeRange] = useState<'day' | 'week' | 'month' | 'year'>('month');
  
  // Calculate KPIs
  const totalSales = orders.reduce((sum, order) => sum + order.total_amount, 0);
  const averageOrderValue = orders.length > 0 ? totalSales / orders.length : 0;
  const conversionRate = orders.length > 0 ? (orders.length / users.length) * 100 : 0;
  
  // Top selling products
  const topProducts = products
    .sort((a, b) => (b.sold_count || 0) - (a.sold_count || 0))
    .slice(0, 5);

  // Sales by region
  const salesByRegion = orders.reduce((acc, order) => {
    const region = order.shipping_address?.region || 'Desconocido';
    acc[region] = (acc[region] || 0) + order.total_amount;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="space-y-6">
      {/* Time Range Selector */}
      <div className="flex justify-end space-x-2">
        {(['day', 'week', 'month', 'year'] as const).map((range) => (
          <button
            key={range}
            onClick={() => setTimeRange(range)}
            className={`px-4 py-2 rounded-lg ${
              timeRange === range
                ? 'bg-primary text-white'
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
          >
            {range === 'day' && 'Hoy'}
            {range === 'week' && 'Semana'}
            {range === 'month' && 'Mes'}
            {range === 'year' && 'Año'}
          </button>
        ))}
      </div>

      {/* Main Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Ventas Totales"
          value={`$${totalSales.toFixed(2)}`}
          icon={DollarSign}
          trend={12.5}
        />
        <StatCard
          title="Pedidos"
          value={orders.length}
          icon={ShoppingCart}
          trend={8.2}
        />
        <StatCard
          title="Usuarios Activos"
          value={users.filter(u => u.is_active).length}
          icon={Users}
          trend={15.3}
        />
        <StatCard
          title="Productos"
          value={products.length}
          icon={Package}
          trend={-2.1}
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sales Trend */}
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Tendencia de Ventas</h3>
          <LineChart
            data={[
              /* Sample data structure */
              { date: '2024-01', value: 12500 },
              { date: '2024-02', value: 15000 },
              { date: '2024-03', value: 18000 }
            ]}
          />
        </div>

        {/* Sales by Category */}
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Ventas por Categoría</h3>
          <DoughnutChart
            data={[
              /* Sample data structure */
              { label: 'Cartuchos', value: 35 },
              { label: 'Comestibles', value: 25 },
              { label: 'Accesorios', value: 20 },
              { label: 'Otros', value: 20 }
            ]}
          />
        </div>
      </div>

      {/* Additional Stats Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Products */}
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Productos Más Vendidos</h3>
          <div className="space-y-4">
            {topProducts.map((product, index) => (
              <div key={product.id} className="flex items-center justify-between">
                <div className="flex items-center">
                  <span className="text-gray-400 w-6">{index + 1}.</span>
                  <span className="text-white">{product.name}</span>
                </div>
                <span className="text-primary font-semibold">
                  {product.sold_count || 0} vendidos
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Regional Sales */}
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Ventas por Región</h3>
          <BarChart
            data={Object.entries(salesByRegion).map(([region, amount]) => ({
              label: region,
              value: amount
            }))}
          />
        </div>
      </div>

      {/* Additional Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard
          title="Valor Promedio de Pedido"
          value={`$${averageOrderValue.toFixed(2)}`}
          icon={DollarSign}
        />
        <StatCard
          title="Tasa de Conversión"
          value={`${conversionRate.toFixed(1)}%`}
          icon={TrendingUp}
        />
        <StatCard
          title="Tiempo Promedio de Entrega"
          value="2.3 días"
          icon={Clock}
        />
      </div>
    </div>
  );
}