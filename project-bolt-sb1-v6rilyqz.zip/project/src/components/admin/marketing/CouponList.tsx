import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import { Edit, Trash2, ArrowUpDown } from 'lucide-react';
import type { Coupon } from '../../../types';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

interface CouponListProps {
  searchTerm: string;
  sortField: keyof Coupon;
  sortDirection: 'asc' | 'desc';
  onSort: (field: keyof Coupon) => void;
  onEdit: (coupon: Coupon) => void;
}

export default function CouponList({
  searchTerm,
  sortField,
  sortDirection,
  onSort,
  onEdit
}: CouponListProps) {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchCoupons();
  }, []);

  const fetchCoupons = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('coupons')
        .select('*');

      if (error) throw error;
      setCoupons(data || []);
    } catch (err) {
      console.error('Error fetching coupons:', err);
      setError('Error al cargar los cupones');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('¿Estás seguro de que deseas eliminar este cupón?')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('coupons')
        .delete()
        .eq('id', id);

      if (error) throw error;
      await fetchCoupons();
    } catch (err) {
      console.error('Error deleting coupon:', err);
      setError('Error al eliminar el cupón');
    }
  };

  const filteredCoupons = coupons
    .filter(coupon =>
      coupon.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      coupon.code.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      const aValue = a[sortField];
      const bValue = b[sortField];
      const comparison = aValue > bValue ? 1 : -1;
      return sortDirection === 'asc' ? comparison : -comparison;
    });

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-900 border border-red-700 text-red-200 p-4 rounded">
        {error}
      </div>
    );
  }

  return (
    <div className="bg-gray-800 rounded-lg shadow overflow-hidden">
      <table className="w-full">
        <thead className="bg-gray-900">
          <tr>
            <th className="text-left py-3 px-4">
              <button
                onClick={() => onSort('name')}
                className="flex items-center gap-1 text-gray-300 hover:text-primary"
              >
                Nombre
                <ArrowUpDown className="h-4 w-4" />
              </button>
            </th>
            <th className="text-left py-3 px-4">
              <button
                onClick={() => onSort('code')}
                className="flex items-center gap-1 text-gray-300 hover:text-primary"
              >
                Código
                <ArrowUpDown className="h-4 w-4" />
              </button>
            </th>
            <th className="text-left py-3 px-4">Descuento</th>
            <th className="text-left py-3 px-4">Usos</th>
            <th className="text-left py-3 px-4">Estado</th>
            <th className="text-left py-3 px-4">Acciones</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-700">
          {filteredCoupons.map(coupon => (
            <tr key={coupon.id} className="hover:bg-gray-700">
              <td className="py-3 px-4 text-white">{coupon.name}</td>
              <td className="py-3 px-4 text-white">{coupon.code}</td>
              <td className="py-3 px-4 text-white">
                {coupon.type === 'percentage'
                  ? `${coupon.value}%`
                  : `$${coupon.value.toFixed(2)}`}
              </td>
              <td className="py-3 px-4 text-white">
                {coupon.uses_count}/{coupon.max_uses || '∞'}
              </td>
              <td className="py-3 px-4">
                <span className={`px-2 py-1 rounded-full text-sm ${
                  coupon.is_active
                    ? 'bg-green-900 text-green-200'
                    : 'bg-red-900 text-red-200'
                }`}>
                  {coupon.is_active ? 'Activo' : 'Inactivo'}
                </span>
              </td>
              <td className="py-3 px-4">
                <div className="flex gap-2">
                  <button
                    onClick={() => onEdit(coupon)}
                    className="text-blue-400 hover:text-blue-300"
                    title="Editar"
                  >
                    <Edit className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(coupon.id)}
                    className="text-red-400 hover:text-red-300"
                    title="Eliminar"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}