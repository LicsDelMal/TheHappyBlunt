import React, { useState, useEffect } from 'react';
import { ChevronDown, ChevronUp, ShoppingCart, ImageOff, ChevronLeft, ChevronRight } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { Link } from 'react-router-dom';
import type { Product } from '../../types';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const [showDetails, setShowDetails] = useState(false);
  const [imageError, setImageError] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const { addToCart, loading } = useCart();
  const [images, setImages] = useState<string[]>([]);

  useEffect(() => {
    fetchProductImages();
  }, [product.id]);

  const fetchProductImages = async () => {
    try {
      const { data, error } = await supabase
        .from('product_images')
        .select('image_url')
        .eq('product_id', product.id)
        .order('display_order');

      if (error) throw error;

      if (data && data.length > 0) {
        const imageUrls = data.map(img => {
          const baseUrl = import.meta.env.VITE_SUPABASE_URL;
          return `${baseUrl}/storage/v1/object/public/product-images/${img.image_url}`;
        });
        setImages(imageUrls);
      } else if (product.image_url) {
        const baseUrl = import.meta.env.VITE_SUPABASE_URL;
        setImages([`${baseUrl}/storage/v1/object/public/product-images/${product.image_url}`]);
      }
    } catch (err) {
      console.error('Error fetching product images:', err);
      setImageError(true);
    }
  };

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent navigation when clicking the add to cart button
    await addToCart(product, 1);
  };

  const handleImageError = () => {
    setImageError(true);
  };

  const nextImage = (e: React.MouseEvent) => {
    e.preventDefault();
    setCurrentImageIndex((prev) => (prev + 1) % images.length);
  };

  const prevImage = (e: React.MouseEvent) => {
    e.preventDefault();
    setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  const renderImage = () => {
    if (imageError || images.length === 0) {
      return (
        <div className="w-full h-full flex items-center justify-center bg-gray-800">
          <div className="text-center text-gray-400">
            <ImageOff className="h-12 w-12 mx-auto mb-2" />
            <p className="text-sm">Imagen no disponible</p>
          </div>
        </div>
      );
    }

    return (
      <div className="relative w-full h-full">
        <img
          src={images[currentImageIndex]}
          alt={product.name}
          className="w-full h-full object-cover transition-opacity duration-300"
          onError={handleImageError}
          loading="lazy"
        />
        {images.length > 1 && (
          <>
            <button
              onClick={prevImage}
              className="absolute left-2 top-1/2 -translate-y-1/2 bg-black bg-opacity-50 p-1 rounded-full text-white hover:bg-opacity-75 transition-opacity opacity-0 group-hover:opacity-100"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              onClick={nextImage}
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-black bg-opacity-50 p-1 rounded-full text-white hover:bg-opacity-75 transition-opacity opacity-0 group-hover:opacity-100"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
            <div className="absolute bottom-2 right-2 bg-black bg-opacity-50 px-2 py-1 rounded text-xs text-white">
              {currentImageIndex + 1}/{images.length}
            </div>
          </>
        )}
      </div>
    );
  };

  return (
    <Link 
      to={`/product/${product.id}`}
      className="block group"
      id={`product-card-${product.id}`}
    >
      <div className="bg-gray-800 rounded-lg shadow-lg overflow-hidden border border-gray-700 hover:border-primary transition-all duration-300 transform hover:-translate-y-1">
        <div className="relative aspect-square">
          {renderImage()}
        </div>

        <div className="p-4">
          <h3 className="text-lg font-semibold mb-2 text-white">{product.name}</h3>
          <div className="flex items-center justify-between mb-2">
            <span className="text-2xl font-bold text-green-500">
              ${product.price.toFixed(2)}
            </span>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm text-gray-300">
              <span>Categoría:</span>
              <span className="font-medium">{product.category}</span>
            </div>
            <div className="flex items-center justify-between text-sm text-gray-300">
              <span>Stock:</span>
              <span className="font-medium">{product.stock} disponibles</span>
            </div>
          </div>

          <button
            onClick={(e) => {
              e.preventDefault();
              setShowDetails(!showDetails);
            }}
            className="w-full mt-2 flex items-center justify-center text-sm text-gray-400 hover:text-secondary transition-colors"
          >
            {showDetails ? (
              <>
                Menos detalles
                <ChevronUp className="h-4 w-4 ml-1" />
              </>
            ) : (
              <>
                Más detalles
                <ChevronDown className="h-4 w-4 ml-1" />
              </>
            )}
          </button>

          {showDetails && (
            <div className="mt-2 text-sm text-gray-300">
              <p>{product.description || 'Sin descripción disponible.'}</p>
            </div>
          )}

          <button
            onClick={handleAddToCart}
            disabled={loading || product.stock === 0}
            className="w-full mt-4 bg-primary text-white py-2 px-4 rounded-lg hover:bg-opacity-90 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 transition-colors"
          >
            <ShoppingCart className="h-5 w-5" />
            {loading ? 'Agregando...' : 'Agregar al carrito'}
          </button>
        </div>
      </div>
    </Link>
  );
}