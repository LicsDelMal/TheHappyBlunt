import React, { useState, useEffect } from 'react';
import { Search, SlidersHorizontal, X, ChevronDown, ChevronUp } from 'lucide-react';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

interface ProductFiltersProps {
  selectedCategory: string;
  setSelectedCategory: (category: string) => void;
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  priceRange: [number, number];
  setPriceRange: (range: [number, number]) => void;
  sortBy: string;
  setSortBy: (sort: string) => void;
}

interface Category {
  id: string;
  name: string;
  parent_id: string | null;
  level: number;
  display_order: number;
}

interface CategoryItemProps {
  category: Category;
  categories: Category[];
  selectedCategory: string;
  setSelectedCategory: (name: string) => void;
  expandedCategories: Record<string, boolean>;
  toggleCategory: (id: string, parentId: string | null) => void;
  level?: number;
}

const CategoryItem: React.FC<CategoryItemProps> = ({
  category,
  categories,
  selectedCategory,
  setSelectedCategory,
  expandedCategories,
  toggleCategory,
  level = 0
}) => {
  const childCategories = categories.filter(cat => cat.parent_id === category.id);
  const hasChildren = childCategories.length > 0;
  const isParent = !category.parent_id;

  return (
    <div className="space-y-0.5">
      <button
        onClick={() => {
          if (hasChildren) {
            toggleCategory(category.id, category.parent_id);
          }
          setSelectedCategory(category.name);
        }}
        className={`
          w-full flex items-center justify-between transition-colors
          ${level === 0 
            ? 'p-3 rounded-lg font-bold text-base' 
            : level === 1
              ? 'p-2.5 rounded-md font-semibold text-sm'
              : 'p-2 rounded text-sm font-normal'
          }
          ${selectedCategory === category.name
            ? 'bg-primary text-white'
            : isParent
              ? 'bg-gray-700 text-gray-200 hover:bg-gray-600'
              : level === 1
                ? 'bg-gray-700/70 text-gray-300 hover:bg-gray-600/70'
                : 'bg-gray-700/50 text-gray-400 hover:bg-gray-600/50'
          }
        `}
        style={{ paddingLeft: `${level * 1.25}rem` }}
      >
        <span className="truncate">{category.name}</span>
        {hasChildren && (
          expandedCategories[category.id] ? 
            <ChevronUp className={`h-4 w-4 flex-shrink-0 ${
              isParent ? 'text-gray-200' : 'text-gray-400'
            }`} /> : 
            <ChevronDown className={`h-4 w-4 flex-shrink-0 ${
              isParent ? 'text-gray-200' : 'text-gray-400'
            }`} />
        )}
      </button>

      {hasChildren && expandedCategories[category.id] && (
        <div className={`space-y-0.5 ${level > 0 ? 'ml-2' : ''}`}>
          {childCategories
            .sort((a, b) => a.display_order - b.display_order)
            .map(childCategory => (
              <CategoryItem
                key={childCategory.id}
                category={childCategory}
                categories={categories}
                selectedCategory={selectedCategory}
                setSelectedCategory={setSelectedCategory}
                expandedCategories={expandedCategories}
                toggleCategory={toggleCategory}
                level={level + 1}
              />
            ))}
        </div>
      )}
    </div>
  );
};

export default function ProductFilters({
  selectedCategory,
  setSelectedCategory,
  searchTerm,
  setSearchTerm,
  priceRange,
  setPriceRange,
  sortBy,
  setSortBy
}: ProductFiltersProps) {
  const [showFilters, setShowFilters] = useState(false);
  const [showCategories, setShowCategories] = useState(false);
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .order('display_order');

      if (error) throw error;
      setCategories(data || []);
    } catch (err) {
      console.error('Error fetching categories:', err);
    }
  };

  const handlePriceChange = (value: string, index: 0 | 1) => {
    const newValue = value === '' ? 0 : Math.max(0, parseInt(value));
    if (index === 0) {
      setPriceRange([newValue, Math.max(newValue, priceRange[1])]);
    } else {
      setPriceRange([Math.min(priceRange[0], newValue), newValue]);
    }
  };

  const toggleCategory = (categoryId: string, parentId: string | null) => {
    setExpandedCategories(prev => {
      const newState = { ...prev };
      
      // Close all categories at the same level (with the same parent)
      categories
        .filter(cat => cat.parent_id === parentId && cat.id !== categoryId)
        .forEach(cat => {
          delete newState[cat.id];
        });
      
      // Toggle the clicked category
      if (prev[categoryId]) {
        delete newState[categoryId];
      } else {
        newState[categoryId] = true;
      }
      
      return newState;
    });
  };

  return (
    <div className="bg-gray-800 rounded-lg shadow-lg p-4 mb-6">
      {/* Search Bar */}
      <div className="flex items-center gap-4 mb-4 lg:mb-0">
        <div className="flex-1 relative">
          <input
            type="text"
            placeholder="Buscar productos..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 text-base border rounded-lg focus:ring-2 focus:ring-primary bg-gray-700 text-white placeholder-gray-400"
          />
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>
          )}
        </div>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="p-3 border rounded-lg hover:bg-gray-700 bg-gray-700 text-white lg:hidden"
          aria-label="Toggle filters"
        >
          <SlidersHorizontal className="h-5 w-5" />
        </button>
      </div>

      {/* Filters Section */}
      <div className={`lg:block ${showFilters ? 'block' : 'hidden'} space-y-6`}>
        {/* Categories */}
        <div className="space-y-2">
          <button
            onClick={() => setShowCategories(!showCategories)}
            className="flex items-center justify-between w-full text-lg font-semibold text-white mb-2 hover:text-primary transition-colors"
          >
            <span>Categorías</span>
            {showCategories ? (
              <ChevronUp className="h-5 w-5" />
            ) : (
              <ChevronDown className="h-5 w-5" />
            )}
          </button>
          
          {showCategories && (
            <div className="space-y-1 mt-2">
              {categories
                .filter(cat => !cat.parent_id)
                .sort((a, b) => a.display_order - b.display_order)
                .map(category => (
                  <CategoryItem
                    key={category.id}
                    category={category}
                    categories={categories}
                    selectedCategory={selectedCategory}
                    setSelectedCategory={setSelectedCategory}
                    expandedCategories={expandedCategories}
                    toggleCategory={toggleCategory}
                  />
                ))}
            </div>
          )}
        </div>

        {/* Sort Options */}
        <div>
          <h3 className="text-lg font-semibold text-white mb-2">Ordenar por</h3>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="w-full px-4 py-3 text-base border rounded-lg focus:ring-2 focus:ring-primary bg-gray-700 text-white"
          >
            <option value="name">Nombre A-Z</option>
            <option value="-name">Nombre Z-A</option>
            <option value="price">Precio: Menor a Mayor</option>
            <option value="-price">Precio: Mayor a Menor</option>
          </select>
        </div>

        {/* Price Range */}
        <div>
          <h3 className="text-lg font-semibold text-white mb-2">Rango de precio</h3>
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex-1 min-w-[120px]">
              <label className="text-sm text-gray-400 mb-1 block">Mínimo</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">$</span>
                <input
                  type="number"
                  min="0"
                  value={priceRange[0]}
                  onChange={(e) => handlePriceChange(e.target.value, 0)}
                  className="w-full pl-8 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary bg-gray-700 text-white"
                />
              </div>
            </div>
            <div className="flex-1 min-w-[120px]">
              <label className="text-sm text-gray-400 mb-1 block">Máximo</label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">$</span>
                <input
                  type="number"
                  min="0"
                  value={priceRange[1]}
                  onChange={(e) => handlePriceChange(e.target.value, 1)}
                  className="w-full pl-8 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary bg-gray-700 text-white"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Clear Filters */}
        {(selectedCategory || searchTerm || priceRange[0] > 0 || priceRange[1] < 1000) && (
          <button
            onClick={() => {
              setSelectedCategory('');
              setSearchTerm('');
              setPriceRange([0, 1000]);
              setSortBy('name');
              setShowCategories(false);
              setExpandedCategories({});
            }}
            className="w-full px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors"
          >
            Limpiar filtros
          </button>
        )}
      </div>
    </div>
  );
}