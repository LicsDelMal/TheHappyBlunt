import React from 'react';
import type { SiteSettings } from '../../../types';

interface SecuritySettingsProps {
  settings: SiteSettings;
  onSettingsChange: (settings: SiteSettings) => void;
}

export default function SecuritySettings({ settings, onSettingsChange }: SecuritySettingsProps) {
  return (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Longitud Mínima de Contraseña
        </label>
        <input
          type="number"
          value={settings.passwordMinLength}
          onChange={e => onSettingsChange({...settings, passwordMinLength: Number(e.target.value)})}
          className="w-full p-2 bg-gray-700 border border-gray-600 rounded text-white"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Intentos Máximos de Login
        </label>
        <input
          type="number"
          value={settings.maxLoginAttempts}
          onChange={e => onSettingsChange({...settings, maxLoginAttempts: Number(e.target.value)})}
          className="w-full p-2 bg-gray-700 border border-gray-600 rounded text-white"
        />
      </div>

      <div className="flex items-center gap-4">
        <input
          type="checkbox"
          checked={settings.twoFactorAuth}
          onChange={e => onSettingsChange({...settings, twoFactorAuth: e.target.checked})}
          className="rounded border-gray-600 text-primary focus:ring-primary bg-gray-700"
        />
        <span className="text-white">Habilitar autenticación de dos factores</span>
      </div>
    </div>
  );
}