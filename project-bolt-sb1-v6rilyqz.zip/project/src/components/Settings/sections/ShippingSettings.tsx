import React from 'react';
import type { SiteSettings, ShippingZone } from '../../../types';

interface ShippingSettingsProps {
  settings: SiteSettings;
  onSettingsChange: (settings: SiteSettings) => void;
}

export default function ShippingSettings({ settings, onSettingsChange }: ShippingSettingsProps) {
  const addShippingZone = () => {
    const newZone: ShippingZone = { name: '', price: 0 };
    onSettingsChange({
      ...settings,
      shippingZones: [...settings.shippingZones, newZone]
    });
  };

  const updateShippingZone = (index: number, field: keyof ShippingZone, value: string | number) => {
    const updatedZones = [...settings.shippingZones];
    updatedZones[index] = { ...updatedZones[index], [field]: value };
    onSettingsChange({ ...settings, shippingZones: updatedZones });
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium text-white mb-4">Zonas de Envío</h3>
        {settings.shippingZones.map((zone, index) => (
          <div key={index} className="bg-gray-700 p-4 rounded mb-4">
            <div className="grid grid-cols-2 gap-4">
              <input
                type="text"
                value={zone.name}
                onChange={e => updateShippingZone(index, 'name', e.target.value)}
                placeholder="Nombre de la zona"
                className="p-2 bg-gray-600 border border-gray-500 rounded text-white"
              />
              <input
                type="number"
                value={zone.price}
                onChange={e => updateShippingZone(index, 'price', Number(e.target.value))}
                placeholder="Precio"
                className="p-2 bg-gray-600 border border-gray-500 rounded text-white"
              />
            </div>
          </div>
        ))}
        <button
          type="button"
          onClick={addShippingZone}
          className="mt-2 px-4 py-2 bg-gray-700 text-white rounded hover:bg-gray-600"
        >
          Añadir Zona
        </button>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Monto mínimo para envío gratis
        </label>
        <input
          type="number"
          value={settings.freeShippingThreshold}
          onChange={e => onSettingsChange({...settings, freeShippingThreshold: Number(e.target.value)})}
          className="w-full p-2 bg-gray-700 border border-gray-600 rounded text-white"
        />
      </div>
    </div>
  );
}