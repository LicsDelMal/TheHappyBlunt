import React from 'react';
import type { SiteSettings } from '../../../types';

interface LegalSettingsProps {
  settings: SiteSettings;
  onSettingsChange: (settings: SiteSettings) => void;
}

export default function LegalSettings({ settings, onSettingsChange }: LegalSettingsProps) {
  return (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Términos y Condiciones
        </label>
        <textarea
          value={settings.termsAndConditions}
          onChange={e => onSettingsChange({...settings, termsAndConditions: e.target.value})}
          className="w-full p-2 bg-gray-700 border border-gray-600 rounded text-white h-32"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Política de Privacidad
        </label>
        <textarea
          value={settings.privacyPolicy}
          onChange={e => onSettingsChange({...settings, privacyPolicy: e.target.value})}
          className="w-full p-2 bg-gray-700 border border-gray-600 rounded text-white h-32"
        />
      </div>

      <div className="flex items-center gap-4">
        <input
          type="checkbox"
          checked={settings.ageVerification}
          onChange={e => onSettingsChange({...settings, ageVerification: e.target.checked})}
          className="rounded border-gray-600 text-primary focus:ring-primary bg-gray-700"
        />
        <span className="text-white">Requerir verificación de edad</span>
      </div>
    </div>
  );
}