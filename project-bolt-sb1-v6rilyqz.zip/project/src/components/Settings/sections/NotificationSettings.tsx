import React from 'react';
import type { SiteSettings } from '../../../types';

interface NotificationSettingsProps {
  settings: SiteSettings;
  onSettingsChange: (settings: SiteSettings) => void;
}

export default function NotificationSettings({ settings, onSettingsChange }: NotificationSettingsProps) {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium text-white mb-4">Notificaciones por Email</h3>
        {Object.entries(settings.emailNotifications).map(([key, value]) => (
          <div key={key} className="flex items-center gap-4 mb-4">
            <input
              type="checkbox"
              checked={value}
              onChange={e => {
                onSettingsChange({
                  ...settings,
                  emailNotifications: {
                    ...settings.emailNotifications,
                    [key]: e.target.checked
                  }
                });
              }}
              className="rounded border-gray-600 text-primary focus:ring-primary bg-gray-700"
            />
            <span className="text-white capitalize">
              {key.replace(/([A-Z])/g, ' $1').toLowerCase()}
            </span>
          </div>
        ))}
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Email del Remitente
        </label>
        <input
          type="email"
          value={settings.emailSender}
          onChange={e => onSettingsChange({...settings, emailSender: e.target.value})}
          className="w-full p-2 bg-gray-700 border border-gray-600 rounded text-white"
        />
      </div>
    </div>
  );
}