import React from 'react';
import type { SiteSettings } from '../../../types';

interface PaymentSettingsProps {
  settings: SiteSettings;
  onSettingsChange: (settings: SiteSettings) => void;
}

export default function PaymentSettings({ settings, onSettingsChange }: PaymentSettingsProps) {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium text-white mb-4">Métodos de Pago</h3>
        <div className="space-y-4">
          {['stripe', 'paypal', 'crypto'].map(method => (
            <div key={method} className="flex items-center gap-4">
              <input
                type="checkbox"
                checked={settings.paymentMethods?.includes(method)}
                onChange={e => {
                  const methods = e.target.checked
                    ? [...(settings.paymentMethods || []), method]
                    : (settings.paymentMethods || []).filter(m => m !== method);
                  onSettingsChange({...settings, paymentMethods: methods});
                }}
                className="rounded border-gray-600 text-primary focus:ring-primary bg-gray-700"
              />
              <span className="text-white capitalize">{method}</span>
            </div>
          ))}
        </div>
      </div>

      {settings.paymentMethods?.includes('stripe') && (
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Stripe Public Key
            </label>
            <input
              type="text"
              value={settings.stripePublicKey || ''}
              onChange={e => onSettingsChange({...settings, stripePublicKey: e.target.value})}
              className="w-full p-2 bg-gray-700 border border-gray-600 rounded text-white"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Stripe Secret Key
            </label>
            <input
              type="password"
              value={settings.stripeSecretKey || ''}
              onChange={e => onSettingsChange({...settings, stripeSecretKey: e.target.value})}
              className="w-full p-2 bg-gray-700 border border-gray-600 rounded text-white"
            />
          </div>
        </div>
      )}
    </div>
  );
}