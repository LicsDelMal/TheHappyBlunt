import React from 'react';
import { Upload } from 'lucide-react';
import type { SiteSettings } from '../../../types';

interface GeneralSettingsProps {
  settings: SiteSettings;
  onSettingsChange: (settings: SiteSettings) => void;
  onLogoUpload: (e: React.ChangeEvent<HTMLInputElement>) => Promise<void>;
}

export default function GeneralSettings({ settings, onSettingsChange, onLogoUpload }: GeneralSettingsProps) {
  return (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Nombre del Sitio
        </label>
        <input
          type="text"
          value={settings.siteName}
          onChange={e => onSettingsChange({...settings, siteName: e.target.value})}
          className="w-full p-2 bg-gray-700 border border-gray-600 rounded text-white"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Descripción
        </label>
        <textarea
          value={settings.description}
          onChange={e => onSettingsChange({...settings, description: e.target.value})}
          className="w-full p-2 bg-gray-700 border border-gray-600 rounded text-white h-24"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Logo
        </label>
        <div className="flex items-center gap-4">
          {settings.logo && (
            <img src={settings.logo} alt="Logo" className="h-16 w-16 object-contain" />
          )}
          <label className="cursor-pointer bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded">
            <Upload className="inline-block mr-2 h-4 w-4" />
            Subir Logo
            <input
              type="file"
              accept="image/*"
              onChange={onLogoUpload}
              className="hidden"
            />
          </label>
        </div>
      </div>
    </div>
  );
}