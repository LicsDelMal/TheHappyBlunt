import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import { Save, CreditCard, Truck, Bell, Lock, Palette, FileText } from 'lucide-react';
import GeneralSettings from './sections/GeneralSettings';
import PaymentSettings from './sections/PaymentSettings';
import ShippingSettings from './sections/ShippingSettings';
import NotificationSettings from './sections/NotificationSettings';
import SecuritySettings from './sections/SecuritySettings';
import LegalSettings from './sections/LegalSettings';
import type { SiteSettings } from '../../types';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

const defaultSettings: SiteSettings = {
  siteName: 'The Happy Blunt',
  description: 'Tu destino confiable para productos cannábicos de calidad',
  logo: '',
  primaryColor: '#047857',
  paymentMethods: [],
  stripePublicKey: '',
  stripeSecretKey: '',
  shippingZones: [],
  freeShippingThreshold: 0,
  emailNotifications: {
    orderConfirmation: true,
    abandonedCart: true,
    orderShipped: true,
  },
  emailSender: '',
  emailTemplate: '',
  passwordMinLength: 8,
  maxLoginAttempts: 3,
  twoFactorAuth: false,
  termsAndConditions: '',
  privacyPolicy: '',
  ageVerification: true,
};

export default function SettingsForm() {
  const [activeTab, setActiveTab] = useState('general');
  const [settings, setSettings] = useState<SiteSettings>(defaultSettings);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('site_settings')
        .select('*')
        .single();

      if (error) throw error;
      if (data) {
        setSettings({
          ...defaultSettings,
          ...data,
        });
      }
    } catch (err) {
      console.error('Error loading settings:', err);
      setMessage({ type: 'error', text: 'Error al cargar la configuración' });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage({ type: '', text: '' });

    try {
      const { error } = await supabase
        .from('site_settings')
        .upsert(settings);

      if (error) throw error;
      setMessage({ type: 'success', text: 'Configuración guardada exitosamente' });
    } catch (err) {
      console.error('Error saving settings:', err);
      setMessage({ type: 'error', text: 'Error al guardar la configuración' });
    } finally {
      setLoading(false);
    }
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setLoading(true);
      const fileExt = file.name.split('.').pop();
      const fileName = `logo-${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('site-assets')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('site-assets')
        .getPublicUrl(fileName);

      setSettings({ ...settings, logo: publicUrl });
    } catch (err) {
      console.error('Error uploading logo:', err);
      setMessage({ type: 'error', text: 'Error al subir el logo' });
    } finally {
      setLoading(false);
    }
  };

  const tabs = [
    { id: 'general', label: 'General', icon: Palette },
    { id: 'payments', label: 'Pagos', icon: CreditCard },
    { id: 'shipping', label: 'Envíos', icon: Truck },
    { id: 'notifications', label: 'Notificaciones', icon: Bell },
    { id: 'security', label: 'Seguridad', icon: Lock },
    { id: 'legal', label: 'Legal', icon: FileText },
  ];

  const renderTab = () => {
    switch (activeTab) {
      case 'general':
        return <GeneralSettings 
          settings={settings} 
          onSettingsChange={setSettings} 
          onLogoUpload={handleLogoUpload}
        />;
      case 'payments':
        return <PaymentSettings 
          settings={settings} 
          onSettingsChange={setSettings}
        />;
      case 'shipping':
        return <ShippingSettings 
          settings={settings} 
          onSettingsChange={setSettings}
        />;
      case 'notifications':
        return <NotificationSettings 
          settings={settings} 
          onSettingsChange={setSettings}
        />;
      case 'security':
        return <SecuritySettings 
          settings={settings} 
          onSettingsChange={setSettings}
        />;
      case 'legal':
        return <LegalSettings 
          settings={settings} 
          onSettingsChange={setSettings}
        />;
      default:
        return null;
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {message.text && (
        <div className={`p-4 rounded ${
          message.type === 'error' ? 'bg-red-900 text-red-200' : 'bg-green-900 text-green-200'
        }`}>
          {message.text}
        </div>
      )}

      <div className="flex flex-wrap gap-2">
        {tabs.map(tab => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
              activeTab === tab.id
                ? 'bg-primary text-white'
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
          >
            <tab.icon className="h-4 w-4" />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="bg-gray-800 rounded-lg p-6">
        {renderTab()}
      </div>

      <div className="flex justify-end">
        <button
          type="submit"
          disabled={loading}
          className="flex items-center gap-2 bg-primary text-white px-6 py-2 rounded-lg hover:bg-opacity-90 disabled:opacity-50"
        >
          <Save className="h-4 w-4" />
          {loading ? 'Guardando...' : 'Guardar Cambios'}
        </button>
      </div>
    </form>
  );
}