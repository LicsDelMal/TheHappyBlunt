import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import { X, Upload, AlertCircle, Plus } from 'lucide-react';
import type { Product } from '../types';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

interface ProductFormProps {
  product?: Product;
  onClose: () => void;
  onSuccess: () => void;
}

interface ProductImage {
  id?: string;
  url: string;
  file?: File;
  isNew?: boolean;
}

// Define main categories and their subcategories
const CATEGORIES = {
  'Flor': {
    'Exótica': ['1Kg', '1/2Kg', '1/4Kg', 'Onza'],
    'Premium': ['1Kg', '1/2Kg', '1/4Kg', 'Onza'],
    'Alta Calidad': ['1Kg', '1/2Kg', '1/4Kg', 'Onza'],
    'Standar': ['1Kg', '1/2Kg', '1/4Kg', 'Onza']
  },
  'Vaporizadores': ['1 Gramo', '2 Gramos']
};

export default function ProductForm({ product, onClose, onSuccess }: ProductFormProps) {
  const [formData, setFormData] = useState({
    name: product?.name || '',
    description: product?.description || '',
    category: product?.category || '',
    subcategory: product?.subcategory || '',
    subsubcategory: '', // New field for third level categories (weights)
    price: product?.price?.toString() || '',
    stock: product?.stock?.toString() || '',
    is_visible: product?.is_visible ?? true
  });
  const [images, setImages] = useState<ProductImage[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [selectedMainCategory, setSelectedMainCategory] = useState<string>(product?.category || '');
  const [selectedQuality, setSelectedQuality] = useState<string>('');

  useEffect(() => {
    if (product?.id) {
      fetchProductImages();
    }
  }, [product]);

  const fetchProductImages = async () => {
    if (!product?.id) return;

    try {
      const { data, error } = await supabase
        .from('product_images')
        .select('*')
        .eq('product_id', product.id)
        .order('display_order');

      if (error) throw error;

      setImages(data.map(img => ({
        id: img.id,
        url: `${import.meta.env.VITE_SUPABASE_URL}/storage/v1/object/public/product-images/${img.image_url}`
      })));
    } catch (err) {
      console.error('Error fetching product images:', err);
      setError('Error al cargar las imágenes del producto');
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const newImages: ProductImage[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      newImages.push({
        url: URL.createObjectURL(file),
        file,
        isNew: true
      });
    }

    setImages(prev => [...prev, ...newImages]);
  };

  const handleImageDelete = async (index: number) => {
    const image = images[index];
    if (image.id) {
      try {
        const { error } = await supabase
          .from('product_images')
          .delete()
          .eq('id', image.id);

        if (error) throw error;
      } catch (err) {
        console.error('Error deleting image:', err);
        return;
      }
    }

    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleMainCategoryChange = (category: string) => {
    setSelectedMainCategory(category);
    setSelectedQuality('');
    setFormData(prev => ({
      ...prev,
      category: category,
      subcategory: '',
      subsubcategory: ''
    }));
  };

  const handleQualityChange = (quality: string) => {
    setSelectedQuality(quality);
    setFormData(prev => ({
      ...prev,
      subcategory: quality,
      subsubcategory: ''
    }));
  };

  const handleWeightChange = (weight: string) => {
    setFormData(prev => ({
      ...prev,
      subsubcategory: weight
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const productData = {
        name: formData.name,
        description: formData.description,
        category: formData.category,
        subcategory: formData.subcategory,
        price: parseFloat(formData.price),
        stock: parseInt(formData.stock),
        is_visible: formData.is_visible
      };

      let productId = product?.id;

      if (product) {
        const { error: updateError } = await supabase
          .from('products')
          .update(productData)
          .eq('id', product.id);

        if (updateError) throw updateError;
      } else {
        const { data: insertedProduct, error: insertError } = await supabase
          .from('products')
          .insert([productData])
          .select()
          .single();

        if (insertError) throw insertError;
        productId = insertedProduct.id;
      }

      // Handle image uploads
      for (const image of images) {
        if (image.isNew && image.file && productId) {
          const fileExt = image.file.name.split('.').pop();
          const fileName = `${productId}/${Date.now()}.${fileExt}`;

          const { error: uploadError } = await supabase.storage
            .from('product-images')
            .upload(fileName, image.file);

          if (uploadError) throw uploadError;

          const { error: insertError } = await supabase
            .from('product_images')
            .insert([{
              product_id: productId,
              image_url: fileName,
              display_order: images.indexOf(image)
            }]);

          if (insertError) throw insertError;
        }
      }

      onSuccess();
      onClose();
    } catch (err) {
      console.error('Error saving product:', err);
      setError('Error al guardar el producto');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-gray-800 rounded-lg p-6 w-full max-w-2xl relative max-h-[90vh] overflow-y-auto border border-gray-700">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white"
        >
          <X className="h-6 w-6" />
        </button>

        <h2 className="text-2xl font-bold text-white mb-6">
          {product ? 'Editar Producto' : 'Nuevo Producto'}
        </h2>

        {error && (
          <div className="mb-4 bg-red-900 border border-red-700 text-red-200 p-4 rounded flex items-center gap-2">
            <AlertCircle className="h-5 w-5" />
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Nombre *
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="w-full p-2 bg-gray-700 border rounded focus:ring-2 focus:ring-primary border-gray-600 text-white"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Categoría Principal *
              </label>
              <select
                value={selectedMainCategory}
                onChange={(e) => handleMainCategoryChange(e.target.value)}
                className="w-full p-2 bg-gray-700 border rounded focus:ring-2 focus:ring-primary border-gray-600 text-white"
                required
              >
                <option value="">Seleccionar categoría</option>
                {Object.keys(CATEGORIES).map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>

            {selectedMainCategory === 'Flor' && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">
                    Calidad *
                  </label>
                  <select
                    value={selectedQuality}
                    onChange={(e) => handleQualityChange(e.target.value)}
                    className="w-full p-2 bg-gray-700 border rounded focus:ring-2 focus:ring-primary border-gray-600 text-white"
                    required
                  >
                    <option value="">Seleccionar calidad</option>
                    {Object.keys(CATEGORIES.Flor).map((quality) => (
                      <option key={quality} value={quality}>
                        {quality}
                      </option>
                    ))}
                  </select>
                </div>

                {selectedQuality && (
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">
                      Peso *
                    </label>
                    <select
                      value={formData.subsubcategory}
                      onChange={(e) => handleWeightChange(e.target.value)}
                      className="w-full p-2 bg-gray-700 border rounded focus:ring-2 focus:ring-primary border-gray-600 text-white"
                      required
                    >
                      <option value="">Seleccionar peso</option>
                      {CATEGORIES.Flor[selectedQuality as keyof typeof CATEGORIES.Flor].map((weight) => (
                        <option key={weight} value={weight}>
                          {weight}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </>
            )}

            {selectedMainCategory === 'Vaporizadores' && (
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Tamaño *
                </label>
                <select
                  value={formData.subcategory}
                  onChange={(e) => setFormData({ ...formData, subcategory: e.target.value })}
                  className="w-full p-2 bg-gray-700 border rounded focus:ring-2 focus:ring-primary border-gray-600 text-white"
                  required
                >
                  <option value="">Seleccionar tamaño</option>
                  {(CATEGORIES.Vaporizadores as string[]).map((size) => (
                    <option key={size} value={size}>
                      {size}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Precio *
              </label>
              <input
                type="number"
                value={formData.price}
                onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
                className="w-full p-2 bg-gray-700 border rounded focus:ring-2 focus:ring-primary border-gray-600 text-white"
                required
                min="0"
                step="0.01"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Stock *
              </label>
              <input
                type="number"
                value={formData.stock}
                onChange={(e) => setFormData(prev => ({ ...prev, stock: e.target.value }))}
                className="w-full p-2 bg-gray-700 border rounded focus:ring-2 focus:ring-primary border-gray-600 text-white"
                required
                min="0"
              />
            </div>

            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Descripción
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                className="w-full p-2 bg-gray-700 border rounded focus:ring-2 focus:ring-primary border-gray-600 text-white h-24 resize-none"
              />
            </div>

            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Imágenes
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {images.map((image, index) => (
                  <div key={index} className="relative aspect-square">
                    <img
                      src={image.url}
                      alt={`Product ${index + 1}`}
                      className="w-full h-full object-cover rounded-lg"
                    />
                    <button
                      type="button"
                      onClick={() => handleImageDelete(index)}
                      className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ))}
                <label className="relative aspect-square bg-gray-700 rounded-lg border-2 border-dashed border-gray-600 hover:border-primary cursor-pointer flex items-center justify-center">
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                  <div className="text-center">
                    <Upload className="h-8 w-8 mx-auto text-gray-400" />
                    <span className="text-sm text-gray-400">Subir imagen</span>
                  </div>
                </label>
              </div>
            </div>

            <div className="col-span-2">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.is_visible}
                  onChange={(e) => setFormData(prev => ({ ...prev, is_visible: e.target.checked }))}
                  className="rounded border-gray-600 text-primary focus:ring-primary bg-gray-700"
                />
                <span className="text-gray-300">Producto visible</span>
              </label>
            </div>
          </div>

          <div className="flex justify-end gap-4 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-400 hover:text-white"
              disabled={loading}
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-primary text-white rounded hover:bg-opacity-90 disabled:opacity-50"
              disabled={loading}
            >
              {loading ? 'Guardando...' : (product ? 'Actualizar' : 'Crear')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}