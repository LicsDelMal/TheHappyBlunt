import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import AuthModal from './AuthModal';
import Logo from './navbar/Logo';
import Navigation from './navbar/Navigation';
import UserMenu from './navbar/UserMenu';
import MobileMenu from './navbar/MobileMenu';

export default function Navbar() {
  const { user } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const isAdmin = user?.role === 'admin';

  return (
    <>
      <nav className="psychedelic-gradient text-white relative">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <Logo />

            <div className="hidden md:flex items-center space-x-4">
              <Navigation isAdmin={isAdmin} />
              <UserMenu onAuthClick={() => setIsAuthModalOpen(true)} />
            </div>

            <MobileMenu 
              isOpen={isMenuOpen}
              onToggle={() => setIsMenuOpen(!isMenuOpen)}
              isAdmin={isAdmin}
              onAuthClick={() => setIsAuthModalOpen(true)}
            />
          </div>
        </div>
      </nav>

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />
    </>
  );
}