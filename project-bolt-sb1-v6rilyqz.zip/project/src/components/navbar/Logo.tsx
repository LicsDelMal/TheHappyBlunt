import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

const LOGO_URL = 'https://pdfclclvzeamwwwcbtjn.supabase.co/storage/v1/object/public/product-images//Logo-modified.png';

export default function Logo() {
  const [logoLoaded, setLogoLoaded] = useState(false);
  
  return (
    <Link to="/" className="flex items-center gap-2 text-xl font-display neon-text">
      <img 
        src={LOGO_URL}
        alt="The Happy Blunt"
        className={`h-10 w-10 object-contain transition-opacity duration-300 ${
          logoLoaded ? 'opacity-100' : 'opacity-0'
        }`}
        onLoad={() => setLogoLoaded(true)}
        onError={(e) => {
          console.error('Error loading logo:', e);
          setLogoLoaded(true); // Show placeholder even on error
        }}
      />
      The Happy Blunt
    </Link>
  );
}