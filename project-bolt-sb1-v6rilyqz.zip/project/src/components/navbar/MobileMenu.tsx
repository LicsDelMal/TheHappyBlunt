import { Menu, X } from 'lucide-react';
import Navigation from './Navigation';
import UserMenu from './UserMenu';

interface MobileMenuProps {
  isOpen: boolean;
  onToggle: () => void;
  isAdmin: boolean;
  onAuthClick: () => void;
}

export default function MobileMenu({ isOpen, onToggle, isAdmin, onAuthClick }: MobileMenuProps) {
  return (
    <>
      <button
        onClick={onToggle}
        className="md:hidden p-2 hover:bg-gray-700 rounded-lg transition-colors"
        aria-label={isOpen ? 'Cerrar menú' : 'Abrir menú'}
      >
        {isOpen ? (
          <X className="h-6 w-6 text-white" />
        ) : (
          <Menu className="h-6 w-6 text-white" />
        )}
      </button>

      <div
        className={`
          fixed inset-0 bg-gray-900 bg-opacity-95 backdrop-blur-sm z-50 md:hidden
          transition-transform duration-300 ease-in-out
          ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        `}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex justify-end p-4">
            <button
              onClick={onToggle}
              className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
              aria-label="Cerrar menú"
            >
              <X className="h-6 w-6 text-white" />
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="flex-1 px-4 py-6 space-y-6">
            <div className="space-y-4">
              <Navigation 
                isAdmin={isAdmin} 
                isMobile={true} 
                onMobileClick={onToggle}
              />
            </div>
            <div className="pt-6 border-t border-gray-700">
              <UserMenu 
                onAuthClick={onAuthClick} 
                isMobile={true} 
                onMobileClick={onToggle}
              />
            </div>
          </nav>
        </div>
      </div>
    </>
  );
}