import { User, Settings, LogOut } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

interface UserMenuProps {
  onAuthClick: () => void;
  isMobile?: boolean;
  onMobileClick?: () => void;
}

export default function UserMenu({ onAuthClick, isMobile, onMobileClick }: UserMenuProps) {
  const { user, signOut } = useAuth();

  const handleClick = () => {
    if (isMobile && onMobileClick) {
      onMobileClick();
    }
  };

  const linkClasses = `
    flex items-center gap-2 py-3 px-4 rounded-lg transition-colors
    ${isMobile ? 'text-lg w-full hover:bg-gray-700' : 'hover:text-accent'}
    font-display
  `;

  if (user) {
    return (
      <div className={`${isMobile ? 'flex flex-col space-y-2' : 'flex items-center space-x-6'}`}>
        <Link 
          to="/settings"
          className={linkClasses}
          onClick={handleClick}
        >
          <Settings className="h-5 w-5" />
          Configuración
        </Link>
        <button
          onClick={() => {
            signOut();
            handleClick();
          }}
          className={linkClasses}
        >
          <LogOut className="h-5 w-5" />
          Cerrar Sesión
        </button>
      </div>
    );
  }

  return (
    <button
      onClick={() => {
        onAuthClick();
        handleClick();
      }}
      className={linkClasses}
    >
      <User className="h-5 w-5" />
      Iniciar Sesión
    </button>
  );
}