import { Link } from 'react-router-dom';
import { ShoppingCart, Package, LayoutDashboard } from 'lucide-react';

interface NavigationProps {
  isAdmin: boolean;
  isMobile?: boolean;
  onMobileClick?: () => void;
}

export default function Navigation({ isAdmin, isMobile, onMobileClick }: NavigationProps) {
  const handleClick = () => {
    if (isMobile && onMobileClick) {
      onMobileClick();
    }
  };

  const linkClasses = `
    flex items-center gap-2 py-3 px-4 rounded-lg transition-colors
    ${isMobile ? 'text-lg w-full hover:bg-gray-700' : 'hover:text-accent'}
    font-display
  `;

  return (
    <div className={`${isMobile ? 'flex flex-col space-y-2' : 'flex items-center space-x-6'}`}>
      <Link 
        to="/products" 
        className={linkClasses}
        onClick={handleClick}
      >
        <Package className="h-5 w-5" />
        Productos
      </Link>
      
      {isAdmin && (
        <Link 
          to="/admin" 
          className={linkClasses}
          onClick={handleClick}
        >
          <LayoutDashboard className="h-5 w-5" />
          Admin
        </Link>
      )}
      
      <Link 
        to="/cart" 
        className={linkClasses}
        onClick={handleClick}
      >
        <ShoppingCart className="h-5 w-5" />
        Carrito
      </Link>
    </div>
  );
}