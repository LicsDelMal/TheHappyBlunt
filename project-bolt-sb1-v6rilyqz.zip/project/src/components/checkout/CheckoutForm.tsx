import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import { useCart } from '../../context/CartContext';
import { ArrowLeft, ArrowRight, MapPin, CreditCard, Truck } from 'lucide-react';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

interface CheckoutFormProps {
  onSuccess: () => void;
  onCancel: () => void;
}

const BANK_DETAILS = {
  name: "Dolores Gabriela",
  clabe: "728969000091958513",
  bank: "Spin by OXXO"
};

const STORAGE_KEY = 'checkout_state';

export default function CheckoutForm({ onSuccess, onCancel }: CheckoutFormProps) {
  const { items, clearCart } = useCart();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [currentStep, setCurrentStep] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const { step } = JSON.parse(saved);
      return step || 0;
    }
    return 0;
  });

  const [formData, setFormData] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const { data } = JSON.parse(saved);
      return data || {
        shipping: {
          fullName: '',
          email: '',
          phone: '',
          address: '',
          betweenStreets: '',
          references: '',
          city: '',
          state: '',
          zipCode: ''
        },
        payment: {
          method: 'cash',
          cardNumber: '',
          cardName: '',
          cardExpiry: '',
          cardCvc: ''
        }
      };
    }
    return {
      shipping: {
        fullName: '',
        email: '',
        phone: '',
        address: '',
        betweenStreets: '',
        references: '',
        city: '',
        state: '',
        zipCode: ''
      },
      payment: {
        method: 'cash',
        cardNumber: '',
        cardName: '',
        cardExpiry: '',
        cardCvc: ''
      }
    };
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      step: currentStep,
      data: formData
    }));
  }, [currentStep, formData]);

  useEffect(() => {
    return () => {
      localStorage.removeItem(STORAGE_KEY);
    };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (currentStep < 2) {
      setCurrentStep(prev => prev + 1);
      return;
    }

    setLoading(true);
    setError('');

    try {
      const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert({
          user_id: (await supabase.auth.getUser()).data.user?.id,
          total_amount: total,
          status: formData.payment.method === 'transfer' ? 'pendiente' : 'en_proceso',
          payment_method: formData.payment.method,
          shipping_address: formData.shipping
        })
        .select()
        .single();

      if (orderError) throw orderError;

      const orderItems = items.map(item => ({
        order_id: order.id,
        product_id: item.id,
        quantity: item.quantity,
        price: item.price
      }));

      const { error: itemsError } = await supabase
        .from('order_items')
        .insert(orderItems);

      if (itemsError) throw itemsError;

      await clearCart();
      localStorage.removeItem(STORAGE_KEY);
      onSuccess();
    } catch (err) {
      console.error('Error creating order:', err);
      setError('Error al procesar el pedido. Por favor intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  const renderShippingForm = () => (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Nombre Completo
        </label>
        <input
          type="text"
          value={formData.shipping.fullName}
          onChange={(e) => setFormData({
            ...formData,
            shipping: { ...formData.shipping, fullName: e.target.value }
          })}
          className="w-full p-4 bg-gray-700 border border-gray-600 rounded-lg text-white"
          placeholder="Nombre completo"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Teléfono
        </label>
        <input
          type="tel"
          value={formData.shipping.phone}
          onChange={(e) => setFormData({
            ...formData,
            shipping: { ...formData.shipping, phone: e.target.value }
          })}
          className="w-full p-4 bg-gray-700 border border-gray-600 rounded-lg text-white"
          placeholder="Número de teléfono"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Correo Electrónico (opcional)
        </label>
        <input
          type="email"
          value={formData.shipping.email}
          onChange={(e) => setFormData({
            ...formData,
            shipping: { ...formData.shipping, email: e.target.value }
          })}
          className="w-full p-4 bg-gray-700 border border-gray-600 rounded-lg text-white"
          placeholder="correo@ejemplo.com"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Dirección
        </label>
        <input
          type="text"
          value={formData.shipping.address}
          onChange={(e) => setFormData({
            ...formData,
            shipping: { ...formData.shipping, address: e.target.value }
          })}
          className="w-full p-4 bg-gray-700 border border-gray-600 rounded-lg text-white"
          placeholder="Calle y número"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Entre Calles (opcional)
        </label>
        <input
          type="text"
          value={formData.shipping.betweenStreets}
          onChange={(e) => setFormData({
            ...formData,
            shipping: { ...formData.shipping, betweenStreets: e.target.value }
          })}
          className="w-full p-4 bg-gray-700 border border-gray-600 rounded-lg text-white"
          placeholder="Entre qué calles se encuentra"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Referencias (opcional)
        </label>
        <textarea
          value={formData.shipping.references}
          onChange={(e) => setFormData({
            ...formData,
            shipping: { ...formData.shipping, references: e.target.value }
          })}
          className="w-full p-4 bg-gray-700 border border-gray-600 rounded-lg text-white h-24 resize-none"
          placeholder="Referencias para encontrar el domicilio"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Ciudad
          </label>
          <input
            type="text"
            value={formData.shipping.city}
            onChange={(e) => setFormData({
              ...formData,
              shipping: { ...formData.shipping, city: e.target.value }
            })}
            className="w-full p-4 bg-gray-700 border border-gray-600 rounded-lg text-white"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2">
            Estado
          </label>
          <input
            type="text"
            value={formData.shipping.state}
            onChange={(e) => setFormData({
              ...formData,
              shipping: { ...formData.shipping, state: e.target.value }
            })}
            className="w-full p-4 bg-gray-700 border border-gray-600 rounded-lg text-white"
            required
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Código Postal
        </label>
        <input
          type="text"
          value={formData.shipping.zipCode}
          onChange={(e) => setFormData({
            ...formData,
            shipping: { ...formData.shipping, zipCode: e.target.value }
          })}
          className="w-full p-4 bg-gray-700 border border-gray-600 rounded-lg text-white"
          required
        />
      </div>
    </div>
  );

  const renderPaymentForm = () => (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-300 mb-2">
          Método de Pago
        </label>
        <select
          value={formData.payment.method}
          onChange={(e) => setFormData({
            ...formData,
            payment: { ...formData.payment, method: e.target.value }
          })}
          className="w-full p-4 bg-gray-700 border border-gray-600 rounded-lg text-white"
          required
        >
          <option value="cash">Efectivo</option>
          <option value="transfer">Transferencia</option>
          <option value="card">Tarjeta</option>
        </select>
      </div>

      {formData.payment.method === 'transfer' && (
        <div className="bg-gray-700 p-4 rounded-lg space-y-3">
          <h4 className="text-lg font-semibold text-white mb-3">Datos Bancarios</h4>
          <div className="space-y-2">
            <div>
              <span className="text-gray-300">Nombre:</span>
              <p className="text-white font-medium">{BANK_DETAILS.name}</p>
            </div>
            <div>
              <span className="text-gray-300">CLABE:</span>
              <p className="text-white font-medium">{BANK_DETAILS.clabe}</p>
            </div>
            <div>
              <span className="text-gray-300">Banco:</span>
              <p className="text-white font-medium">{BANK_DETAILS.bank}</p>
            </div>
          </div>
          <p className="text-sm text-yellow-400 mt-3">
            Importante: Guarda una captura de tu comprobante de pago. El pedido se procesará una vez confirmado el pago.
          </p>
        </div>
      )}

      {formData.payment.method === 'card' && (
        <>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Número de Tarjeta
            </label>
            <input
              type="text"
              value={formData.payment.cardNumber}
              onChange={(e) => setFormData({
                ...formData,
                payment: { ...formData.payment, cardNumber: e.target.value }
              })}
              className="w-full p-4 bg-gray-700 border border-gray-600 rounded-lg text-white"
              placeholder="1234 5678 9012 3456"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Nombre en la Tarjeta
            </label>
            <input
              type="text"
              value={formData.payment.cardName}
              onChange={(e) => setFormData({
                ...formData,
                payment: { ...formData.payment, cardName: e.target.value }
              })}
              className="w-full p-4 bg-gray-700 border border-gray-600 rounded-lg text-white"
              required
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Vencimiento
              </label>
              <input
                type="text"
                value={formData.payment.cardExpiry}
                onChange={(e) => setFormData({
                  ...formData,
                  payment: { ...formData.payment, cardExpiry: e.target.value }
                })}
                className="w-full p-4 bg-gray-700 border border-gray-600 rounded-lg text-white"
                placeholder="MM/YY"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                CVC
              </label>
              <input
                type="text"
                value={formData.payment.cardCvc}
                onChange={(e) => setFormData({
                  ...formData,
                  payment: { ...formData.payment, cardCvc: e.target.value }
                })}
                className="w-full p-4 bg-gray-700 border border-gray-600 rounded-lg text-white"
                placeholder="123"
                required
              />
            </div>
          </div>
        </>
      )}
    </div>
  );

  const renderConfirmation = () => (
    <div className="space-y-6">
      <div className="bg-gray-700 p-4 rounded-lg">
        <h3 className="text-lg font-semibold text-white mb-4">Resumen del Pedido</h3>
        <div className="space-y-4">
          {items.map(item => (
            <div key={item.id} className="flex justify-between text-gray-300">
              <span>{item.name} x{item.quantity}</span>
              <span>${(item.price * item.quantity).toFixed(2)}</span>
            </div>
          ))}
          <div className="border-t border-gray-600 pt-4">
            <div className="flex justify-between text-white font-semibold">
              <span>Total</span>
              <span>${items.reduce((sum, item) => sum + item.price * item.quantity, 0).toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gray-700 p-4 rounded-lg">
        <h3 className="text-lg font-semibold text-white mb-4">Dirección de Envío</h3>
        <div className="text-gray-300">
          <p>{formData.shipping.fullName}</p>
          <p>{formData.shipping.phone}</p>
          {formData.shipping.email && <p>{formData.shipping.email}</p>}
          <p>{formData.shipping.address}</p>
          {formData.shipping.betweenStreets && <p>Entre calles: {formData.shipping.betweenStreets}</p>}
          {formData.shipping.references && <p>Referencias: {formData.shipping.references}</p>}
          <p>{formData.shipping.city}, {formData.shipping.state}</p>
          <p>CP: {formData.shipping.zipCode}</p>
        </div>
      </div>

      <div className="bg-gray-700 p-4 rounded-lg">
        <h3 className="text-lg font-semibold text-white mb-4">Método de Pago</h3>
        <p className="text-gray-300 capitalize">
          {formData.payment.method === 'transfer' ? 'Transferencia Bancaria' : formData.payment.method}
        </p>
        {formData.payment.method === 'transfer' && (
          <div className="mt-4 p-4 bg-gray-600 rounded-lg">
            <p className="text-sm text-yellow-400 mb-2">
              Importante: Realiza la transferencia con los siguientes datos:
            </p>
            <div className="space-y-2 text-gray-300">
              <p><span className="font-medium">Nombre:</span> {BANK_DETAILS.name}</p>
              <p><span className="font-medium">CLABE:</span> {BANK_DETAILS.clabe}</p>
              <p><span className="font-medium">Banco:</span> {BANK_DETAILS.bank}</p>
            </div>
          </div>
        )}
      </div>

      {formData.payment.method === 'transfer' && (
        <div className="bg-yellow-900/50 border border-yellow-700 text-yellow-200 p-4 rounded-lg">
          <p>Su pedido se completará una vez que se confirme el pago. Puede ver el estado de su pago en la sección de pedidos.</p>
        </div>
      )}
    </div>
  );

  const steps = [
    { title: 'Envío', icon: Truck, content: renderShippingForm },
    { title: 'Pago', icon: CreditCard, content: renderPaymentForm },
    { title: 'Confirmar', icon: MapPin, content: renderConfirmation }
  ];

  return (
    <div className="bg-gray-800 rounded-lg p-4 md:p-6">
      {error && (
        <div className="mb-6 bg-red-900 border border-red-700 text-red-200 p-4 rounded-lg">
          {error}
        </div>
      )}

      {/* Progress Steps */}
      <div className="mb-8">
        <div className="flex justify-between">
          {steps.map((step, index) => {
            const StepIcon = step.icon;
            return (
              <div
                key={index}
                className={`flex flex-col items-center w-1/3 ${
                  index === currentStep
                    ? 'text-primary'
                    : index < currentStep
                    ? 'text-green-500'
                    : 'text-gray-500'
                }`}
              >
                <div className="relative flex items-center justify-center w-10 h-10 rounded-full border-2 border-current mb-2">
                  <StepIcon className="w-5 h-5" />
                  {index < steps.length - 1 && (
                    <div className={`absolute left-full w-full h-0.5 ${
                      index < currentStep ? 'bg-green-500' : 'bg-gray-700'
                    }`} />
                  )}
                </div>
                <span className="text-sm font-medium hidden md:block">{step.title}</span>
              </div>
            );
          })}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {steps[currentStep].content()}

        <div className="flex justify-between pt-6">
          <button
            type="button"
            onClick={currentStep === 0 ? onCancel : () => setCurrentStep(prev => prev - 1)}
            className="flex items-center gap-2 px-6 py-3 text-gray-300 hover:text-white transition-colors"
            disabled={loading}
          >
            <ArrowLeft className="h-5 w-5" />
            {currentStep === 0 ? 'Volver' : 'Anterior'}
          </button>
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-3 bg-primary text-white rounded-lg hover:bg-opacity-90 disabled:opacity-50"
            disabled={loading}
          >
            {loading ? (
              'Procesando...'
            ) : currentStep === steps.length - 1 ? (
              'Confirmar Pedido'
            ) : (
              <>
                Siguiente
                <ArrowRight className="h-5 w-5" />
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}