import React from 'react';
import { AlertTriangle } from 'lucide-react';

interface DeleteConfirmationProps {
  title?: string;
  message?: string;
  onConfirm: () => void;
  onCancel: () => void;
  loading?: boolean;
}

export default function DeleteConfirmation({
  title = '¿Eliminar elemento?',
  message = 'Esta acción no se puede deshacer. ¿Estás seguro de que deseas continuar?',
  onConfirm,
  onCancel,
  loading = false,
}: DeleteConfirmationProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md border border-gray-700">
        <div className="flex items-center justify-center text-red-500 mb-4">
          <AlertTriangle className="h-12 w-12" />
        </div>
        
        <h2 className="text-xl font-bold text-center text-white mb-4">
          {title}
        </h2>
        
        <p className="text-gray-300 text-center mb-6">
          {message}
        </p>
        
        <div className="flex justify-center space-x-4">
          <button
            onClick={onCancel}
            className="px-4 py-2 text-gray-400 hover:text-gray-200"
            disabled={loading}
          >
            Cancelar
          </button>
          <button
            onClick={onConfirm}
            className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 disabled:opacity-50"
            disabled={loading}
          >
            {loading ? 'Eliminando...' : 'Eliminar'}
          </button>
        </div>
      </div>
    </div>
  );
}