import React, { useState } from 'react';
import { MoreHorizontal, Download, Search, ArrowUpDown } from 'lucide-react';
import type { UserProfile } from '../../types';

interface UserTableProps {
  users: UserProfile[];
  onEdit: (user: UserProfile) => void;
  onDelete: (user: UserProfile) => void;
  onBlock: (user: UserProfile) => void;
  onViewDetails: (user: UserProfile) => void;
}

export default function UserTable({ users, onEdit, onDelete, onBlock, onViewDetails }: UserTableProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<keyof UserProfile>('username');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const handleSort = (field: keyof UserProfile) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const filteredUsers = users
    .filter(user => {
      if (!searchTerm) return true;
      const searchLower = searchTerm.toLowerCase();
      const username = user.username?.toLowerCase() || '';
      return username.includes(searchLower);
    })
    .sort((a, b) => {
      const aValue = a[sortField] || '';
      const bValue = b[sortField] || '';
      const comparison = aValue > bValue ? 1 : -1;
      return sortDirection === 'asc' ? comparison : -comparison;
    });

  const paginatedUsers = filteredUsers.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const exportToCSV = () => {
    const headers = ['Usuario', 'Rol', 'Estado', 'Último Acceso'];
    const data = filteredUsers.map(user => [
      user.username || '',
      user.role || '',
      user.is_active ? 'Activo' : 'Inactivo',
      user.last_login ? new Date(user.last_login).toLocaleString() : ''
    ]);

    const csvContent = [headers, ...data]
      .map(row => row.join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'usuarios.csv';
    link.click();
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin':
        return 'bg-purple-900 text-purple-200';
      case 'seller':
        return 'bg-blue-900 text-blue-200';
      case 'support':
        return 'bg-teal-900 text-teal-200';
      default:
        return 'bg-gray-900 text-gray-200';
    }
  };

  return (
    <div className="bg-gray-800 rounded-lg shadow-xl">
      <div className="p-6 border-b border-gray-700">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex-1">
            <div className="relative">
              <input
                type="text"
                placeholder="Buscar usuarios..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-primary"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </div>
          
          <button
            onClick={exportToCSV}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-opacity-90"
          >
            <Download className="h-4 w-4" />
            Exportar CSV
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-900">
            <tr>
              <th className="text-left py-3 px-4">
                <button
                  onClick={() => handleSort('username')}
                  className="flex items-center gap-1 text-gray-300 hover:text-primary"
                >
                  Usuario
                  <ArrowUpDown className="h-4 w-4" />
                </button>
              </th>
              <th className="text-left py-3 px-4">
                <button
                  onClick={() => handleSort('role')}
                  className="flex items-center gap-1 text-gray-300 hover:text-primary"
                >
                  Rol
                  <ArrowUpDown className="h-4 w-4" />
                </button>
              </th>
              <th className="text-left py-3 px-4">Estado</th>
              <th className="text-left py-3 px-4">Último Acceso</th>
              <th className="text-left py-3 px-4">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-700">
            {paginatedUsers.map(user => (
              <tr key={user.id} className="hover:bg-gray-700">
                <td className="py-3 px-4 text-white">{user.username || '-'}</td>
                <td className="py-3 px-4">
                  <span className={`px-2 py-1 rounded-full text-sm ${getRoleColor(user.role)}`}>
                    {user.role || 'user'}
                  </span>
                </td>
                <td className="py-3 px-4">
                  <span className={`px-2 py-1 rounded-full text-sm ${
                    user.is_active 
                      ? 'bg-green-900 text-green-200' 
                      : 'bg-red-900 text-red-200'
                  }`}>
                    {user.is_active ? 'Activo' : 'Inactivo'}
                  </span>
                </td>
                <td className="py-3 px-4 text-gray-300">
                  {user.last_login ? new Date(user.last_login).toLocaleString() : '-'}
                </td>
                <td className="py-3 px-4">
                  <div className="relative group">
                    <button className="p-1 hover:bg-gray-600 rounded">
                      <MoreHorizontal className="h-5 w-5 text-gray-400" />
                    </button>
                    <div className="absolute right-0 mt-2 w-48 bg-gray-800 rounded-md shadow-lg hidden group-hover:block z-10 border border-gray-700">
                      <div className="py-1">
                        <button
                          onClick={() => onViewDetails(user)}
                          className="block w-full text-left px-4 py-2 text-sm text-gray-300 hover:bg-gray-700"
                        >
                          Ver Detalles
                        </button>
                        <button
                          onClick={() => onEdit(user)}
                          className="block w-full text-left px-4 py-2 text-sm text-gray-300 hover:bg-gray-700"
                        >
                          Editar
                        </button>
                        <button
                          onClick={() => onBlock(user)}
                          className="block w-full text-left px-4 py-2 text-sm text-gray-300 hover:bg-gray-700"
                        >
                          {user.is_active ? 'Bloquear' : 'Desbloquear'}
                        </button>
                        {user.role !== 'admin' && (
                          <button
                            onClick={() => onDelete(user)}
                            className="block w-full text-left px-4 py-2 text-sm text-red-400 hover:bg-gray-700"
                          >
                            Eliminar
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {filteredUsers.length > itemsPerPage && (
        <div className="flex justify-between items-center p-4 border-t border-gray-700">
          <p className="text-sm text-gray-400">
            Mostrando {(currentPage - 1) * itemsPerPage + 1} a{' '}
            {Math.min(currentPage * itemsPerPage, filteredUsers.length)} de{' '}
            {filteredUsers.length} usuarios
          </p>
          <div className="flex gap-2">
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="px-3 py-1 border border-gray-600 rounded hover:bg-gray-700 disabled:opacity-50 text-gray-300"
            >
              Anterior
            </button>
            <button
              onClick={() => setCurrentPage(p => p + 1)}
              disabled={currentPage * itemsPerPage >= filteredUsers.length}
              className="px-3 py-1 border border-gray-600 rounded hover:bg-gray-700 disabled:opacity-50 text-gray-300"
            >
              Siguiente
            </button>
          </div>
        </div>
      )}
    </div>
  );
}