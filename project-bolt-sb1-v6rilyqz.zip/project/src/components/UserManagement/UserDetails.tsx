import React, { useState } from 'react';
import { X, Save } from 'lucide-react';
import type { UserProfile, PurchaseHistory } from '../../types';

interface UserDetailsProps {
  user: UserProfile;
  purchaseHistory: PurchaseHistory[];
  onClose: () => void;
  onUpdateNotes: (userId: string, notes: string) => Promise<void>;
  onBlock: (user: UserProfile, days?: number) => Promise<void>;
}

export default function UserDetails({
  user,
  purchaseHistory,
  onClose,
  onUpdateNotes,
  onBlock
}: UserDetailsProps) {
  const [notes, setNotes] = useState(user.internal_notes || '');
  const [suspensionDays, setSuspensionDays] = useState(1);
  const [loading, setLoading] = useState(false);

  const handleSaveNotes = async () => {
    setLoading(true);
    await onUpdateNotes(user.id, notes);
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-gray-800 rounded-lg p-6 w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-white">Detalles del Usuario</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* User Info */}
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Información General</h3>
              <div className="bg-gray-700 rounded-lg p-4 space-y-2">
                <p className="text-gray-300">Nombre: {user.full_name}</p>
                <p className="text-gray-300">Usuario: {user.username}</p>
                <p className="text-gray-300">Rol: {user.role}</p>
                <p className="text-gray-300">Estado: {user.is_active ? 'Activo' : 'Inactivo'}</p>
                <p className="text-gray-300">
                  Último acceso: {new Date(user.last_login).toLocaleString()}
                </p>
              </div>
            </div>

            {/* Suspension Controls */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Control de Acceso</h3>
              <div className="bg-gray-700 rounded-lg p-4 space-y-4">
                <div className="flex items-center gap-4">
                  <input
                    type="number"
                    min="1"
                    value={suspensionDays}
                    onChange={(e) => setSuspensionDays(parseInt(e.target.value))}
                    className="w-20 px-2 py-1 bg-gray-600 border border-gray-500 rounded text-white"
                  />
                  <span className="text-gray-300">días</span>
                  <button
                    onClick={() => onBlock(user, suspensionDays)}
                    className="px-4 py-2 bg-yellow-600 text-white rounded hover:bg-yellow-700"
                    disabled={loading}
                  >
                    Suspender
                  </button>
                </div>
                <button
                  onClick={() => onBlock(user)}
                  className={`px-4 py-2 rounded ${
                    user.is_active
                      ? 'bg-red-600 hover:bg-red-700'
                      : 'bg-green-600 hover:bg-green-700'
                  } text-white`}
                  disabled={loading}
                >
                  {user.is_active ? 'Bloquear' : 'Desbloquear'}
                </button>
              </div>
            </div>

            {/* Internal Notes */}
            <div>
              <h3 className="text-lg font-semibold text-white mb-2">Notas Internas</h3>
              <div className="bg-gray-700 rounded-lg p-4">
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full h-32 px-3 py-2 bg-gray-600 border border-gray-500 rounded text-white resize-none"
                  placeholder="Añadir notas sobre el cliente..."
                />
                <button
                  onClick={handleSaveNotes}
                  className="mt-2 px-4 py-2 bg-primary text-white rounded hover:bg-opacity-90 flex items-center gap-2"
                  disabled={loading}
                >
                  <Save className="h-4 w-4" />
                  Guardar Notas
                </button>
              </div>
            </div>
          </div>

          {/* Purchase History */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-2">Historial de Compras</h3>
            <div className="bg-gray-700 rounded-lg p-4">
              {purchaseHistory.length > 0 ? (
                <div className="space-y-4">
                  {purchaseHistory.map((purchase) => (
                    <div
                      key={purchase.id}
                      className="border-b border-gray-600 last:border-0 pb-4"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="text-white">
                            Orden #{purchase.id.slice(0, 8)}
                          </p>
                          <p className="text-sm text-gray-400">
                            {new Date(purchase.order_date).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-white">
                            ${purchase.total_amount.toFixed(2)}
                          </p>
                          <span
                            className={`text-sm px-2 py-1 rounded ${
                              purchase.status === 'completed'
                                ? 'bg-green-900 text-green-200'
                                : purchase.status === 'pending'
                                ? 'bg-yellow-900 text-yellow-200'
                                : 'bg-red-900 text-red-200'
                            }`}
                          >
                            {purchase.status}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-400">No hay compras registradas</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}