// Add Category type to existing types file
export interface Category {
  id: string;
  name: string;
  parent_id?: string;
  level: number;
  display_order: number;
  created_at: string;
}