import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Navigate } from 'react-router-dom';
import { createClient } from '@supabase/supabase-js';
import { Package, Users, Settings, LayoutDashboard, Menu, X, Tag, Truck, MessageCircle } from 'lucide-react';
import DashboardSection from '../components/admin/DashboardSection';
import ProductsSection from '../components/admin/ProductsSection';
import UsersSection from '../components/admin/UsersSection';
import OrdersSection from '../components/admin/OrdersSection';
import MarketingSection from '../components/admin/MarketingSection';
import SupportSection from '../components/admin/SupportSection';
import SettingsForm from '../components/Settings/SettingsForm';
import CategoriesSection from '../components/admin/categories/CategoriesSection';
import type { Product, UserProfile } from '../types';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

const menuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'products', label: 'Productos', icon: Package },
  { id: 'categories', label: 'Categorías', icon: Tag },
  { id: 'orders', label: 'Pedidos', icon: Truck },
  { id: 'users', label: 'Usuarios', icon: Users },
  { id: 'marketing', label: 'Marketing', icon: Tag },
  { id: 'support', label: 'Soporte', icon: MessageCircle },
  { id: 'settings', label: 'Configuración', icon: Settings },
];

export default function Admin() {
  const { user } = useAuth();
  const [activeSection, setActiveSection] = useState('dashboard');
  const [products, setProducts] = useState<Product[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    try {
      setLoading(true);
      const [productsData, usersData] = await Promise.all([
        supabase.from('products').select('*'),
        supabase.from('user_profiles').select('*')
      ]);

      if (productsData.error) throw productsData.error;
      if (usersData.error) throw usersData.error;

      setProducts(productsData.data || []);
      setUsers(usersData.data || []);
    } catch (err) {
      console.error('Error fetching data:', err);
      setError('Error al cargar los datos');
    } finally {
      setLoading(false);
    }
  };

  const renderContent = () => {
    if (loading) {
      return (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      );
    }

    if (error) {
      return (
        <div className="bg-red-900 border border-red-700 text-red-100 px-4 py-3 rounded">
          {error}
        </div>
      );
    }

    switch (activeSection) {
      case 'dashboard':
        return <DashboardSection products={products} users={users} />;
      case 'products':
        return (
          <ProductsSection
            products={products}
            categories={{}}
            onProductsChange={fetchInitialData}
          />
        );
      case 'categories':
        return <CategoriesSection />;
      case 'orders':
        return <OrdersSection />;
      case 'users':
        return (
          <UsersSection
            users={users}
            onUsersChange={fetchInitialData}
          />
        );
      case 'marketing':
        return <MarketingSection />;
      case 'support':
        return <SupportSection />;
      case 'settings':
        return <SettingsForm />;
      default:
        return <div>Sección no encontrada</div>;
    }
  };

  if (!user || user.role !== 'admin') {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Mobile Header */}
      <div className="lg:hidden bg-gray-800 text-white p-4 flex items-center justify-between">
        <h1 className="text-xl font-bold text-primary">Panel Admin</h1>
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-2 hover:bg-gray-700 rounded-lg"
        >
          {isMobileMenuOpen ? (
            <X className="h-6 w-6" />
          ) : (
            <Menu className="h-6 w-6" />
          )}
        </button>
      </div>

      <div className="flex flex-col lg:flex-row">
        {/* Sidebar - Mobile (Overlay) */}
        <aside
          className={`
            lg:hidden fixed inset-0 z-50 bg-gray-800 transform transition-transform duration-300 ease-in-out
            ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
          `}
        >
          <div className="p-4 h-full overflow-y-auto">
            <nav className="space-y-2">
              {menuItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveSection(item.id);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    activeSection === item.id
                      ? 'bg-primary text-white'
                      : 'text-gray-300 hover:bg-gray-700'
                  }`}
                >
                  <item.icon className="h-5 w-5" />
                  {item.label}
                </button>
              ))}
            </nav>
          </div>
        </aside>

        {/* Sidebar - Desktop */}
        <aside className="hidden lg:block w-64 bg-gray-800 min-h-screen">
          <div className="p-6 border-b border-gray-700">
            <h1 className="text-xl font-bold text-primary">Panel Admin</h1>
          </div>
          <nav className="p-4">
            <ul className="space-y-2">
              {menuItems.map(item => (
                <li key={item.id}>
                  <button
                    onClick={() => setActiveSection(item.id)}
                    className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg transition-colors ${
                      activeSection === item.id
                        ? 'bg-primary text-white'
                        : 'text-gray-300 hover:bg-gray-700'
                    }`}
                  >
                    <item.icon className="h-5 w-5" />
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-4 lg:p-8">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-white">
              {menuItems.find(item => item.id === activeSection)?.label}
            </h1>
          </div>
          <div className="bg-gray-800 rounded-lg shadow-xl p-4 lg:p-6">
            {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
}