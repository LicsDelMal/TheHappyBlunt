import React, { useState, useEffect } from 'react';
import { Trash2, Plus, Minus, ArrowLeft, ShoppingBag } from 'lucide-react';
import { createClient } from '@supabase/supabase-js';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import CheckoutForm from '../components/checkout/CheckoutForm';
import { Link } from 'react-router-dom';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

export default function Cart() {
  const { items, removeFromCart, updateQuantity, loading, error } = useCart();
  const { user } = useAuth();
  const [showCheckout, setShowCheckout] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(false);
  const [productImages, setProductImages] = useState<Record<string, string>>({});

  useEffect(() => {
    fetchProductImages();
  }, [items]);

  const fetchProductImages = async () => {
    try {
      for (const item of items) {
        if (productImages[item.id]) continue;

        const { data: imageData, error: imageError } = await supabase
          .from('product_images')
          .select('image_url')
          .eq('product_id', item.id)
          .order('display_order')
          .limit(1);

        if (imageError) throw imageError;

        let imageUrl = '';
        if (imageData && imageData.length > 0) {
          imageUrl = `${import.meta.env.VITE_SUPABASE_URL}/storage/v1/object/public/product-images/${imageData[0].image_url}`;
        } else if (item.image_url) {
          imageUrl = `${import.meta.env.VITE_SUPABASE_URL}/storage/v1/object/public/product-images/${item.image_url}`;
        }

        if (imageUrl) {
          setProductImages(prev => ({
            ...prev,
            [item.id]: imageUrl
          }));
        }
      }
    } catch (err) {
      console.error('Error fetching product images:', err);
    }
  };

  if (!user) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-gray-800 rounded-lg p-8 text-center">
          <ShoppingBag className="h-16 w-16 text-primary mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-4">Inicia sesión para ver tu carrito</h2>
          <p className="text-gray-300 mb-6">
            Necesitas iniciar sesión para acceder a tu carrito y realizar compras.
          </p>
          <button
            onClick={() => window.location.href = '/'}
            className="bg-primary text-white px-6 py-3 rounded-lg hover:bg-opacity-90"
          >
            Iniciar Sesión
          </button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-red-900 border border-red-700 text-red-200 p-4 rounded-lg">
          {error}
        </div>
      </div>
    );
  }

  if (orderSuccess) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-gray-800 rounded-lg p-8 text-center">
          <div className="w-16 h-16 bg-green-900 rounded-full flex items-center justify-center mx-auto mb-6">
            <ShoppingBag className="h-8 w-8 text-green-200" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-4">¡Pedido Realizado con Éxito!</h2>
          <p className="text-gray-300 mb-6">
            Gracias por tu compra. Te enviaremos un correo con los detalles de tu pedido.
          </p>
          <Link
            to="/products"
            className="inline-flex items-center gap-2 bg-primary text-white px-6 py-3 rounded-lg hover:bg-opacity-90"
          >
            <ArrowLeft className="h-5 w-5" />
            Seguir Comprando
          </Link>
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-gray-800 rounded-lg p-8 text-center">
          <ShoppingBag className="h-16 w-16 text-gray-600 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-4">Tu carrito está vacío</h2>
          <p className="text-gray-300 mb-6">
            ¡Explora nuestros productos y encuentra algo que te guste!
          </p>
          <Link
            to="/products"
            className="inline-flex items-center gap-2 bg-primary text-white px-6 py-3 rounded-lg hover:bg-opacity-90"
          >
            <ArrowLeft className="h-5 w-5" />
            Ver Productos
          </Link>
        </div>
      </div>
    );
  }

  if (showCheckout) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8 text-white">Checkout</h1>
        <CheckoutForm
          onSuccess={() => setOrderSuccess(true)}
          onCancel={() => setShowCheckout(false)}
        />
      </div>
    );
  }

  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-white">Carrito de Compras</h1>

      <div className="bg-gray-800 rounded-lg shadow-xl overflow-hidden">
        {/* Cart Items */}
        <div className="divide-y divide-gray-700">
          {items.map(item => (
            <div key={item.id} className="p-4 md:p-6">
              <div className="flex gap-4">
                <div className="w-24 h-24 bg-gray-900 rounded-lg overflow-hidden flex-shrink-0">
                  {productImages[item.id] ? (
                    <img
                      src={productImages[item.id]}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gray-800">
                      <div className="animate-pulse bg-gray-700 w-full h-full" />
                    </div>
                  )}
                </div>
                
                <div className="flex-1">
                  <h3 className="font-semibold text-white text-lg mb-1">{item.name}</h3>
                  <p className="text-gray-400 mb-4">${item.price.toFixed(2)}</p>
                  
                  <div className="flex items-center gap-4">
                    <div className="flex items-center bg-gray-700 rounded-lg">
                      <button
                        onClick={() => updateQuantity(item.id, Math.max(1, item.quantity - 1))}
                        className="p-2 hover:bg-gray-600 rounded-l-lg text-gray-300 transition-colors"
                        aria-label="Reducir cantidad"
                      >
                        <Minus className="h-5 w-5" />
                      </button>
                      <span className="w-12 text-center text-white">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="p-2 hover:bg-gray-600 rounded-r-lg text-gray-300 transition-colors"
                        aria-label="Aumentar cantidad"
                      >
                        <Plus className="h-5 w-5" />
                      </button>
                    </div>
                    
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="p-2 text-red-400 hover:text-red-300 hover:bg-gray-700 rounded-lg transition-colors"
                      aria-label="Eliminar producto"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>

                <div className="text-right">
                  <p className="text-lg font-semibold text-green-500">
                    ${(item.price * item.quantity).toFixed(2)}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Cart Summary */}
        <div className="bg-gray-900 p-6">
          <div className="flex justify-between items-center mb-6">
            <span className="text-lg text-white">Total:</span>
            <span className="text-2xl font-bold text-green-500">${total.toFixed(2)}</span>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <Link
              to="/products"
              className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3 border border-gray-600 text-gray-300 rounded-lg hover:bg-gray-800 transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
              Seguir Comprando
            </Link>
            <button
              onClick={() => setShowCheckout(true)}
              className="flex-1 bg-primary text-white px-6 py-3 rounded-lg hover:bg-opacity-90 transition-colors"
            >
              Proceder al pago
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}