import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { createClient } from '@supabase/supabase-js';
import { ShoppingCart, Star, ChevronLeft, ChevronRight, Package } from 'lucide-react';
import { useCart } from '../context/CartContext';
import ProductCard from '../components/products/ProductCard';
import type { Product } from '../types';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

export default function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState<Product | null>(null);
  const [images, setImages] = useState<string[]>([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [popularProducts, setPopularProducts] = useState<Product[]>([]);
  const { addToCart, loading } = useCart();
  const [error, setError] = useState('');

  useEffect(() => {
    fetchProduct();
    window.scrollTo(0, 0);
  }, [id]);

  const fetchProduct = async () => {
    try {
      // Fetch product details
      const { data: productData, error: productError } = await supabase
        .from('products')
        .select('*')
        .eq('id', id)
        .single();

      if (productError) throw productError;
      if (!productData) throw new Error('Producto no encontrado');

      setProduct(productData);

      // Fetch product images
      const { data: imageData, error: imageError } = await supabase
        .from('product_images')
        .select('image_url')
        .eq('product_id', id)
        .order('display_order');

      if (imageError) throw imageError;

      const imageUrls = imageData.length > 0
        ? imageData.map(img => `${import.meta.env.VITE_SUPABASE_URL}/storage/v1/object/public/product-images/${img.image_url}`)
        : productData.image_url 
          ? [`${import.meta.env.VITE_SUPABASE_URL}/storage/v1/object/public/product-images/${productData.image_url}`]
          : [];

      setImages(imageUrls);

      // Fetch related products
      const { data: relatedData, error: relatedError } = await supabase
        .from('products')
        .select('*')
        .eq('category', productData.category)
        .neq('id', id)
        .limit(4);

      if (relatedError) throw relatedError;
      setRelatedProducts(relatedData || []);

      // Fetch random products for the popular section
      const { data: randomProducts, error: randomError } = await supabase
        .from('products')
        .select('*')
        .neq('id', id)
        .limit(4);

      if (randomError) throw randomError;
      setPopularProducts(randomProducts || []);

    } catch (err) {
      console.error('Error fetching product:', err);
      setError('Error al cargar el producto');
    }
  };

  const handleAddToCart = async () => {
    if (!product) return;
    await addToCart(product, quantity);
  };

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  if (error) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="bg-red-900 border border-red-700 text-red-100 p-4 rounded">
          {error}
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Product Detail Section */}
      <div className="bg-gray-800 rounded-lg shadow-xl overflow-hidden">
        <div className="grid md:grid-cols-2 gap-8 p-8">
          {/* Image Gallery */}
          <div className="relative aspect-square bg-gray-900 rounded-lg overflow-hidden">
            {images.length > 0 ? (
              <>
                <img
                  src={images[currentImageIndex]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
                {images.length > 1 && (
                  <>
                    <button
                      onClick={prevImage}
                      className="absolute left-4 top-1/2 -translate-y-1/2 bg-black bg-opacity-50 p-2 rounded-full text-white hover:bg-opacity-75"
                    >
                      <ChevronLeft className="h-6 w-6" />
                    </button>
                    <button
                      onClick={nextImage}
                      className="absolute right-4 top-1/2 -translate-y-1/2 bg-black bg-opacity-50 p-2 rounded-full text-white hover:bg-opacity-75"
                    >
                      <ChevronRight className="h-6 w-6" />
                    </button>
                    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black bg-opacity-50 px-3 py-1 rounded-full text-white text-sm">
                      {currentImageIndex + 1} / {images.length}
                    </div>
                  </>
                )}
              </>
            ) : (
              <div className="flex items-center justify-center h-full">
                <Package className="h-16 w-16 text-gray-600" />
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">{product.name}</h1>
              <div className="flex items-center gap-4">
                <div className="flex items-center">
                  <Star className="h-5 w-5 text-yellow-400 fill-current" />
                  <span className="ml-1 text-gray-300">4.5</span>
                </div>
                <span className="text-gray-400">|</span>
                <span className="text-gray-300">{product.category}</span>
              </div>
            </div>

            <div className="border-t border-gray-700 pt-6">
              <div className="text-4xl font-bold text-green-500 mb-4">
                ${product.price.toFixed(2)}
              </div>
              <p className="text-gray-300">{product.description || 'Sin descripción disponible.'}</p>
            </div>

            <div className="border-t border-gray-700 pt-6">
              <div className="flex items-center gap-4 mb-6">
                <label className="text-gray-300">Cantidad:</label>
                <div className="flex items-center">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-1 bg-gray-700 text-white rounded-l hover:bg-gray-600"
                  >
                    -
                  </button>
                  <span className="px-4 py-1 bg-gray-700 text-white">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-1 bg-gray-700 text-white rounded-r hover:bg-gray-600"
                  >
                    +
                  </button>
                </div>
              </div>

              <button
                onClick={handleAddToCart}
                disabled={loading || product.stock === 0}
                className="w-full bg-primary text-white py-3 rounded-lg hover:bg-opacity-90 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                <ShoppingCart className="h-5 w-5" />
                {loading ? 'Agregando...' : 'Agregar al carrito'}
              </button>

              {product.stock === 0 && (
                <p className="text-red-500 text-sm mt-2">Producto agotado</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Related Products Section */}
      <div className="mt-12">
        <h2 className="text-2xl font-bold text-white mb-6">Productos Relacionados</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {relatedProducts.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>

      {/* Popular Products Section */}
      <div className="mt-12">
        <h2 className="text-2xl font-bold text-white mb-6">También te puede interesar</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {popularProducts.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
}