import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Star, Package, Shield, Truck, Heart, Leaf, Cookie, FlaskRound as Flask, Box, Brain } from 'lucide-react';

const LOGO_URL = 'https://pdfclclvzeamwwwcbtjn.supabase.co/storage/v1/object/public/product-images//Logo-modified.png';

export default function Home() {
  const [logoLoaded, setLogoLoaded] = useState(false);

  const mainCategories = [
    {
      name: 'FLOR',
      icon: Leaf,
      color: 'from-green-500 to-green-700',
      description: 'Variedades premium de cannabis',
      subcategories: ['1KG', '1/2KG', '1/4KG', 'ONZAS', 'TOQUES']
    },
    {
      name: 'COMESTIBLES',
      icon: Cookie,
      color: 'from-yellow-500 to-yellow-700',
      description: 'Deliciosos productos infusionados',
      subcategories: ['Americanos', 'Caseros']
    },
    {
      name: 'EXTRACTOS',
      icon: Flask,
      color: 'from-purple-500 to-purple-700',
      description: 'Concentrados de alta pureza',
      subcategories: ['Cartuchos', 'Desechables', 'Sólidos']
    },
    {
      name: 'INSUMOS',
      icon: Box,
      color: 'from-blue-500 to-blue-700',
      description: 'Todo lo necesario para tu experiencia',
      subcategories: ['Para Wax', 'Para Weed']
    },
    {
      name: 'PSICOTROPICOS',
      icon: Brain,
      color: 'from-pink-500 to-pink-700',
      description: 'Experiencias psicodélicas seguras',
      subcategories: ['LSD', 'Hongos']
    }
  ];

  return (
    <div className="min-h-screen bg-dark">
      {/* Hero Section */}
      <div className="relative hero-background py-20">
        <div className="max-w-4xl mx-auto text-center px-4">
          <img 
            src={LOGO_URL}
            alt="The Happy Blunt" 
            className={`w-48 h-48 mx-auto mb-8 animate-float object-contain transition-opacity duration-300 ${
              logoLoaded ? 'opacity-100' : 'opacity-0'
            }`}
            onLoad={() => setLogoLoaded(true)}
            onError={(e) => {
              console.error('Error loading logo:', e);
              setLogoLoaded(true);
            }}
          />
          <h1 className="text-6xl font-display neon-text mb-6 animate-fadeIn">
            THE HAPPY BLUNT
          </h1>
          <p className="text-2xl font-body mb-8 animate-fadeIn delay-200">
            Tu Experiencia de Cannabis Elevada
          </p>
          <Link
            to="/products"
            className="inline-block bg-accent text-dark px-8 py-3 rounded-full text-lg font-semibold hover:bg-opacity-90 transition-colors neon-border animate-fadeIn delay-300"
          >
            Explorar Productos
          </Link>
        </div>
      </div>

      {/* Features Grid */}
      <div className="max-w-6xl mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          <div className="bg-gray-800 p-6 rounded-xl border border-primary hover:scale-105 transition-transform duration-300">
            <Star className="h-12 w-12 text-primary mx-auto mb-4" />
            <h3 className="text-xl font-display text-white mb-2 text-center">Alta Calidad</h3>
            <p className="text-gray-300 text-center">Productos premium seleccionados cuidadosamente</p>
          </div>
          <div className="bg-gray-800 p-6 rounded-xl border border-primary hover:scale-105 transition-transform duration-300">
            <Shield className="h-12 w-12 text-primary mx-auto mb-4" />
            <h3 className="text-xl font-display text-white mb-2 text-center">Seguridad</h3>
            <p className="text-gray-300 text-center">Envíos discretos y seguros garantizados</p>
          </div>
          <div className="bg-gray-800 p-6 rounded-xl border border-primary hover:scale-105 transition-transform duration-300">
            <Truck className="h-12 w-12 text-primary mx-auto mb-4" />
            <h3 className="text-xl font-display text-white mb-2 text-center">Rapidez</h3>
            <p className="text-gray-300 text-center">Entregas rápidas en toda la ciudad</p>
          </div>
          <div className="bg-gray-800 p-6 rounded-xl border border-primary hover:scale-105 transition-transform duration-300">
            <Heart className="h-12 w-12 text-primary mx-auto mb-4" />
            <h3 className="text-xl font-display text-white mb-2 text-center">Confianza</h3>
            <p className="text-gray-300 text-center">Años de experiencia respaldando nuestro servicio</p>
          </div>
        </div>

        {/* Categories Section */}
        <div className="mb-16">
          <h2 className="text-4xl font-display text-center mb-12 gradient-text">
            Nuestras Categorías
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {mainCategories.map((category) => {
              const Icon = category.icon;
              return (
                <Link 
                  to="/products" 
                  key={category.name}
                  className="group relative overflow-hidden"
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-lg`} />
                  <div className="relative bg-gray-800 p-8 rounded-lg border border-gray-700 group-hover:border-transparent transition-colors duration-500 h-full">
                    <div className="flex flex-col items-center text-center h-full">
                      <div className="mb-6 transform group-hover:scale-110 transition-transform duration-500">
                        <Icon className="h-16 w-16 text-primary group-hover:text-white transition-colors duration-500" />
                      </div>
                      <h3 className="text-2xl font-display text-white mb-4">
                        {category.name}
                      </h3>
                      <p className="text-gray-400 mb-6 group-hover:text-gray-200 transition-colors duration-500">
                        {category.description}
                      </p>
                      <div className="mt-auto">
                        <div className="flex flex-wrap justify-center gap-2">
                          {category.subcategories.map((sub) => (
                            <span 
                              key={sub}
                              className="px-3 py-1 bg-gray-700 text-sm text-gray-300 rounded-full group-hover:bg-white/20 group-hover:text-white transition-colors duration-500"
                            >
                              {sub}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center bg-gray-800 rounded-2xl p-12 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-primary to-secondary opacity-10"></div>
          <div className="relative z-10">
            <h2 className="text-4xl font-display text-white neon-text mb-6">
              ¿Listo para una experiencia única?
            </h2>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Descubre nuestra selección premium de productos y déjate sorprender por la calidad y el servicio que solo The Happy Blunt puede ofrecerte.
            </p>
            <Link
              to="/products"
              className="inline-flex items-center gap-2 bg-primary text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-opacity-90 transition-colors neon-border"
            >
              Explorar Catálogo
              <Package className="h-5 w-5" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}