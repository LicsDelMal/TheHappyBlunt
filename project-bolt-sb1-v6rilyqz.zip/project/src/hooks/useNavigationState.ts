import { useEffect, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const NAVIGATION_STATE_KEY = 'app_navigation_state';
const LAST_ACTIVE_TIME_KEY = 'app_last_active_time';
const MAX_INACTIVE_TIME = 24 * 60 * 60 * 1000; // 24 hours

export function useNavigationState() {
  const location = useLocation();
  const navigate = useNavigate();

  const handleVisibilityChange = useCallback(() => {
    if (document.visibilityState === 'hidden') {
      try {
        sessionStorage.setItem(NAVIGATION_STATE_KEY, JSON.stringify({
          pathname: location.pathname,
          search: location.search,
          hash: location.hash,
          state: location.state
        }));
        sessionStorage.setItem(LAST_ACTIVE_TIME_KEY, Date.now().toString());
      } catch (err) {
        console.warn('Error saving navigation state:', err);
      }
    }
  }, [location]);

  const restoreState = useCallback(() => {
    if (document.visibilityState === 'visible') {
      try {
        const lastActiveTime = Number(sessionStorage.getItem(LAST_ACTIVE_TIME_KEY));
        const currentTime = Date.now();

        if (currentTime - lastActiveTime < MAX_INACTIVE_TIME) {
          const savedState = sessionStorage.getItem(NAVIGATION_STATE_KEY);
          const savedUser = sessionStorage.getItem('auth_user');
          
          if (savedState && savedUser) {
            const { pathname, search, hash, state } = JSON.parse(savedState);
            const user = JSON.parse(savedUser);
            
            if (user.role === 'admin' || !pathname.startsWith('/admin')) {
              if (location.pathname !== pathname) {
                navigate(pathname + search + hash, { 
                  state,
                  replace: true
                });
              }
            }
          }
        } else {
          // Limpiar estado expirado
          sessionStorage.removeItem(NAVIGATION_STATE_KEY);
          sessionStorage.removeItem(LAST_ACTIVE_TIME_KEY);
        }
      } catch (error) {
        console.warn('Error restoring navigation state:', error);
        sessionStorage.removeItem(NAVIGATION_STATE_KEY);
        sessionStorage.removeItem(LAST_ACTIVE_TIME_KEY);
      }
    }
  }, [navigate, location]);

  useEffect(() => {
    // Guardar estado inicial
    handleVisibilityChange();

    // Agregar listeners
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('focus', restoreState);
    window.addEventListener('pageshow', restoreState);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('focus', restoreState);
      window.removeEventListener('pageshow', restoreState);
    };
  }, [handleVisibilityChange, restoreState]);
}