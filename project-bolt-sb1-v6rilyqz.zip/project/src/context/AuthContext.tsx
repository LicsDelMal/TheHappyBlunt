import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { createClient } from '@supabase/supabase-js';
import type { User } from '../types';

const CACHE_VERSION = '1.0';
const CACHE_KEY = `auth_cache_${CACHE_VERSION}`;

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY,
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: false,
      storage: {
        getItem: (key) => {
          try {
            const item = sessionStorage.getItem(key);
            if (!item) return null;
            const { value, timestamp } = JSON.parse(item);
            if (Date.now() - timestamp > 24 * 60 * 60 * 1000) {
              sessionStorage.removeItem(key);
              return null;
            }
            return value;
          } catch {
            return null;
          }
        },
        setItem: (key, value) => {
          const item = {
            value,
            timestamp: Date.now(),
            version: CACHE_VERSION
          };
          sessionStorage.setItem(key, JSON.stringify(item));
        },
        removeItem: (key) => sessionStorage.removeItem(key)
      }
    }
  }
);

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signIn: (username: string, password: string) => Promise<void>;
  signUp: (username: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const MAX_RETRIES = 3;
const RETRY_DELAY = 1000;

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    const savedUser = sessionStorage.getItem(CACHE_KEY);
    return savedUser ? JSON.parse(savedUser) : null;
  });
  const [loading, setLoading] = useState(true);

  const withRetry = async <T,>(operation: () => Promise<T>, retries = MAX_RETRIES): Promise<T> => {
    try {
      return await operation();
    } catch (error) {
      if (retries > 0) {
        await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
        return withRetry(operation, retries - 1);
      }
      throw error;
    }
  };

  const createUserProfile = async (userId: string, username: string) => {
    try {
      const { data: existingProfile } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (!existingProfile) {
        const { error: insertError } = await supabase
          .from('user_profiles')
          .insert([
            {
              id: userId,
              username,
              role: 'user',
              is_active: true
            }
          ]);

        if (insertError) throw insertError;
      }
    } catch (error) {
      console.error('Error creating user profile:', error);
      throw error;
    }
  };

  const getUserProfile = async (userId: string): Promise<User | null> => {
    try {
      const { data: profile, error } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) throw error;
      return profile;
    } catch (error) {
      console.error('Error fetching user profile:', error);
      return null;
    }
  };

  const setUserWithProfile = async (userId: string, username: string) => {
    try {
      await createUserProfile(userId, username);
      const profile = await getUserProfile(userId);

      if (profile) {
        const userWithRole = {
          id: userId,
          username,
          role: profile.role || 'user',
          is_active: profile.is_active
        };

        setUser(userWithRole);
        sessionStorage.setItem(CACHE_KEY, JSON.stringify(userWithRole));
      }
    } catch (error) {
      console.error('Error setting user profile:', error);
      const defaultUser = {
        id: userId,
        username,
        role: 'user',
        is_active: true
      };
      setUser(defaultUser);
      sessionStorage.setItem(CACHE_KEY, JSON.stringify(defaultUser));
    }
  };

  const recoverSession = async () => {
    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      
      if (error) throw error;
      
      if (session?.user) {
        const username = session.user.user_metadata.username;
        await setUserWithProfile(session.user.id, username);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Error recovering session:', error);
      return false;
    }
  };

  useEffect(() => {
    const initAuth = async () => {
      try {
        const sessionRecovered = await recoverSession();
        if (!sessionRecovered) {
          sessionStorage.removeItem(CACHE_KEY);
          setUser(null);
        }
      } catch (error) {
        console.error('Error initializing auth:', error);
        sessionStorage.removeItem(CACHE_KEY);
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    initAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session?.user) {
        const username = session.user.user_metadata.username;
        await setUserWithProfile(session.user.id, username);
      } else if (event === 'SIGNED_OUT') {
        sessionStorage.removeItem(CACHE_KEY);
        setUser(null);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const signIn = async (username: string, password: string) => {
    try {
      setLoading(true);
      const { data, error } = await withRetry(() =>
        supabase.auth.signInWithPassword({
          email: `${username}@thehappyblunt.com`,
          password,
        })
      );
      
      if (error) throw error;
      if (!data.user) throw new Error('Error al iniciar sesión');

      await setUserWithProfile(data.user.id, username);
    } catch (error) {
      if (error instanceof Error) {
        throw new Error(error.message);
      }
      throw new Error('Error al iniciar sesión');
    } finally {
      setLoading(false);
    }
  };

  const signUp = async (username: string, password: string) => {
    try {
      setLoading(true);
      const { data, error } = await withRetry(() =>
        supabase.auth.signUp({
          email: `${username}@thehappyblunt.com`,
          password,
          options: {
            data: { username }
          }
        })
      );
      
      if (error) {
        if (error.message.includes('already registered')) {
          throw new Error('Este usuario ya está registrado');
        }
        throw error;
      }

      if (data.user) {
        await createUserProfile(data.user.id, username);
      }
    } catch (error) {
      if (error instanceof Error) {
        throw error;
      }
      throw new Error('Error al registrar usuario');
    } finally {
      setLoading(false);
    }
  };

  const signOut = async () => {
    try {
      setLoading(true);
      await withRetry(() => supabase.auth.signOut());
      sessionStorage.removeItem(CACHE_KEY);
      setUser(null);
    } catch (error) {
      console.warn('Warning: Error during sign out:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signUp, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}