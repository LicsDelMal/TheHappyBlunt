import React, { createContext, useContext, useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import type { CartItem, Product } from '../types';
import { useAuth } from './AuthContext';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

interface CartContextType {
  items: CartItem[];
  addToCart: (product: Product, quantity: number) => Promise<void>;
  removeFromCart: (productId: string) => Promise<void>;
  updateQuantity: (productId: string, quantity: number) => Promise<void>;
  clearCart: () => Promise<void>;
  loading: boolean;
  error: string | null;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

const MAX_RETRIES = 3;
const INITIAL_RETRY_DELAY = 1000; // 1 second

// Helper function for exponential backoff
const wait = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Helper function to handle retries with exponential backoff
const withRetry = async <T,>(
  operation: () => Promise<T>,
  retries = MAX_RETRIES,
  delay = INITIAL_RETRY_DELAY
): Promise<T> => {
  try {
    return await operation();
  } catch (error) {
    if (retries > 0) {
      await wait(delay);
      return withRetry(operation, retries - 1, delay * 2);
    }
    throw error;
  }
};

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const fetchCartItems = async () => {
    if (!user) return;

    try {
      setLoading(true);
      setError(null);

      // Get cart items with retry logic
      const { data: cartData, error: cartError } = await withRetry(() =>
        supabase
          .from('cart_items')
          .select('product_id, quantity')
          .eq('user_id', user.id)
      );

      if (cartError) throw cartError;

      if (!cartData || cartData.length === 0) {
        setItems([]);
        return;
      }

      // Get product details with retry logic
      const productIds = cartData.map(item => item.product_id);
      const { data: productsData, error: productsError } = await withRetry(() =>
        supabase
          .from('products')
          .select('*')
          .in('id', productIds)
      );

      if (productsError) throw productsError;

      const cartItems = cartData.map(cartItem => {
        const product = productsData?.find(p => p.id === cartItem.product_id);
        if (!product) return null;
        return {
          ...product,
          quantity: cartItem.quantity
        };
      }).filter((item): item is CartItem => item !== null);

      setItems(cartItems);
    } catch (err) {
      console.error('Error fetching cart items:', err);
      setError('Error al cargar el carrito. Por favor, intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchCartItems();
    } else {
      setItems([]);
      setError(null);
    }
  }, [user]);

  const addToCart = async (product: Product, quantity: number) => {
    if (!user) {
      setError('Debes iniciar sesión para agregar productos al carrito');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      // Check if item exists with retry logic
      const { data: existingItem, error: checkError } = await withRetry(() =>
        supabase
          .from('cart_items')
          .select('quantity')
          .eq('user_id', user.id)
          .eq('product_id', product.id)
          .maybeSingle()
      );

      if (checkError) throw checkError;

      if (existingItem) {
        // Update existing item with retry logic
        const newQuantity = existingItem.quantity + quantity;
        const { error: updateError } = await withRetry(() =>
          supabase
            .from('cart_items')
            .update({ quantity: newQuantity })
            .eq('user_id', user.id)
            .eq('product_id', product.id)
        );

        if (updateError) throw updateError;
      } else {
        // Insert new item with retry logic
        const { error: insertError } = await withRetry(() =>
          supabase
            .from('cart_items')
            .insert({
              user_id: user.id,
              product_id: product.id,
              quantity: quantity
            })
        );

        if (insertError) throw insertError;
      }

      await fetchCartItems();
    } catch (err) {
      console.error('Error adding to cart:', err);
      setError('Error al agregar al carrito. Por favor, intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  const removeFromCart = async (productId: string) => {
    if (!user) return;

    try {
      setLoading(true);
      setError(null);

      // Delete item with retry logic
      const { error } = await withRetry(() =>
        supabase
          .from('cart_items')
          .delete()
          .eq('user_id', user.id)
          .eq('product_id', productId)
      );

      if (error) throw error;

      await fetchCartItems();
    } catch (err) {
      console.error('Error removing from cart:', err);
      setError('Error al eliminar del carrito. Por favor, intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  const updateQuantity = async (productId: string, quantity: number) => {
    if (!user) return;

    try {
      setLoading(true);
      setError(null);

      // Update quantity with retry logic
      const { error } = await withRetry(() =>
        supabase
          .from('cart_items')
          .update({ quantity })
          .eq('user_id', user.id)
          .eq('product_id', productId)
      );

      if (error) throw error;

      await fetchCartItems();
    } catch (err) {
      console.error('Error updating quantity:', err);
      setError('Error al actualizar cantidad. Por favor, intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  const clearCart = async () => {
    if (!user) return;

    try {
      setLoading(true);
      setError(null);

      // Clear cart with retry logic
      const { error } = await withRetry(() =>
        supabase
          .from('cart_items')
          .delete()
          .eq('user_id', user.id)
      );

      if (error) throw error;

      setItems([]);
    } catch (err) {
      console.error('Error clearing cart:', err);
      setError('Error al limpiar el carrito. Por favor, intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  const value = {
    items,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    loading,
    error
  };

  return (
    <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}