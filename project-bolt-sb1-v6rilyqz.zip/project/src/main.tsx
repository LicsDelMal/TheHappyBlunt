import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';

// Función para limpiar caché antigua
const clearOldCache = async () => {
  try {
    if ('caches' in window) {
      const cacheNames = await caches.keys();
      const oldCaches = cacheNames.filter(name => name.startsWith('app-cache-'));
      await Promise.all(oldCaches.map(name => caches.delete(name)));
    }
  } catch (err) {
    console.warn('Error clearing old caches:', err);
  }
};

// Limpiar caché al inicio
clearOldCache();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);

// Registrar evento para recargar en caso de error de red
window.addEventListener('offline', () => {
  console.warn('Connection lost. Some features may be unavailable.');
});

window.addEventListener('online', () => {
  console.log('Connection restored. Reloading...');
  window.location.reload();
});