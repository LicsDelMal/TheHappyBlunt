import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');

  return {
    plugins: [react()],
    optimizeDeps: {
      exclude: ['lucide-react'],
    },
    build: {
      // Improve chunking strategy
      rollupOptions: {
        output: {
          manualChunks: {
            vendor: ['react', 'react-dom', 'react-router-dom'],
            ui: ['lucide-react'],
            supabase: ['@supabase/supabase-js']
          }
        }
      },
      // Enable source maps for better debugging
      sourcemap: true,
      // Improve chunk loading
      chunkSizeWarningLimit: 1000,
    },
    server: {
      // Optimize dev server
      hmr: {
        overlay: false
      },
      watch: {
        usePolling: false,
        interval: 100
      }
    },
    define: {
      'process.env': env
    }
  };
});