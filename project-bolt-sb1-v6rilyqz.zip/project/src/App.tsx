import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import { useNavigationState } from './hooks/useNavigationState';
import Navbar from './components/Navbar';

// Lazy load pages with error boundaries
const Home = lazy(() => import('./pages/Home'));
const Products = lazy(() => import('./pages/Products'));
const ProductDetail = lazy(() => import('./pages/ProductDetail'));
const Cart = lazy(() => import('./pages/Cart'));
const Admin = lazy(() => import('./pages/Admin'));
const Settings = lazy(() => import('./pages/Settings'));

// Loading component
const LoadingSpinner = () => (
  <div className="min-h-screen bg-dark flex items-center justify-center">
    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
  </div>
);

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
}

// Error Boundary Component
class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(): ErrorBoundaryState {
    return { hasError: true };
  }

  componentDidCatch(error: Error) {
    console.error('Page Error:', error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-dark flex items-center justify-center">
          <div className="bg-red-900 text-white p-4 rounded-lg">
            <h2 className="text-xl font-bold mb-2">Algo salió mal</h2>
            <p>Por favor, recarga la página o intenta más tarde.</p>
            <button 
              onClick={() => {
                this.setState({ hasError: false });
                window.location.reload();
              }}
              className="mt-4 bg-red-700 px-4 py-2 rounded hover:bg-red-600"
            >
              Recargar página
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

// Wrap each lazy-loaded component with error boundary
const withErrorBoundary = (Component: React.ComponentType) => {
  return function WithErrorBoundary(props: any) {
    return (
      <ErrorBoundary>
        <Component {...props} />
      </ErrorBoundary>
    );
  };
};

const SafeHome = withErrorBoundary(Home);
const SafeProducts = withErrorBoundary(Products);
const SafeProductDetail = withErrorBoundary(ProductDetail);
const SafeCart = withErrorBoundary(Cart);
const SafeAdmin = withErrorBoundary(Admin);
const SafeSettings = withErrorBoundary(Settings);

function AppContent() {
  useNavigationState();

  return (
    <ErrorBoundary>
      <Navbar />
      <Suspense fallback={<LoadingSpinner />}>
        <Routes>
          <Route path="/" element={<SafeHome />} />
          <Route path="/products" element={<SafeProducts />} />
          <Route path="/product/:id" element={<SafeProductDetail />} />
          <Route path="/cart" element={<SafeCart />} />
          <Route path="/admin" element={<SafeAdmin />} />
          <Route path="/settings" element={<SafeSettings />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Suspense>
    </ErrorBoundary>
  );
}

export default function App() {
  return (
    <Router>
      <AuthProvider>
        <CartProvider>
          <AppContent />
        </CartProvider>
      </AuthProvider>
    </Router>
  );
}